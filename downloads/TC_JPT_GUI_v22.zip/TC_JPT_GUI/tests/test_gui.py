import csv
import http.client
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
import zipfile

from boiling_automation.gui import GuiServer, GuiSession


def payload(**overrides):
    return {"source": "demo", "critical_c": 100, "allowed_std_c": 0.2,
            "max_power_percent": 0, "speed": 300, **overrides}


class GuiSessionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.session = GuiSession(Path(self.temporary.name) / "results")

    def tearDown(self):
        self.session.stop()
        if self.session.worker:
            self.session.worker.join(5)
        self.temporary.cleanup()

    def complete(self):
        self.session.worker.join(5)
        self.assertFalse(self.session.worker.is_alive(), "Replay should finish within five seconds")
        return self.session.snapshot()

    def test_gui_exports_selected_interval_and_three_full_measurement_files(self):
        self.session.start(payload())
        state = self.complete()
        self.assertEqual(state["state"], "completed")
        self.assertFalse(state["hardware_connected"])
        self.assertEqual(state["records"][0]["recorded_at_s"], 90)
        body, name = self.session.export()
        self.assertTrue(name.endswith(".zip"))
        with zipfile.ZipFile(io.BytesIO(body)) as archive:
            self.assertEqual(set(archive.namelist()), {"run.json", "events.jsonl", "stages.csv", "selected_samples.csv", "measurements_raw.lvm", "measurements_tab4.lvm", "measurements_tab3.lvm", "DATA_FORMAT.md", "data_snapshot.json"})
            samples = list(csv.DictReader(io.StringIO(archive.read("selected_samples.csv").decode())))
            self.assertEqual(len(samples), 21)
            self.assertEqual(float(samples[-1]["t_s"]) - float(samples[0]["t_s"]), 20)
            metadata = json.loads(archive.read("run.json"))
            self.assertFalse(metadata["hardware_connected"])
            self.assertTrue(metadata["created_at"].endswith("+09:00"))

    def test_blank_tolerance_uses_five_minutes(self):
        self.session.start(payload(allowed_std_c=None))
        state = self.complete()
        self.assertEqual(state["records"][0]["recorded_at_s"], 300)
        self.assertEqual(state["records"][0]["completion_reason"], "maximum_step_time")

    def test_threshold_injection_latches_both_shutdown_decisions(self):
        self.session.start(payload(max_power_percent=100, speed=60))
        self.session.inject(7)
        state = self.complete()
        self.assertEqual(state["reason"], "critical_temperature")
        self.assertFalse(state["running"])
        self.assertEqual(state["events"][-1]["details"]["channels"], ["TC8"])
        self.assertEqual(state["events"][-1]["details"]["independent_actions"], ["shutter_close", "laser_emission_off"])
        self.assertFalse(state["hardware_connected"])

    def test_emergency_stop_preserves_run_and_requires_new_start(self):
        first = self.session.start(payload(speed=1))
        stopped = self.session.stop("emergency_stop")
        self.assertEqual(stopped["reason"], "emergency_stop")
        self.assertFalse(stopped["running"])
        self.assertTrue(Path(first["result_folder"]).is_dir())
        second = self.session.start(payload())
        state = self.complete()
        self.assertNotEqual(first["run_name"], second["run_name"])
        self.assertTrue(Path(first["result_folder"]).is_dir())
        self.assertEqual(state["reason"], "maximum_output_reached")

    def test_csv_replay_is_connected_to_the_same_core(self):
        text = "t_s,TC1,TC2,TC3,TC4,TC5,TC6,TC7,TC8\n" + "\n".join(
            str(t) + ",25,25,25,25,25,25,25,25" for t in range(91)
        )
        self.session.start(payload(source="csv", csv_text=text))
        state = self.complete()
        self.assertEqual(state["source"], "csv")
        self.assertEqual(state["records"][0]["segment"]["channels"][0]["mean_c"], 25)
        self.assertEqual(len(self.session.record(0)["selected_samples"]), 21)

    def test_invalid_csv_header_does_not_create_a_run(self):
        with self.assertRaisesRegex(ValueError, "TC1"):
            self.session.start(payload(source="csv", csv_text="TC1\n25\n"))
        self.assertFalse(self.session.snapshot()["running"])
        self.assertIsNone(self.session.writer)

    def test_invalid_values_remain_valid_json_in_the_gui(self):
        text = "t_s,TC1,TC2,TC3,TC4,TC5,TC6,TC7,TC8\n0,nan,25,25,25,25,25,25,25\n"
        self.session.start(payload(source="csv", csv_text=text))
        state = self.complete()
        self.assertEqual(state["reason"], "invalid_temperature_data")
        json.dumps(state, allow_nan=False)

    def test_actual_hardware_mode_is_not_available(self):
        with self.assertRaises(ValueError):
            self.session.start(payload(source="hardware"))

    def test_nonfinite_critical_value_is_rejected(self):
        with self.assertRaises(ValueError):
            self.session.start(payload(critical_c=float("nan")))


class GuiHttpTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.server = GuiServer(("127.0.0.1", 0), Path(self.temporary.name) / "results")
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.session.stop()
        if self.server.session.worker:
            self.server.session.worker.join(5)
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(5)
        self.temporary.cleanup()

    def request(self, method, path, data=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_address[1], timeout=5)
        try:
            connection.request(method, path, body=json.dumps(data) if data is not None else None,
                               headers=headers or {})
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            connection.close()

    def test_page_and_snapshot_are_available(self):
        status, headers, body = self.request("GET", "/")
        self.assertEqual(status, 200)
        self.assertIn("text/html", headers["Content-Type"])
        self.assertIn("보일링 실험 제어", body.decode())
        status, _, body = self.request("GET", "/api/state")
        self.assertEqual(status, 200)
        self.assertFalse(json.loads(body)["hardware_connected"])

    def test_start_requires_app_token_and_rejects_foreign_origin(self):
        status, _, _ = self.request("POST", "/api/start", payload())
        self.assertEqual(status, 403)
        status, _, _ = self.request("POST", "/api/start", payload(), {
            "X-App-Token": self.server.token, "Origin": "https://another.example"
        })
        self.assertEqual(status, 403)

    def test_unexpected_host_is_rejected(self):
        status, _, _ = self.request("GET", "/api/state", headers={"Host": "another.example"})
        self.assertEqual(status, 403)

    def test_start_record_download_and_stop_via_http(self):
        status, _, body = self.request("GET", "/api/bootstrap")
        token = json.loads(body)["token"]
        status, _, _ = self.request("POST", "/api/start", payload(), {"X-App-Token": token})
        self.assertEqual(status, 200)
        self.server.session.worker.join(5)
        status, _, body = self.request("GET", "/api/record?index=0")
        self.assertEqual(status, 200)
        self.assertEqual(len(json.loads(body)["selected_samples"]), 21)
        status, headers, body = self.request("GET", "/api/export")
        self.assertEqual(status, 200)
        self.assertEqual(headers["Content-Type"], "application/zip")
        self.assertIsNone(zipfile.ZipFile(io.BytesIO(body)).testzip())
        status, _, _ = self.request("POST", "/api/stop", {}, {"X-App-Token": token})
        self.assertEqual(status, 200)
