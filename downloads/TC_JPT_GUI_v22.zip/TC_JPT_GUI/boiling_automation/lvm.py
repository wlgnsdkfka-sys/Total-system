"""LabVIEW Measurement text files with numeric channels and explicit time values."""
import csv
from datetime import datetime,timedelta,timezone
import io
import json
import math

from .calibration_common import ALL_CHANNELS

CSV_COLUMNS=('sample_id','t_s','elapsed_s','power_percent','power_index_after_sample_percent',
             'state_after_sample','sample_status','stop_reason','interpolated','temperature_basis',*ALL_CHANNELS)
Y_COLUMNS=(*ALL_CHANNELS,'sample_id','elapsed_s','power_percent','power_index_after_sample_percent','interpolated')


def file_header():
    stamp=datetime.now(timezone(timedelta(hours=9)))
    fields=[('Writer_Version','2'),('Reader_Version','2'),('Separator','Tab'),
            ('Decimal_Separator','.'),('Multi_Headings','Yes'),('X_Columns','One'),
            ('Time_Pref','Relative'),('Date',stamp.strftime('%Y/%m/%d')),('Time',stamp.strftime('%H:%M:%S.%f'))]
    return 'LabVIEW Measurement\n'+''.join(k+'\t'+v+'\n' for k,v in fields)+'***End_of_Header***\n\n'


def segment(rows,comment_cache):
    count=len(Y_COLUMNS);n=len(rows)
    def header(key,values):return key+'\t'+'\t'.join(map(str,values))+'\n'
    delta=rows[1][1]-rows[0][1] if n>1 else 0.
    if not isinstance(delta,(int,float)) or not math.isfinite(delta):delta=0.
    origin=rows[0][1] if math.isfinite(rows[0][1]) else 0.
    result=[header('Channels',[count]),header('Samples',[n]*count),
            header('Y_Unit_Label',['Celsius']*12+['Index','s','Percent','Percent','Boolean']),
            header('X_Dimension',['Time']*count),header('X0',[origin]*count),
            header('Delta_X',[delta]*count),'***End_of_Header***\n',
            header('X_Value',[*Y_COLUMNS,'Comment'])]
    for row in rows:
        key=(row[5],row[6],row[7],row[9])
        if key not in comment_cache:
            comment_cache[key]=json.dumps(dict(zip(('state_after_sample','sample_status','stop_reason','temperature_basis'),key)),separators=(',',':'),ensure_ascii=True)
        numeric=[row[1],*row[10:],row[0],row[2],row[3],row[4],row[8]]
        result.append('\t'.join('NaN' if v is None else str(v) for v in numeric)+'\t'+comment_cache[key]+'\n')
    result.append('\n')
    return ''.join(result)


def measurement_rows(body):
    """Decode our complete LVM segments, including lossless status comments."""
    text=body.decode('utf-8-sig') if isinstance(body,bytes) else body.lstrip('\ufeff')
    if not text.startswith('LabVIEW Measurement'):raise ValueError('LVM 파일 머리글을 확인하세요.')
    remaining=0;columns=None;expected=None
    for line in text.splitlines():
        fields=line.split('\t')
        if remaining:
            if columns is None or len(fields)!=len(columns):raise ValueError('LVM 온도 행이 불완전합니다.')
            values=dict(zip(columns,fields))
            try:comment=json.loads(values['Comment'])
            except (KeyError,ValueError,TypeError) as error:raise ValueError('LVM 측정 상태 정보를 확인하세요.') from error
            if (not isinstance(comment,dict) or set(comment)!={'state_after_sample','sample_status','stop_reason','temperature_basis'}
                    or any(not isinstance(v,str) for v in comment.values())):
                raise ValueError('LVM 측정 상태 필드가 올바르지 않습니다.')
            out={'t_s':values['X_Value'],**{key:values[key] for key in Y_COLUMNS},**comment}
            yield {key:'' if out[key]=='NaN' else out[key] for key in CSV_COLUMNS}
            remaining-=1
        elif fields[0]=='Samples':
            try:expected=int(fields[1])
            except (ValueError,IndexError) as error:raise ValueError('LVM 샘플 수를 확인하세요.') from error
        elif fields[0]=='X_Value':
            if fields!=['X_Value',*Y_COLUMNS,'Comment'] or expected is None or expected<1:
                raise ValueError('지원하는 TC1~12 실험 LVM 형식이 아닙니다.')
            columns=fields;remaining=expected;expected=None
    if remaining:raise ValueError('LVM 마지막 저장 구간이 불완전합니다.')


def to_csv(body):
    output=io.StringIO(newline='');writer=csv.DictWriter(output,fieldnames=CSV_COLUMNS)
    writer.writeheader();writer.writerows(measurement_rows(body))
    return output.getvalue().encode('utf-8')
