# 실험 LVM 데이터 파일 안내

v22의 연속 실험 이력은 실제 LabVIEW Measurement 텍스트 형식(v2, 탭 구분)으로 저장합니다.
- measurements_raw.lvm: 보정 전 TC1~12 원시온도.
- measurements_tab4.lvm: TC1~8 전기로 보정만 적용, bulk TC9~12 원시값.
- measurements_tab3.lvm: 전기로 보정 + 실측 오프셋의 최종 온도. bulk는 비등 오프셋만 적용.

세 파일의 sample_id와 X_Value(초), 출력 설정은 일치합니다. 각 파일은 온도 채널 TC1~12와
sample_id / elapsed_s / power_percent / power_index_after_sample_percent / interpolated의
17개 숫자 채널, 실제 시각 X_Value, Comment를 포함합니다. 누락 bulk는 NaN으로 표시하며
잘못된 입력 숫자 nan/inf와 구분합니다. Comment의 JSON에는 state_after_sample, sample_status,
stop_reason, temperature_basis가 있습니다. 정상 온도 샘플을 생략하거나 숫자를 반올림하지 않습니다.

파일 헤더와 각 저장 구간의 Channels, Samples, X0, Delta_X, X_Value 머리글을 포함합니다.
구간마다 실제 X_Value를 저장하므로 불규칙한 입력의 시각도 유지합니다. 0.25초 경과를 다음
입력에서 확인하거나 128행이 모이면 저장하며, 단계 기록/상승/정지/종료/다운로드 전에 비웁니다.
세 파일 모두 완료한 구간의 바이트 위치만 내보냅니다. 저장 실패는 이전 공통 완료 지점으로
되돌린 뒤 중단하며, 강제 종료 시 최근 미저장 구간이 남을 수 있습니다.

NI 실험의 20초 구간은 단계 종료 판정 시점 직전 60초를 고정해 배경 작업으로 계산합니다.
그동안 현재 출력을 유지하며 온도 수집, 임계 감시와 누수 감시는 계속합니다. 계산·기록 저장
완료 후 다음 출력으로 진행하므로 이전 선택 구간을 쓰는 누수 비교 기준을 유지합니다.
records의 recorded_at_s는 판정 시점이며 실제 상승 이벤트 시각과 소폭 다를 수 있습니다.
계산 중 임계/긴급중단이 발생하면 뒤늦게 완료된 계산으로 출력을 올리지 않습니다.
단계 계산이 비정상적으로 오래 걸리면 보호 정지하며, NI 버퍼 2초 보호도 유지합니다.

stages.csv와 selected_samples.csv는 기존의 작은 단계 요약 및 선택 구간 파일로 유지합니다.
전체 입력을 CSV 세 파일로 동시에 중복 저장하지 않습니다. 예전 API의 CSV 다운로드 요청은
완료된 LVM 데이터를 요청 시 변환하며, 현재 화면의 세 다운로드 버튼과 결과 ZIP은 LVM입니다.
재생은 원시 LVM 또는 예전 원시 CSV를 사용하세요. 최종 보정값을 원시값으로 다시 입력해
보정을 중복 적용하는 동작은 차단합니다.

run.json의 보정식·원시 교정점·실측 오프셋·수식 상수와 events.jsonl을 함께 보관하세요.
data_snapshot.json은 완료 샘플 수, 파일별 완료 바이트 수와 저장 설정을 기록합니다.
출력 %는 가상 단계 설정이며 실제 레이저 ON/OFF 통신은 여전히 미연결입니다.

## 요청 시 CSV 호환 내보내기

예전 API의 `/api/export-measurements?basis=raw&format=csv`는 저장 완료된 LVM을 요청 시 변환합니다. 라이브 수집에서 CSV 세 파일을 중복 쓰지 않습니다. `format=lvm`은 실제 LVM 데이터를 반환합니다. LVM 자체의 텍스트 형식이 저장 지연을 없앤다고 보장하지 않으며, 구간 계산 개선과 배경 처리를 함께 적용합니다.
