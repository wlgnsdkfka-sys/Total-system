import contextlib
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest

from boiling_automation.__main__ import main


class ReplayFileTests(unittest.TestCase):
    def invoke(self, root, *arguments):
        output = root / "results"
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            status = main([*arguments, "--output", str(output)])
        return status, output, stdout.getvalue(), stderr.getvalue()

    def test_early_stability_saves_only_twenty_seconds_for_each_output(self):
        with tempfile.TemporaryDirectory() as name:
            status, output, stdout, _ = self.invoke(
                Path(name), "--demo", "--critical-temp", "100", "--stability-std", "0.1"
            )
            self.assertEqual(status, 0)
            result = json.loads(stdout)
            self.assertEqual(result["reason"], "critical_temperature")
            self.assertEqual(result["recorded_steps"], 10)
            with (output / "selected_samples.csv").open() as source:
                selected = list(csv.DictReader(source))
            # At 1 Hz, inclusive endpoints represent 20 s using 21 samples.
            self.assertEqual(len(selected), 21 * 10)
            self.assertFalse((output / "raw.csv").exists())
            for power in range(10):
                rows = [r for r in selected if int(r["power_percent"]) == power]
                self.assertEqual(float(rows[-1]["t_s"]) - float(rows[0]["t_s"]), 20)
            events = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]
            self.assertEqual(events[-1]["details"]["independent_actions"], ["shutter_close", "laser_emission_off"])
            self.assertFalse(json.loads((output / "run.json").read_text())["hardware_connected"])

    def test_unspecified_stability_tolerance_uses_five_minute_limit(self):
        with tempfile.TemporaryDirectory() as name:
            status, output, _, _ = self.invoke(Path(name), "--demo", "--critical-temp", "100")
            self.assertEqual(status, 0)
            with (output / "stages.csv").open() as source:
                rows = list(csv.DictReader(source))
            self.assertEqual([float(r["recorded_at_s"]) for r in rows], [300, 600])
            self.assertTrue(all(r["completion_reason"] == "maximum_step_time" for r in rows))

    def test_truncated_input_is_incomplete_and_returns_failure(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            source = root / "input.csv"
            source.write_text("t_s,TC1,TC2,TC3,TC4,TC5,TC6,TC7,TC8\n0,25,25,25,25,25,25,25,25\n")
            status, output, stdout, _ = self.invoke(root, "--input", str(source), "--critical-temp", "100")
            self.assertEqual(status, 2)
            self.assertEqual(json.loads(stdout)["reason"], "input_ended_before_completion")
            self.assertEqual(len((output / "selected_samples.csv").read_text().splitlines()), 1)

    def test_bad_csv_reports_input_error(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            source = root / "input.csv"
            source.write_text("TC1\n25\n")
            status, output, _, stderr = self.invoke(root, "--input", str(source), "--critical-temp", "100")
            self.assertEqual(status, 2)
            self.assertIn("requires t_s", stderr)
            event = json.loads((output / "events.jsonl").read_text().splitlines()[-1])
            self.assertEqual(event["details"]["reason"], "input_error")

    def test_existing_results_are_preserved(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            (root / "results").mkdir()
            marker = root / "results" / "run.json"
            marker.write_text("existing experiment")
            status, _, _, stderr = self.invoke(root, "--demo", "--critical-temp", "100")
            self.assertEqual(status, 2)
            self.assertIn("existing results are preserved", stderr)
            self.assertEqual(marker.read_text(), "existing experiment")


if __name__ == "__main__":
    unittest.main()
