"""Counter waveforms, explicit commands, closure priority, and honest state reporting."""
import http.client
import importlib
import json
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from boiling_automation.gui import GuiSession,GuiServer
from boiling_automation.manual_controls import ManualControls,NIShutter,ShutterSettings,discover_outputs


INVENTORY={'devices':[{'name':'Dev2','model':'test NI counter','simulated':False,'counter_channels':['Dev2/ctr0','Dev2/ctr1']}]}
SETTINGS={'counter_channel':'Dev2/ctr0','output_terminal':''}


class FakeTask:
    def __init__(self):
        self.channel_settings=None;self.closed=False;self.started=False;self.implicit=None
        self.channel=SimpleNamespace(co_pulse_term='/Dev2/PFI0')
        self.co_channels=SimpleNamespace(add_co_pulse_chan_time=self.add)
        self.timing=SimpleNamespace(cfg_implicit_timing=self.configure)
    def add(self,*args,**kwargs):self.channel_settings=(args,kwargs);return self.channel
    def configure(self,**kwargs):self.implicit=kwargs
    def start(self):self.started=True
    def close(self):self.closed=True


class ManualTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.m=ManualControls(Path(self.temp.name));self.tasks=[]
        self.constants=SimpleNamespace(TimeUnits=SimpleNamespace(SECONDS='seconds'),Level=SimpleNamespace(LOW='low'),AcquisitionType=SimpleNamespace(CONTINUOUS='continuous'))
        def task():
            t=FakeTask();self.tasks.append(t);return t
        self.module=SimpleNamespace(Task=task)
        real_import=importlib.import_module
        def load(name):
            if name=='nidaqmx':return self.module
            if name=='nidaqmx.constants':return self.constants
            if not name.startswith('nidaqmx'):return real_import(name)
            raise AssertionError('Unexpected NI module: '+name)
        for p in (patch('boiling_automation.manual_controls.importlib.import_module',side_effect=load),patch('boiling_automation.manual_controls.discover_outputs',return_value=INVENTORY)):
            p.start();self.addCleanup(p.stop)
    def tearDown(self):
        self.m.wait_for_close()
        self.m.disconnect();self.temp.cleanup()
    def connect(self):self.m.connect(SETTINGS)
    def test_startup_restore_and_connection_never_create_output_tasks(self):
        self.assertEqual(self.tasks,[]);self.connect();self.assertEqual(self.tasks,[])
        restored=ManualControls(Path(self.temp.name))
        state=restored.snapshot()['shutter']
        self.assertEqual(state['settings']['counter_channel'],'Dev2/ctr0')
        self.assertFalse(state['connected']);self.assertIsNone(state['last_command']);self.assertEqual(self.tasks,[])
    def test_open_close_preserve_fixed_low_and_use_distinct_confirmed_high_times(self):
        self.connect();self.m.open();self.m.request_close();self.assertTrue(self.m.wait_for_close())
        self.assertEqual(len(self.tasks),2)
        opened,closed=self.tasks
        self.assertEqual(opened.channel_settings[1]['high_time'],.0010)
        self.assertEqual(closed.channel_settings[1]['high_time'],.0015)
        self.assertTrue(all(t.channel_settings[1]['low_time']==.0185 for t in self.tasks))
        self.assertTrue(all(t.channel_settings[1]['units']=='seconds' and t.channel_settings[1]['idle_state']=='low' for t in self.tasks))
        self.assertTrue(all(t.implicit=={'sample_mode':'continuous'} for t in self.tasks))
        self.assertTrue(opened.closed);self.assertFalse(closed.closed)
        self.assertIsNone(self.m.snapshot()['shutter']['actual_position'])
        self.assertFalse(self.m.snapshot()['shutter']['position_feedback_available'])
    def test_selected_output_terminal_is_applied(self):
        self.m.connect({**SETTINGS,'output_terminal':'/Dev2/PFI7'});self.m.open()
        self.assertEqual(self.tasks[0].channel.co_pulse_term,'/Dev2/PFI7')
    def test_unknown_or_simulated_channels_do_not_connect_or_emit(self):
        with self.assertRaises(ValueError):self.m.connect({'counter_channel':'Dev3/ctr0'})
        with patch('boiling_automation.manual_controls.discover_outputs',return_value={'devices':[{**INVENTORY['devices'][0],'simulated':True}]}):
            with self.assertRaises(ValueError):self.connect()
        self.assertEqual(self.tasks,[])
    def test_unsupported_actions_and_physical_channels_are_rejected(self):
        for data in ({'counter_channel':'Dev2/ai0'},{'counter_channel':'Dev2/ctr0:1'},{**SETTINGS,'output_terminal':'/Other/port0/line1'}):
            with self.assertRaises(ValueError):ShutterSettings.from_payload(data)
        with self.assertRaises(ValueError):self.m.open()
        with self.assertRaises(ValueError):NIShutter(ShutterSettings('Dev2/ctr0')).apply('toggle')
        self.assertEqual(self.tasks,[])
    def test_chassis_counter_can_route_to_module_pfi(self):
        settings=ShutterSettings.from_payload({'counter_channel':'cDAQ1/ctr0','output_terminal':'/cDAQ1Mod1/PFI0'})
        self.assertEqual(settings.output_terminal,'/cDAQ1Mod1/PFI0')
    def test_failed_setup_and_cleanup_keep_task_available_for_another_close_attempt(self):
        self.connect()
        with patch.object(FakeTask,'start',side_effect=RuntimeError('start failed')),patch.object(FakeTask,'close',side_effect=RuntimeError('cleanup failed')):
            with self.assertRaisesRegex(ValueError,'NI 출력 태스크 해제 실패'):self.m.open()
        self.assertIs(self.m.driver.task,self.tasks[0])
        self.assertIsNone(self.m.snapshot()['shutter']['actual_position'])
        self.m.request_close();self.assertTrue(self.m.wait_for_close())
        self.assertTrue(self.tasks[0].closed);self.assertEqual(self.m.snapshot()['shutter']['last_command'],'close')
    def test_task_start_failure_closes_created_task_and_reports_unknown_position(self):
        self.connect()
        with patch.object(FakeTask,'start',side_effect=RuntimeError('device unavailable')):
            with self.assertRaisesRegex(ValueError,'device unavailable'):self.m.open()
        self.assertTrue(self.tasks[0].closed)
        self.assertIsNone(self.m.snapshot()['shutter']['last_command'])
    def test_active_output_settings_cannot_be_replaced_without_release(self):
        self.connect();self.m.open()
        with self.assertRaises(ValueError):self.m.connect({'counter_channel':'Dev2/ctr1'})
        self.assertEqual(self.m.settings.counter_channel,'Dev2/ctr0')
    def test_duplicate_close_requests_do_not_restart_held_closed_waveform(self):
        self.connect();self.m.request_close();self.m.wait_for_close();count=len(self.tasks)
        self.m.request_close();self.m.wait_for_close();self.assertEqual(len(self.tasks),count)
        self.m.request_close('critical_temperature',latch=True);self.m.wait_for_close()
        self.assertEqual(len(self.tasks),count+1)
        self.m.request_close('critical_temperature',latch=True);self.m.wait_for_close()
        self.assertEqual(len(self.tasks),count+1)
        self.assertEqual(self.m.snapshot()['shutter']['inhibit_reason'],'critical_temperature')
    def test_emergency_arriving_during_open_is_closed_next_and_blocks_reopening(self):
        self.connect();entered=threading.Event();release=threading.Event();original=self.m.driver.apply
        def slow(action):
            if action=='open':entered.set();release.wait(3)
            return original(action)
        with patch.object(self.m.driver,'apply',side_effect=slow):
            worker=threading.Thread(target=self.m.open);worker.start();self.assertTrue(entered.wait(1))
            self.m.request_close('emergency_stop',latch=True)
            self.assertFalse(self.m.clear_interlock())
            release.set();worker.join(3);self.assertTrue(self.m.wait_for_close())
        self.assertEqual(self.m.snapshot()['shutter']['last_command'],'close')
        with self.assertRaises(ValueError):self.m.open()
    def test_slow_shutter_io_does_not_block_temperature_state_snapshots(self):
        self.connect();entered=threading.Event();release=threading.Event();original=self.m.driver.apply
        def slow(action):entered.set();release.wait(3);return original(action)
        with patch.object(self.m.driver,'apply',side_effect=slow):
            self.m.request_close();self.assertTrue(entered.wait(1))
            snapshots=[];reader=threading.Thread(target=lambda:snapshots.append(self.m.snapshot()));reader.start();reader.join(.5)
            try:self.assertFalse(reader.is_alive());self.assertTrue(snapshots[0]['shutter']['close_requested'])
            finally:release.set();self.m.wait_for_close();reader.join(2)
    def test_log_failure_prevents_open_but_does_not_prevent_close(self):
        self.connect()
        with patch.object(self.m,'_record',side_effect=OSError('disk full')):
            with self.assertRaises(ValueError):self.m.open()
            self.assertEqual(self.tasks,[])
            self.m.request_close('emergency_stop',latch=True);self.assertTrue(self.m.wait_for_close())
        self.assertEqual(self.tasks[0].channel_settings[1]['high_time'],.0015)
        self.assertEqual(self.m.snapshot()['shutter']['last_command'],'close')
    def test_a_stalled_close_log_cannot_delay_the_close_pulse(self):
        self.connect();self.m.open();entered=threading.Event();release=threading.Event();original=self.m._record
        def slow(action,details):
            if action=='shutter_command_requested' and details['action']=='close':entered.set();release.wait(3)
            return original(action,details)
        with patch.object(self.m,'_record',side_effect=slow):
            self.m.request_close('emergency_stop',latch=True);self.assertTrue(entered.wait(1))
            try:
                self.assertEqual(len(self.tasks),2)
                self.assertEqual(self.tasks[-1].channel_settings[1]['high_time'],.0015)
            finally:release.set();self.m.wait_for_close()
    def test_emergency_during_open_audit_cancels_open_before_ni_output(self):
        self.connect();entered=threading.Event();release=threading.Event();original=self.m._record;errors=[]
        def slow(action,details):
            if action=='shutter_command_requested' and details['action']=='open':entered.set();release.wait(3)
            return original(action,details)
        def opening():
            try:self.m.open()
            except ValueError as error:errors.append(error)
        with patch.object(self.m,'_record',side_effect=slow):
            worker=threading.Thread(target=opening);worker.start();self.assertTrue(entered.wait(1))
            self.m.request_close('emergency_stop',latch=True);self.assertTrue(self.m.wait_for_close())
            release.set();worker.join(3)
        self.assertTrue(errors)
        self.assertTrue(all(t.channel_settings[1]['high_time']==.0015 for t in self.tasks))
    def test_disconnect_requests_close_then_releases_without_claiming_position(self):
        self.connect();self.m.open();self.m.disconnect()
        self.assertTrue(all(t.closed for t in self.tasks));state=self.m.snapshot()['shutter']
        self.assertFalse(state['connected']);self.assertFalse(state['pwm_active']);self.assertIsNone(state['actual_position'])
    def test_laser_settings_are_staged_without_any_ni_or_laser_output(self):
        self.m.save_laser({'power_percent':0,'frequency_khz':20,'pulse_width_ns':100})
        laser=self.m.snapshot()['laser'];self.assertFalse(laser['connected']);self.assertEqual(laser['emission_state'],'unknown')
        self.assertIsNone(laser['power_index_percent']);self.assertFalse(laser['settings_applied_to_hardware']);self.assertEqual(self.tasks,[])
        restored=ManualControls(Path(self.temp.name));self.assertEqual(restored.laser_settings['pulse_width_ns'],100)
    def test_invalid_staged_laser_values_do_not_replace_saved_settings(self):
        previous=dict(self.m.laser_settings)
        for values in ({'power_percent':-1},{'power_percent':101},{'power_percent':float('nan')},{'power_percent':1,'pulse_width_ns':0}):
            with self.assertRaises(ValueError):self.m.save_laser(values)
        self.assertEqual(self.m.laser_settings,previous)
    def test_session_emergency_closes_manual_shutter_even_without_a_measurement(self):
        session=GuiSession(Path(self.temp.name));session.manual_controls=self.m;self.connect();self.m.open()
        session.stop('emergency_stop');self.assertTrue(self.m.wait_for_close())
        self.assertEqual(self.m.snapshot()['shutter']['last_command'],'close')
    def test_critical_temperature_requests_close_even_if_measurement_storage_fails(self):
        session=GuiSession(Path(self.temp.name));session.manual_controls=self.m;self.connect();self.m.open()
        text='t_s,'+','.join('TC'+str(i) for i in range(1,9))+'\n0,'+','.join(['120']*8)+'\n'
        with patch('boiling_automation.gui.MeasurementLog.write',side_effect=OSError('disk full')):
            session.start({'source':'csv','csv_text':text,'critical_c':100,'speed':300})
            session.worker.join(3);self.assertFalse(session.worker.is_alive())
        self.assertTrue(self.m.wait_for_close());self.assertEqual(self.m.snapshot()['shutter']['last_command'],'close')
        self.assertIsNotNone(self.m.snapshot()['shutter']['inhibit_reason'])
    def test_discovery_only_reads_counter_capabilities(self):
        dev=SimpleNamespace(name='Dev2',product_type='NI model',dev_is_simulated=False,co_physical_chans=[SimpleNamespace(name='Dev2/ctr0')])
        module=SimpleNamespace(System=SimpleNamespace(local=lambda:SimpleNamespace(devices=[dev])))
        with patch('boiling_automation.manual_controls.importlib.import_module',return_value=module):
            inventory=discover_outputs()
        self.assertEqual(inventory['devices'][0]['counter_channels'],['Dev2/ctr0']);self.assertEqual(self.tasks,[])


class ManualHttpTests(unittest.TestCase):
    def test_output_mutations_require_token_and_laser_commands_cannot_fake_connection(self):
        with tempfile.TemporaryDirectory() as folder:
            server=GuiServer(('127.0.0.1',0),Path(folder));worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
            def request(method,path,payload=None,token=None):
                conn=http.client.HTTPConnection('127.0.0.1',server.server_address[1],timeout=3)
                headers={'Content-Type':'application/json'}
                if token:headers['X-App-Token']=token
                try:
                    conn.request(method,path,None if payload is None else json.dumps(payload),headers);response=conn.getresponse();return response.status,response.read()
                finally:conn.close()
            try:
                self.assertEqual(request('GET','/manual-controls.js')[0],200)
                self.assertEqual(request('POST','/api/manual/shutter',{'action':'open'})[0],403)
                self.assertEqual(request('POST','/api/manual/shutter',{'action':'bad'},server.token)[0],400)
                self.assertEqual(request('POST','/api/manual/laser',{'action':'on','connected':True},server.token)[0],400)
                code,body=request('POST','/api/manual/laser-settings',{'power_percent':0},server.token)
                self.assertEqual(code,200);self.assertFalse(json.loads(body)['manual_controls']['laser']['connected'])
            finally:server.session.stop();server.shutdown();server.server_close();worker.join(3)
