"""Explicit NI shutter commands, independently queued closure, and staged laser settings."""
from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
import importlib
import json
import math
from pathlib import Path
import re
import threading
import time


OPEN_HIGH_S = .0010
CLOSE_HIGH_S = .0015
LOW_S = .0185


def now():
    return datetime.now(timezone(timedelta(hours=9))).isoformat()


def discover_outputs():
    """Enumerate devices/counter outputs without creating or starting a task."""
    try:
        system=importlib.import_module('nidaqmx.system').System.local()
        devices=[]
        for dev in system.devices:
            item={'name':dev.name,'model':dev.product_type,'simulated':dev.dev_is_simulated,
                  'counter_channels':[],'error':None}
            try:item['counter_channels']=[c.name for c in dev.co_physical_chans]
            except Exception as error:item['error']=str(error)
            devices.append(item)
        return {'devices':devices,'checked_at':now()}
    except Exception as error:
        raise ValueError('NI 출력 장치 조회 실패: '+str(error)) from error


@dataclass(frozen=True)
class ShutterSettings:
    counter_channel: str = ''
    output_terminal: str = ''

    @classmethod
    def from_payload(cls,payload):
        if not isinstance(payload,dict):raise ValueError('셔터 NI 설정을 확인하세요.')
        channel=payload.get('counter_channel','');terminal=payload.get('output_terminal','')
        if not isinstance(channel,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}/ctr\d{1,3}',channel):
            raise ValueError('실제 셔터 출력 채널을 장치명/ctr번호 형식으로 선택하세요.')
        if not isinstance(terminal,str) or terminal and not re.fullmatch(r'/?[A-Za-z0-9_-]{1,80}/PFI\d{1,3}',terminal):
            raise ValueError('출력 단자는 /장치명/PFI번호 형식입니다. 비우면 장치 기본 단자를 사용합니다.')
        # A cDAQ chassis counter may route to a module PFI terminal with a
        # different device prefix. DAQmx validates the actual terminal route.
        return cls(channel,terminal)


class NIShutter:
    """Hold a continuous counter pulse train; never create laser/AI/AO/DO tasks."""
    def __init__(self,settings):
        self.settings=settings;self.task=None

    def apply(self,action):
        if action not in ('open','close'):raise ValueError('셔터 열기 또는 닫기를 선택하세요.')
        nidaqmx=importlib.import_module('nidaqmx')
        constants=importlib.import_module('nidaqmx.constants')
        self.release()
        task=nidaqmx.Task()
        try:
            high=OPEN_HIGH_S if action=='open' else CLOSE_HIGH_S
            channel=task.co_channels.add_co_pulse_chan_time(
                self.settings.counter_channel,units=constants.TimeUnits.SECONDS,
                idle_state=constants.Level.LOW,initial_delay=0,high_time=high,low_time=LOW_S)
            if self.settings.output_terminal:channel.co_pulse_term=self.settings.output_terminal
            try:terminal=channel.co_pulse_term
            except Exception:terminal=self.settings.output_terminal or None
            task.timing.cfg_implicit_timing(sample_mode=constants.AcquisitionType.CONTINUOUS)
            task.start()
            self.task=task
            return {'action':action,'high_s':high,'low_s':LOW_S,'period_s':high+LOW_S,'output_terminal':terminal,'output_started_at':now()}
        except BaseException as error:
            try:task.close()
            except Exception as cleanup_error:
                self.task=task
                raise RuntimeError(str(error)+'; NI 출력 태스크 해제 실패: '+str(cleanup_error)) from error
            raise

    def release(self):
        if self.task is not None:
            self.task.close();self.task=None


class ManualControls:
    def __init__(self,root):
        self.root=Path(root);self.state_lock=threading.Lock();self.io_lock=threading.RLock();self.log_lock=threading.Lock()
        self.driver=None;self.close_worker=None;self.pending_close=False;self.close_reason=None
        self.settings=ShutterSettings();self.events=deque(maxlen=40)
        self.laser_settings={'power_percent':0.,'frequency_khz':None,'pulse_width_ns':None}
        self.state={'connected':False,'busy':False,'pwm_active':False,'last_command':None,
                    'last_close_reason':None,
                    'actual_position':None,'position_feedback_available':False,'output_terminal':None,
                    'error':None,'inhibit_reason':None,'close_requested':False}
        path=self.root/'manual_control_settings.json'
        if path.is_file():
            try:
                saved=json.loads(path.read_text(encoding='utf-8'))
                if saved.get('shutter',{}).get('counter_channel'):self.settings=ShutterSettings.from_payload(saved['shutter'])
                self.laser_settings=self.validate_laser_settings(saved.get('laser',self.laser_settings))
            except (ValueError,TypeError,OSError) as error:self.state['error']='수동 설정 불러오기 실패: '+str(error)

    @staticmethod
    def validate_laser_settings(payload):
        if not isinstance(payload,dict):raise ValueError('레이저 수동 설정을 확인하세요.')
        result={}
        for key in ('power_percent','frequency_khz','pulse_width_ns'):
            value=payload.get(key,0 if key=='power_percent' else None)
            if value is None or value=='':
                if key=='power_percent':raise ValueError('레이저 출력 %를 입력하세요.')
                result[key]=None;continue
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):raise ValueError('레이저 설정에 유효한 숫자를 입력하세요.')
            if key=='power_percent' and not 0<=value<=100 or key!='power_percent' and value<=0:raise ValueError('출력은 0~100%, 주파수와 펄스폭은 0보다 커야 합니다.')
            result[key]=float(value)
        return result

    def _save(self,settings=None,laser=None):
        self.root.mkdir(parents=True,exist_ok=True)
        data={'version':1,'shutter':asdict(settings or self.settings),'laser':laser or self.laser_settings,
              'shutter_waveform_s':{'open_high':OPEN_HIGH_S,'close_high':CLOSE_HIGH_S,'low':LOW_S}}
        path=self.root/'manual_control_settings.json';temporary=path.with_name('.manual_settings.tmp')
        try:
            temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
            temporary.replace(path)
        finally:temporary.unlink(missing_ok=True)

    def _record(self,action,details):
        event={'at':now(),'action':action,'details':details}
        self.root.mkdir(parents=True,exist_ok=True)
        with self.log_lock:
            with (self.root/'manual_control_events.jsonl').open('a',encoding='utf-8') as f:
                f.write(json.dumps(event,ensure_ascii=False,allow_nan=False)+'\n');f.flush()
        with self.state_lock:self.events.append(event)

    def snapshot(self):
        with self.state_lock:
            return {'shutter':{**self.state,'configured':self.driver is not None,'settings':asdict(self.settings),
                    'waveform_s':{'open_high':OPEN_HIGH_S,'close_high':CLOSE_HIGH_S,'low':LOW_S}},
                    'laser':{'connected':False,'emission_state':'unknown','power_index_percent':None,
                             'settings':dict(self.laser_settings),'settings_applied_to_hardware':False},
                    'events':list(self.events)}

    def connect(self,payload):
        settings=ShutterSettings.from_payload(payload)
        with self.io_lock:
            if self.driver and self.driver.task is not None:raise ValueError('출력을 해제한 뒤 NI 설정을 변경하세요.')
            inventory=discover_outputs()
            found=[d for d in inventory['devices'] if settings.counter_channel in d['counter_channels']]
            if not found:raise ValueError('선택한 NI 카운터 출력 채널을 찾지 못했습니다. 장치 목록을 다시 조회하세요.')
            if found[0]['simulated']:raise ValueError('실제 셔터에는 시뮬레이션 NI 장치를 사용할 수 없습니다.')
            self._save(settings=settings)
            self._record('shutter_connected',{'settings':asdict(settings),'model':found[0]['model'],'output_started':False})
            with self.state_lock:
                self.settings=settings;self.driver=NIShutter(settings)
                self.state.update(connected=True,error=None,last_command=None,pwm_active=False,output_terminal=None)
        return self.snapshot()

    def save_laser(self,payload):
        settings=self.validate_laser_settings(payload)
        with self.io_lock:
            self._save(laser=settings)
            self._record('laser_settings_saved',{'settings':settings,'sent_to_hardware':False})
            with self.state_lock:self.laser_settings=settings
        return self.snapshot()

    def _perform(self,action,reason):
        attempted=False
        with self.state_lock:
            intended=self.driver
            if intended is None:raise ValueError('5번 탭에서 셔터 NI 출력 채널을 먼저 연결하세요.')
            if action=='open' and (self.state['inhibit_reason'] or self.state['close_requested']):
                raise ValueError('차단 요청이 있어 셔터를 열 수 없습니다. 원인을 해소하고 새 온도 측정을 시작하세요.')
        try:
            # Opening audit happens before I/O. Closing never waits for this disk
            # operation: it uses io_lock only for the NI command itself.
            if action=='open':self._record('shutter_command_requested',{'action':action,'reason':reason})
            with self.io_lock:
                with self.state_lock:
                    if self.driver is None:raise ValueError('셔터 연결이 해제됐습니다.')
                    if action=='open' and (self.driver is not intended or self.state['inhibit_reason'] or self.state['close_requested']):
                        raise ValueError('셔터 연결 또는 차단 상태가 변경되어 열기를 취소했습니다.')
                    self.state['busy']=True
                try:
                    attempted=True
                    result=self.driver.apply(action)
                    with self.state_lock:
                        self.state.update(connected=True,last_command=action,pwm_active=True,
                                          output_terminal=result['output_terminal'],error=None,
                                          last_close_reason=reason if action=='close' else None)
                finally:
                    with self.state_lock:self.state['busy']=False
        except Exception as error:
            with self.state_lock:
                self.state['error']=str(error)
                if attempted:self.state.update(last_command=None,pwm_active=bool(self.driver and self.driver.task is not None))
            raise ValueError('셔터 출력 오류: '+str(error)) from error
        # Audit writes run without io_lock, so a stalled disk cannot block a
        # later emergency close while the shutter is open.
        try:
            if action=='close':self._record('shutter_command_requested',{'action':action,'reason':reason})
            self._record('shutter_command_started',{**result,'reason':reason,'position_confirmed':False})
        except OSError as error:
            if action=='open':self.request_close('opening_log_error',latch=True)
            with self.state_lock:self.state['error']=str(error)
            if action=='open':raise ValueError('셔터 열기 이력 저장 실패 · 닫기를 요청했습니다: '+str(error)) from error

    def open(self):
        self._perform('open','manual')
        # A close request arriving during NI setup has priority over this open.
        with self.state_lock:close_pending=self.pending_close or bool(self.state['inhibit_reason'])
        if close_pending:self.request_close('close_during_open')
        return self.snapshot()

    def request_close(self,reason='manual',*,latch=False):
        with self.state_lock:
            if latch:self.state['inhibit_reason']=reason
            if self.driver is None:return
            if self.state['close_requested']:return
            if self.state['last_command']=='close' and self.state['last_close_reason']==reason and self.state['pwm_active'] and not self.state['busy'] and not self.state['error']:return
            self.pending_close=True;self.close_reason=reason;self.state['close_requested']=True
            if self.close_worker is None or not self.close_worker.is_alive():
                self.close_worker=threading.Thread(target=self._close_loop,daemon=True)
                self.close_worker.start()

    def _close_loop(self):
        while True:
            with self.state_lock:
                if not self.pending_close:
                    self.state['close_requested']=False
                    self.close_worker=None
                    return
                self.pending_close=False;reason=self.close_reason
            try:self._perform('close',reason)
            except ValueError:pass

    def clear_interlock(self):
        with self.state_lock:
            if not self.pending_close and not self.state['close_requested'] and not self.state['busy']:
                self.state['inhibit_reason']=None
                self.state['last_close_reason']=None
                return True
            return False

    def wait_for_close(self,timeout=3):
        with self.state_lock:worker=self.close_worker
        if worker:worker.join(timeout)
        return not worker or not worker.is_alive()

    def disconnect(self):
        with self.state_lock:
            connected=self.driver is not None
        if not connected:return self.snapshot()
        self.request_close('disconnect')
        if not self.wait_for_close():raise ValueError('셔터 닫힘 명령을 처리 중입니다. 잠시 후 다시 시도하세요.')
        with self.io_lock:
            if self.driver:
                # Give the requested close waveform several periods before release.
                time.sleep(.06)
                try:self.driver.release()
                except Exception as error:raise ValueError('NI 출력 해제 실패: '+str(error)) from error
            with self.state_lock:
                self.driver=None;self.state.update(connected=False,pwm_active=False,last_command=None)
            self._record('shutter_output_released',{'actual_position':'unknown'})
        return self.snapshot()

