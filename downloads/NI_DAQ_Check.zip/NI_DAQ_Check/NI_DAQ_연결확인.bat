@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
    py -3 check_ni_daq.py
    goto finished
)
where python >nul 2>&1
if not errorlevel 1 (
    python check_ni_daq.py
    goto finished
)
echo Python 3.10 이상이 필요합니다. v13 실행에 사용한 Python을 설치해 주세요.
:finished
echo.
echo 생성된 NI_DAQ_진단결과.txt 또는 .json 파일을 대화에 첨부해 주세요.
pause
