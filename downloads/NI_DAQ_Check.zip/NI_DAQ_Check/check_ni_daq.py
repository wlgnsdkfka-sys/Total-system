"""Collect NI-DAQmx device metadata on the measurement PC; never open a task."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import importlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys


def describe_error(stage, error):
    return {
        "stage": stage,
        "type": type(error).__name__,
        "code": getattr(error, "error_code", None),
        "message": str(error),
    }


def collect_inventory():
    report = {
        "tool": "NI DAQ connection check 1.0",
        "checked_at": datetime.now(timezone(timedelta(hours=9))).isoformat(),
        "python": platform.python_version(),
        "operating_system": platform.system(),
        "status": "not_checked",
        "nidaqmx_python_version": None,
        "driver_version": None,
        "devices": [],
        "errors": [],
        "warnings": [],
        "temperature_read_performed": False,
        "output_commands_sent": False,
    }
    try:
        importlib.import_module("nidaqmx")
        system_module = importlib.import_module("nidaqmx.system")
    except Exception as error:
        report["status"] = "python_package_unavailable"
        report["errors"].append(describe_error("import_nidaqmx", error))
        return report
    try:
        report["nidaqmx_python_version"] = importlib.metadata.version("nidaqmx")
    except importlib.metadata.PackageNotFoundError:
        pass
    try:
        system = system_module.System.local()
        version = system.driver_version
        report["driver_version"] = ".".join(str(getattr(version, key)) for key in (
            "major_version", "minor_version", "update_version"))
        devices = list(system.devices)
    except Exception as error:
        report["status"] = "driver_or_device_enumeration_failed"
        report["errors"].append(describe_error("load_driver_and_list_devices", error))
        return report
    for device in devices:
        item = {"name": device.name, "product_type": None, "simulated": None,
                "analog_input_channels": [], "supported_ai_measurements": None,
                "thermocouple_supported": None, "errors": []}
        for prop, key in (("product_type", "product_type"), ("dev_is_simulated", "simulated")):
            try:
                item[key] = getattr(device, prop)
            except Exception as error:
                item["errors"].append(describe_error(prop, error))
        try:
            item["analog_input_channels"] = [channel.name for channel in device.ai_physical_chans]
        except Exception as error:
            item["errors"].append(describe_error("analog_input_channels", error))
        try:
            names = [getattr(value, "name", str(value)) for value in device.ai_meas_types]
            item["supported_ai_measurements"] = names
            item["thermocouple_supported"] = "TEMPERATURE_THERMOCOUPLE" in names
        except Exception as error:
            # A chassis or an output-only device may not expose AI capabilities.
            item["errors"].append(describe_error("supported_ai_measurements", error))
        report["devices"].append(item)
    report["status"] = "inventory_complete" if devices else "no_devices_found"
    if devices and not any(device["simulated"] is False for device in report["devices"]):
        report["warnings"].append("시뮬레이션 장치 또는 실제 장치 여부를 확인하지 못한 장치만 발견했습니다.")
    return report


def report_text(report):
    lines = ["NI TC DAQ 연결 진단", "=" * 50,
             "확인 시각: " + report["checked_at"],
             "운영체제: " + report["operating_system"],
             "Python: " + report["python"],
             "Python nidaqmx: " + str(report["nidaqmx_python_version"] or "확인 안 됨"),
             "NI-DAQmx 드라이버: " + str(report["driver_version"] or "확인 안 됨"),
             "상태: " + report["status"], ""]
    if report["status"] == "python_package_unavailable":
        lines += ["Python nidaqmx를 불러오지 못했습니다. 아래 오류를 확인하고 설치한 뒤 다시 실행하세요.",
                  '"' + sys.executable + '" -m pip install "nidaqmx>=0.9,<2"',
                  "NI-DAQmx 드라이버는 Python 패키지와 별도로 필요합니다.", ""]
    if report["status"] == "no_devices_found":
        lines += ["발견한 NI 장치가 없습니다. 전원·USB/네트워크·NI MAX 인식을 확인하세요.", ""]
    for device in report["devices"]:
        lines += ["장치 이름: " + device["name"],
                  "모델: " + str(device["product_type"]),
                  "시뮬레이션 장치: " + str(device["simulated"]),
                  "열전대 측정 지원: " + str(device["thermocouple_supported"]),
                  "아날로그 입력: " + (", ".join(device["analog_input_channels"]) or "없음/확인 불가")]
        for error in device["errors"]:
            lines.append("장치 정보 오류: " + json.dumps(error, ensure_ascii=False))
        lines.append("")
    for warning in report["warnings"]:
        lines.append("주의: " + warning)
    for error in report["errors"]:
        lines.append("오류: " + json.dumps(error, ensure_ascii=False))
    lines += ["", "이 진단은 장치 정보만 조회합니다. 온도 입력 태스크도 생성하지 않습니다.",
              "레이저·셔터 명령이나 AO/DO/카운터 출력은 보내지 않습니다.",
              "장치 인식은 실제 TC 온도·배선·정확도가 검증됐다는 의미가 아닙니다.",
              "열전대 종류는 하드웨어 조회만으로 확정할 수 없으므로 실제 종류를 알려주세요.",
              "이 TXT 또는 JSON 파일을 대화에 첨부해 주세요."]
    return "\n".join(lines) + "\n"


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    report = collect_inventory()
    text = report_text(report)
    print(text)
    output = Path(__file__).resolve().parent
    try:
        (output / "NI_DAQ_진단결과.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (output / "NI_DAQ_진단결과.txt").write_text(text, encoding="utf-8-sig")
    except OSError as error:
        print("진단 파일 저장 실패: " + str(error))
        print("ZIP을 압축 해제하고 쓰기 가능한 폴더에서 실행하세요.")
        return 1
    print("진단 파일 저장 위치: " + str(output))
    return 0 if report["status"] == "inventory_complete" else 1


if __name__ == "__main__":
    raise SystemExit(main())
