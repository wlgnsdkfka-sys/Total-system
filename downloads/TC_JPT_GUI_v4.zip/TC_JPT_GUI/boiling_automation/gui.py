"""Local browser GUI for the offline experiment core. Standard library only."""

from __future__ import annotations

import argparse
from collections import deque
import csv
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import math
from pathlib import Path
import secrets
import threading
from urllib.parse import parse_qs, urlparse
import uuid
import webbrowser
import zipfile

from .core import CHANNELS, BULK_CHANNELS, Config, Event, Reading, ReplayController, _interval, _statistics
from .boiling import curve_csv, import_curve_csv, prepare_curve
from .calculation import calculate_stage, default_settings, validate_settings
from .leak import FluxMonitor, LeakConfig


ROOT = Path(__file__).resolve().parent.parent
SEOUL = timezone(timedelta(hours=9))
MAX_REQUEST_BYTES = 20 * 1024 * 1024
RESULT_FILES = ("run.json", "events.jsonl", "stages.csv", "selected_samples.csv")


def record_summary(record):
    result = asdict(record)
    result.pop("selected_samples")
    return result


class ResultWriter:
    def __init__(self, directory: Path, config: Config, source: str, monitor=None):
        self.directory = directory
        directory.mkdir(parents=True, exist_ok=False)
        self.streams = []
        self.closed = False
        try:
            (directory / "run.json").write_text(json.dumps({
                "mode": "offline_gui", "hardware_connected": False,
                "version": "4.0.0", "standard_deviation": "sample_N_minus_1",
                "created_at": datetime.now(SEOUL).isoformat(),
                "source": source, "config": asdict(config),
                "leak_detection": asdict(monitor.config) if monitor else asdict(LeakConfig()),
                "calculation_settings": monitor.settings if monitor else None,
            }, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
            self.events = self._open("events.jsonl")
            self.stages = self._open("stages.csv", newline="")
            self.samples = self._open("selected_samples.csv", newline="")
            self.stage_csv = csv.writer(self.stages)
            self.sample_csv = csv.writer(self.samples)
            self.stage_csv.writerow([
                "power_percent", "recorded_at_s", "start_s", "end_s", "completion_reason",
                "selected_worst_range_c", "current_worst_range_c", *[f"{c}_mean_c" for c in CHANNELS],
                "selected_max_std_c", "current_max_std_c", *[f"{c}_std_c" for c in CHANNELS],
            ])
            self.sample_csv.writerow(["power_percent", "recorded_at_s", "t_s", "interpolated", *CHANNELS, *BULK_CHANNELS])
            self.flush()
        except Exception:
            self.close()
            raise

    def _open(self, name, **kwargs):
        stream = (self.directory / name).open("w", encoding="utf-8", **kwargs)
        self.streams.append(stream)
        return stream

    def write(self, events):
        for event in events:
            if event.kind == "observation_recorded":
                record = event.details["record"]
                self.stage_csv.writerow([
                    record.power_percent, record.recorded_at_s,
                    record.segment.start_s, record.segment.end_s, record.completion_reason,
                    record.segment.worst_range_c, record.current_range_c,
                    *[c.mean_c for c in record.segment.channels],
                    record.segment.worst_std_c, record.current_std_c,
                    *[c.std_c for c in record.segment.channels],
                ])
                for point in record.selected_samples:
                    self.sample_csv.writerow([
                        record.power_percent, record.recorded_at_s,
                        point.t_s, point.interpolated, *point.temperatures_c,
                        *(point.bulk_temperatures_c or (None,) * 4),
                    ])
                # A stage's sample files are flushed before its subsequent event.
                self.stages.flush()
                self.samples.flush()
            payload = asdict(event)
            if event.kind == "observation_recorded":
                payload["details"]["record"].pop("selected_samples")
            self.events.write(json.dumps(payload, ensure_ascii=False, allow_nan=False) + "\n")
            self.events.flush()

    def flush(self):
        for stream in self.streams:
            if not stream.closed:
                stream.flush()

    def close(self):
        if not self.closed:
            for stream in self.streams:
                stream.close()
            self.closed = True


def csv_readings(text: str):
    reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
    fields = reader.fieldnames
    if not fields or not {"t_s", *CHANNELS}.issubset(fields):
        raise ValueError("CSV에는 t_s, TC1~TC8 열이 필요합니다.")
    if len(set(fields)) != len(fields):
        raise ValueError("CSV 열 이름이 중복되어 있습니다.")
    for row in reader:
        try:
            bulk = tuple(None if row.get(c) in (None, "") else float(row[c]) for c in BULK_CHANNELS)
            if any(v is not None and not math.isfinite(v) for v in bulk):
                raise ValueError("TC9~12 값은 유한한 숫자 또는 빈칸이어야 합니다.")
            yield Reading(float(row["t_s"]), tuple(float(row[c]) for c in CHANNELS), bulk_temperatures_c=bulk)
        except (ValueError, TypeError) as error:
            raise ValueError(f"CSV {reader.line_num}행의 온도 또는 시각을 확인하세요.") from error


class GuiSession:
    def __init__(self, results_root: Path):
        self.results_root = results_root
        self.lock = threading.RLock()
        self.controller = None
        self.writer = None
        self.worker = None
        self.cancel = threading.Event()
        self.generation = 0
        self.running = False
        self.history = deque(maxlen=361)
        self.std_history = deque(maxlen=361)
        self.current_channel_std = None
        self.events = deque(maxlen=100)
        self.last_reading = None
        self.first_t = None
        self.step_start = None
        self.current_range = None
        self.current_std = None
        self.reason = None
        self.error = None
        self.source = "demo"
        self.speed = 1
        self.injected_channel = None
        self.curve = None
        self.calculation_settings = default_settings()
        self.leak_config = LeakConfig()
        settings_file = results_root / "calculation_settings.json"
        if settings_file.is_file():
            self.calculation_settings = validate_settings(json.loads(settings_file.read_text(encoding="utf-8")))
        leak_file = results_root / "leak_settings.json"
        if leak_file.is_file():
            self.leak_config = LeakConfig.from_payload(json.loads(leak_file.read_text(encoding="utf-8")))

    def start(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("실험 설정 형식이 올바르지 않습니다.")
        leak_config = LeakConfig.from_payload(payload["leak_detection"]) if "leak_detection" in payload else self.leak_config
        try:
            critical = float(payload["critical_c"])
            allowed = payload.get("allowed_std_c")
            allowed = None if allowed in (None, "") else float(allowed)
            maximum = payload.get("max_power_percent", 100)
            if isinstance(maximum, bool) or float(maximum) != int(maximum):
                raise ValueError("최대 출력은 정수여야 합니다.")
            maximum = int(maximum)
            speed = float(payload.get("speed", 1))
            if speed not in (1, 10, 60, 300):
                raise ValueError("지원하는 재생 속도를 선택하세요.")
            config = Config(critical, allowed_std_c=allowed, max_power_percent=maximum)
        except (KeyError, TypeError, ValueError, OverflowError) as error:
            raise ValueError(f"온도·허용 변동폭·최대 출력을 확인하세요. {error}") from error
        source = payload.get("source", "demo")
        if source not in ("demo", "csv"):
            raise ValueError("현재 가상 장치와 CSV 재생만 지원합니다.")
        text = payload.get("csv_text", "")
        if source == "csv":
            if not isinstance(text, str) or not text.strip():
                raise ValueError("재생할 CSV 파일을 선택하세요.")
            # Validate the header/first row before creating a run or launching a worker.
            probe = csv_readings(text)
            try:
                next(probe)
            except StopIteration as error:
                raise ValueError("CSV에 온도 데이터가 없습니다.") from error
            finally:
                probe.close()
        with self.lock:
            if self.running:
                raise ValueError("실행 중인 실험을 먼저 중지하세요.")
            self.cancel.set()
            if self.writer:
                self.writer.close()
            name = datetime.now(SEOUL).strftime("run_%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:8]
            monitor = FluxMonitor(leak_config, self.calculation_settings)
            writer = ResultWriter(self.results_root / name, config, source, monitor)
            self.writer = writer
            self.controller = ReplayController(config, flux_monitor=monitor)
            self.cancel = threading.Event()
            self.generation += 1
            generation, cancel, controller = self.generation, self.cancel, self.controller
            self.history.clear()
            self.std_history.clear()
            self.current_channel_std = None
            self.events.clear()
            self.last_reading = self.first_t = self.step_start = self.current_range = None
            self.current_std = None
            self.reason = self.error = self.injected_channel = None
            self.source, self.speed, self.running = source, speed, True
            self.worker = threading.Thread(
                target=self._run, args=(generation, cancel, controller, writer, source, speed, text), daemon=True
            )
            self.worker.start()
        return self.snapshot()

    def _demo_reading(self, second, previous, controller):
        values = []
        for i in range(8):
            target = 25 + i * 0.2 + controller.power_percent * (1.4 + i * 0.045)
            prior = previous[i] if previous else 25 + i * 0.2
            value = prior + (target - prior) * (1 - math.exp(-1 / (8 + i * 1.2)))
            values.append(value + 0.008 * math.sin(second * 0.37 + i))
        bulk = tuple(25 + controller.power_percent * .08 + i * .05 + .01 * math.sin(second * .1 + i) for i in range(4))
        return Reading(float(second), tuple(values), bulk_temperatures_c=bulk)

    def _run(self, generation, cancel, controller, writer, source, speed, text):
        rows = csv_readings(text) if source == "csv" else None
        second, previous, previous_t = 0, None, None
        try:
            while not cancel.is_set():
                if rows is not None:
                    try:
                        reading = next(rows)
                    except StopIteration:
                        with self.lock:
                            if generation == self.generation:
                                self._events(controller.finish())
                                self.running = False
                        break
                else:
                    reading = self._demo_reading(second, previous, controller)
                    previous = reading.temperatures_c
                    second += 1
                delay = 0 if previous_t is None else max(0, reading.t_s - previous_t) / speed
                # Invalid timestamps are handled by the core, without an infinite wait.
                if not math.isfinite(delay):
                    delay = 0
                if cancel.wait(min(delay, 2.0)):
                    break
                with self.lock:
                    if generation != self.generation or cancel.is_set() or controller.terminal:
                        break
                    if self.injected_channel is not None:
                        temperatures = list(reading.temperatures_c)
                        temperatures[self.injected_channel] = controller.config.critical_c + 1
                        reading = Reading(reading.t_s, tuple(temperatures), bulk_temperatures_c=reading.bulk_temperatures_c)
                        self.injected_channel = None
                    events = controller.process(reading)
                    valid = (math.isfinite(reading.t_s) and len(reading.temperatures_c) == 8
                             and all(math.isfinite(v) for v in reading.temperatures_c))
                    if valid:
                        self.first_t = reading.t_s if self.first_t is None else self.first_t
                        self.last_reading = reading
                        self.history.append(reading)
                    self._events(events)
                    self._update_range()
                    if valid:
                        self.std_history.append({"t_s": reading.t_s, "power_percent": controller.power_percent,
                                                 "values_c": self.current_channel_std})
                    if controller.terminal:
                        self.running = False
                        break
                previous_t = reading.t_s
        except Exception as error:
            with self.lock:
                if generation == self.generation:
                    self.error = str(error)
                    self.running = False
                    try:
                        self._events(controller.abort("input_or_storage_error"))
                    except OSError:
                        self.reason = "input_or_storage_error"
        finally:
            if rows is not None:
                rows.close()
            with self.lock:
                writer.close()

    def _events(self, events):
        # Write first: a file error prevents processing further planned increases.
        self.writer.write(events)
        for event in events:
            compact = {"kind": event.kind, "t_s": event.t_s, "details": dict(event.details)}
            if event.kind == "observation_recorded":
                compact["details"]["record"] = record_summary(event.details["record"])
            if event.kind in ("simulated_step_started", "simulated_power_increased"):
                self.step_start = event.t_s
            if event.kind == "shutdown_required":
                self.reason = event.details["reason"]
                self.cancel.set()
            self.events.append(compact)

    def _update_range(self):
        self.current_range = None
        self.current_std = None
        self.current_channel_std = None
        if not self.last_reading or self.step_start is None:
            return
        end = self.last_reading.t_s
        if end - self.step_start < 20:
            return
        points = [p for p in self.history if p.t_s >= self.step_start]
        if not points or points[0].t_s > end - 20:
            return
        statistics = _statistics(_interval(points, end - 20, end))
        self.current_range = max(c.range_c for c in statistics)
        self.current_std = max(c.std_c for c in statistics)
        self.current_channel_std = [c.std_c for c in statistics]

    def stop(self, reason="user_stop"):
        with self.lock:
            if self.controller and self.running:
                self.cancel.set()
                try:
                    self._events(self.controller.abort(reason))
                except OSError as error:
                    self.error = str(error)
                    self.reason = "input_or_storage_error"
                finally:
                    self.running = False
                    self.writer.close()
        return self.snapshot()

    def inject(self, channel=7):
        with self.lock:
            if not self.running or self.source != "demo":
                raise ValueError("가상 장치 실행 중에만 임계온도 시험을 할 수 있습니다.")
            if type(channel) is not int or not 0 <= channel < 8:
                raise ValueError("TC1~TC8 중 하나를 선택하세요.")
            self.injected_channel = channel
        return {"ok": True}

    def snapshot(self):
        with self.lock:
            controller = self.controller
            end = self.last_reading.t_s if self.last_reading else None
            return {
                "hardware_connected": False, "source": self.source,
                "running": self.running, "state": controller.state if controller else "idle",
                "reason": self.reason, "error": self.error, "speed": self.speed,
                "config": asdict(controller.config) if controller else None,
                "power_percent": controller.power_percent if controller else 0,
                "elapsed_s": max(0, end - self.first_t) if end is not None else 0,
                "step_elapsed_s": max(0, end - self.step_start) if end is not None and self.step_start is not None else 0,
                "latest": asdict(self.last_reading) if self.last_reading else None,
                "current_range_c": self.current_range,
                "current_std_c": self.current_std,
                "current_channel_std_c": self.current_channel_std,
                "std_history": list(self.std_history),
                "leak_detection": controller.flux_monitor.snapshot() if controller and controller.flux_monitor else None,
                "saturation_c": self.calculation_settings["saturation_c"],
                "history": [asdict(p) for p in self.history],
                "records": [record_summary(r) for r in controller.records] if controller else [],
                "events": list(self.events),
                "result_folder": str(self.writer.directory) if self.writer else None,
                "run_name": self.writer.directory.name if self.writer else None,
            }

    def record(self, index):
        with self.lock:
            if not self.controller or index < 0 or index >= len(self.controller.records):
                raise ValueError("선택한 기록이 없습니다.")
            return asdict(self.controller.records[index])

    def export(self):
        with self.lock:
            if not self.writer:
                raise ValueError("먼저 가상 실험 또는 CSV 재생을 실행하세요.")
            self.writer.flush()
            result = io.BytesIO()
            with zipfile.ZipFile(result, "w", zipfile.ZIP_DEFLATED) as archive:
                for name in RESULT_FILES:
                    archive.write(self.writer.directory / name, arcname=name)
            return result.getvalue(), self.writer.directory.name + ".zip"

    def prepare_curve(self, payload):
        result = prepare_curve(payload)
        with self.lock:
            self.curve = result
        return result

    def export_curve(self):
        with self.lock:
            if self.curve is None:
                raise ValueError("보일링 커브를 먼저 그려주세요.")
            return curve_csv(self.curve)

    def save_settings(self, payload):
        settings = validate_settings(payload)
        with self.lock:
            if self.running:
                raise ValueError("실행 중에는 계산 상수를 변경할 수 없습니다. 실험을 중지한 뒤 저장하세요.")
            if self.leak_config.enabled and any(settings[k] != self.calculation_settings[k] for k in ("bands", "flux_sign")):
                raise ValueError("누수 감지를 끄고 저장한 뒤 열유속 계산식을 변경하세요. 변경 후 계산식을 다시 확인하고 감지를 켜세요.")
            self.results_root.mkdir(parents=True, exist_ok=True)
            path = self.results_root / "calculation_settings.json"
            temporary = path.with_name("calculation_settings_" + uuid.uuid4().hex + ".tmp")
            try:
                temporary.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")
                temporary.replace(path)
            finally:
                temporary.unlink(missing_ok=True)
            self.calculation_settings = settings
        return settings

    def save_leak_settings(self, payload):
        config = LeakConfig.from_payload(payload)
        with self.lock:
            if self.running:
                raise ValueError("실행 중에는 누수 감지 설정을 변경할 수 없습니다. 먼저 실험을 중지하세요.")
            self.results_root.mkdir(parents=True, exist_ok=True)
            path = self.results_root / "leak_settings.json"
            temporary = path.with_name("leak_settings_" + uuid.uuid4().hex + ".tmp")
            try:
                temporary.write_text(json.dumps(asdict(config), ensure_ascii=False, indent=2), encoding="utf-8")
                temporary.replace(path)
            finally:
                temporary.unlink(missing_ok=True)
            self.leak_config = config
        return asdict(config)

    def curve_from_records(self):
        with self.lock:
            if not self.controller or not self.controller.records:
                raise ValueError("온도 기록이 먼저 필요합니다. 가상 실험 또는 CSV 재생을 실행하세요.")
            settings = self.calculation_settings
            rows = [calculate_stage(record, settings) for record in self.controller.records]
            result = prepare_curve({"saturation_c": settings["saturation_c"],
                                    "heat_flux_unit": "W/cm2", "rows": rows})
            result["calculation_settings"] = settings
            result["source"] = "Average Temp / Total Flux · 선택 구간 샘플별 계산"
            self.curve = result
            return {"curve": result, "rows": rows}


class GuiServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, results_root):
        self.session = GuiSession(Path(results_root))
        self.token = secrets.token_urlsafe(32)
        super().__init__(address, GuiHandler)

    @property
    def origin(self):
        return f"http://127.0.0.1:{self.server_address[1]}"


class GuiHandler(BaseHTTPRequestHandler):
    server_version = "BoilingGUI/1.0"

    def log_message(self, format, *args):
        pass

    def _send(self, status, body, content_type="application/json; charset=utf-8", **headers):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for name, value in headers.items():
            self.send_header(name.replace("_", "-"), value)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, value, status=200):
        self._send(status, json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8"))

    def _local_request(self):
        expected_host = f"127.0.0.1:{self.server.server_address[1]}"
        if self.headers.get("Host") != expected_host:
            self._json({"error": "허용되지 않은 호스트입니다."}, 403)
            return False
        origin = self.headers.get("Origin")
        if origin and origin != self.server.origin:
            self._json({"error": "이 프로그램 창에서 실행하세요."}, 403)
            return False
        return True

    def do_GET(self):
        if not self._local_request():
            return
        url = urlparse(self.path)
        try:
            if url.path == "/":
                self._send(200, (Path(__file__).parent / "web" / "index.html").read_bytes(), "text/html; charset=utf-8")
            elif url.path in ("/analysis.js", "/leak.js"):
                self._send(200, (Path(__file__).parent / "web" / url.path[1:]).read_bytes(), "application/javascript; charset=utf-8")
            elif url.path == "/api/bootstrap":
                self._json({"token": self.server.token, "hardware_connected": False})
            elif url.path == "/api/state":
                self._json(self.server.session.snapshot())
            elif url.path == "/api/record":
                index = int(parse_qs(url.query).get("index", ["-1"])[0])
                self._json(self.server.session.record(index))
            elif url.path == "/api/export":
                body, filename = self.server.session.export()
                self._send(200, body, "application/zip", Content_Disposition=f'attachment; filename="{filename}"')
            elif url.path == "/api/boiling/export":
                self._send(200, self.server.session.export_curve(), "text/csv; charset=utf-8",
                           Content_Disposition='attachment; filename="boiling_curve.csv"')
            elif url.path == "/api/calculation":
                self._json(self.server.session.calculation_settings)
            elif url.path == "/api/leak-settings":
                self._json(asdict(self.server.session.leak_config))
            elif url.path == "/api/calculation/reference":
                self._json(default_settings())
            elif url.path == "/api/boiling/export-zip":
                with self.server.session.lock:
                    body = self.server.session.export_curve()
                    output = io.BytesIO()
                    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
                        archive.writestr("boiling_curve.csv", body)
                        archive.writestr("settings.json", json.dumps(self.server.session.curve, ensure_ascii=False, indent=2, allow_nan=False))
                    self._send(200, output.getvalue(), "application/zip", Content_Disposition='attachment; filename="boiling_curve.zip"')
            elif url.path == "/favicon.ico":
                self._send(204, b"", "image/x-icon")
            else:
                self._json({"error": "찾을 수 없는 요청입니다."}, 404)
        except (ValueError, OSError) as error:
            self._json({"error": str(error)}, 400)

    def do_POST(self):
        if not self._local_request():
            return
        if not secrets.compare_digest(self.headers.get("X-App-Token", ""), self.server.token):
            self._json({"error": "프로그램 창을 새로 열고 다시 시도하세요."}, 403)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 <= size <= MAX_REQUEST_BYTES:
                raise ValueError("파일 크기가 너무 큽니다. 20MB 이하의 CSV를 사용하세요.")
            data = json.loads(self.rfile.read(size) or b"{}")
            path = urlparse(self.path).path
            if path == "/api/start":
                self._json(self.server.session.start(data))
            elif path == "/api/stop":
                self._json(self.server.session.stop())
            elif path == "/api/emergency":
                self._json(self.server.session.stop("emergency_stop"))
            elif path == "/api/inject":
                if not isinstance(data, dict):
                    raise ValueError("시험 요청 형식이 올바르지 않습니다.")
                self._json(self.server.session.inject(data.get("channel", 7)))
            elif path == "/api/boiling":
                self._json(self.server.session.prepare_curve(data))
            elif path == "/api/boiling/import":
                if not isinstance(data, dict):
                    raise ValueError("CSV 입력 형식이 올바르지 않습니다.")
                self._json(import_curve_csv(data.get("csv_text"), data.get("heat_flux_unit", "W/cm2")))
            elif path == "/api/calculation":
                self._json(self.server.session.save_settings(data))
            elif path == "/api/leak-settings":
                self._json(self.server.session.save_leak_settings(data))
            elif path == "/api/boiling/from-records":
                self._json(self.server.session.curve_from_records())
            elif path == "/api/shutdown":
                self.server.session.stop("application_closed")
                self._json({"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
            else:
                self._json({"error": "찾을 수 없는 요청입니다."}, 404)
        except (ValueError, TypeError, UnicodeDecodeError, OSError) as error:
            self._json({"error": str(error)}, 400)


def main(argv=None):
    parser = argparse.ArgumentParser(description="TC/JPT local GUI; simulation and CSV replay only")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--results", type=Path, default=ROOT / "results")
    args = parser.parse_args(argv)
    server = GuiServer(("127.0.0.1", args.port), args.results)
    if not args.no_browser:
        webbrowser.open(server.origin)
    print("TC / JPT GUI를 시작했습니다. 브라우저의 프로그램 종료 버튼 또는 Ctrl+C로 종료하세요.", flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.session.stop("application_closed")
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
