@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
    py -3 check_ni_tc.py
    goto finished
)
where python >nul 2>&1
if not errorlevel 1 (
    python check_ni_tc.py
    goto finished
)
echo Python 3.10 이상이 필요합니다.
:finished
echo.
echo NI_TC_온도진단결과.json 또는 .txt 파일을 대화에 첨부해 주세요.
pause
