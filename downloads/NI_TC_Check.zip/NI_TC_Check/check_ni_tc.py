"""Read each configured NI-9213 K-type input independently for diagnosis."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import csv
import importlib
import json
import math
from pathlib import Path
import sys
import time

from check_ni_daq import collect_inventory, describe_error


MODULE = "cDAQ1Mod3"
CHANNELS = tuple(f"{MODULE}/ai{i}" for i in (0, 1, 2, 3, 4, 5, 6, 7, 15, 14, 13, 12))
MINIMUM_C = 0.0
MAXIMUM_C = 300.0
SAMPLES_PER_CHANNEL = 3


def now():
    return datetime.now(timezone(timedelta(hours=9))).isoformat()


def collect_temperatures():
    report = {
        "tool": "NI-9213 K-type per-channel temperature check 1.0",
        "started_at": now(), "finished_at": None,
        "module": MODULE, "thermocouple_type": "K", "cjc": "built_in",
        "minimum_c": MINIMUM_C, "maximum_c": MAXIMUM_C,
        "sampling": "Sequential channel diagnosis; readings are not simultaneous.",
        "temperature_unit": "degC", "status": "not_started",
        "temperature_tasks_started": 0, "output_commands_sent": False,
        "inventory": collect_inventory(), "channels": [], "errors": [],
    }
    try:
        device = next((d for d in report["inventory"]["devices"] if d["name"] == MODULE), None)
        if device is None:
            raise ValueError(f"{MODULE}을 찾지 못했습니다. 연결 진단 결과의 실제 모듈 이름을 확인하세요.")
        if device["simulated"] is not False or "9213" not in str(device["product_type"]):
            raise ValueError("이 도구는 실제 NI-9213 모듈용입니다. 장치 모델과 시뮬레이션 여부를 확인하세요.")
        if not set(CHANNELS).issubset(device["analog_input_channels"]):
            raise ValueError("설정한 입력 채널 일부가 실제 모듈에 없습니다.")
        nidaqmx = importlib.import_module("nidaqmx")
        constants = importlib.import_module("nidaqmx.constants")
        report["status"] = "collecting"
        for i, physical in enumerate(CHANNELS):
            row = {"tc": f"TC{i+1}", "physical_channel": physical,
                   "bulk": i >= 8, "samples": [], "errors": []}
            report["channels"].append(row)
            print(f"{row['tc']} · {physical} 확인 중...", flush=True)
            try:
                with nidaqmx.Task() as task:
                    task.ai_channels.add_ai_thrmcpl_chan(
                        physical, name_to_assign_to_channel=row["tc"],
                        min_val=MINIMUM_C, max_val=MAXIMUM_C,
                        units=constants.TemperatureUnits.DEG_C,
                        thermocouple_type=constants.ThermocoupleType.K,
                        cjc_source=constants.CJCSource.BUILT_IN)
                    task.start()
                    report["temperature_tasks_started"] += 1
                    for n in range(SAMPLES_PER_CHANNEL):
                        value = task.read(timeout=2.0)
                        # One AI channel must return one scalar (or a singleton).
                        if isinstance(value, (list, tuple)):
                            if len(value) != 1:
                                raise ValueError("단일 TC 채널에서 온도 하나를 받지 못했습니다.")
                            value = value[0]
                        value = float(value)
                        finite = math.isfinite(value)
                        status = ("non_finite" if not finite else "within_range"
                                  if MINIMUM_C <= value <= MAXIMUM_C else "out_of_range")
                        sample = {"sample_index": n+1, "observed_at": now(),
                                  "temperature_c": value if finite else None,
                                  "raw_value_text": repr(value), "status": status}
                        row["samples"].append(sample)
                        print(f"  {value:g} °C · {status}", flush=True)
                        if n+1 < SAMPLES_PER_CHANNEL:
                            time.sleep(0.2)
            except Exception as error:
                row["errors"].append(describe_error("read_channel", error))
                print("  읽기 오류: " + str(error), flush=True)
                # A failed/open channel must not hide the other channel results.
        problematic = any(r["errors"] or any(s["status"] != "within_range" for s in r["samples"])
                          for r in report["channels"])
        report["status"] = "completed_with_channel_issues" if problematic else "completed_within_range"
    except KeyboardInterrupt:
        report["status"] = "interrupted"
    except Exception as error:
        report["status"] = "failed"
        report["errors"].append(describe_error("temperature_check", error))
    finally:
        report["finished_at"] = now()
    return report


def summary_text(report):
    lines = ["NI-9213 K타입 채널별 원시온도 확인", "="*55,
             "시작: " + report["started_at"], "종료: " + str(report["finished_at"]),
             "상태: " + report["status"], "판정 범위: 0~300°C (v13 기본 범위)",
             "각 채널을 순서대로 읽었으며 같은 시각의 실험 데이터가 아닙니다.", ""]
    for row in report["channels"]:
        lines.append(row["tc"] + (" bulk" if row["bulk"] else "") + " · " + row["physical_channel"])
        for sample in row["samples"]:
            lines.append("  " + sample["raw_value_text"] + " °C · " + sample["status"])
        for error in row["errors"]:
            lines.append("  오류: " + json.dumps(error, ensure_ascii=False))
    for error in report["errors"]:
        lines.append("오류: " + json.dumps(error, ensure_ascii=False))
    lines += ["", "out_of_range = 설정 범위 밖, non_finite = 숫자로 사용할 수 없는 값입니다.",
              "범위 내 값이라고 배선·정확도·극성이 검증된 것은 아닙니다.",
              "범위 밖 값은 미연결·단선·극성·단자 순서·실제 온도를 대조해야 합니다.",
              "이 결과로 범위를 자동 확대하거나 보정값을 변경하지 않습니다.",
              "이 도구는 열전대 입력만 읽으며 레이저·셔터·AO/DO/카운터 출력은 제어하지 않습니다.",
              "생성된 NI_TC_온도진단결과.json 또는 .txt를 대화에 첨부하세요."]
    return "\n".join(lines) + "\n"


def save_report(report, output):
    (output / "NI_TC_온도진단결과.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    (output / "NI_TC_온도진단결과.txt").write_text(summary_text(report), encoding="utf-8-sig")
    fields = ("tc", "physical_channel", "sample_index", "observed_at", "temperature_c", "status", "error")
    with (output / "NI_TC_원시온도.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in report["channels"]:
            for sample in row["samples"]:
                writer.writerow({"tc": row["tc"], "physical_channel": row["physical_channel"],
                                 **{key: sample[key] for key in fields[2:6]}})
            for error in row["errors"]:
                writer.writerow({"tc": row["tc"], "physical_channel": row["physical_channel"],
                                 "status": "read_error", "error": json.dumps(error, ensure_ascii=False)})


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("NI-9213 / cDAQ1Mod3 / K타입 원시온도 확인", flush=True)
    print("v13과 LabVIEW, NI MAX 테스트 패널의 측정을 먼저 중지하세요.", flush=True)
    report = collect_temperatures()
    try:
        save_report(report, Path(__file__).resolve().parent)
    except OSError as error:
        print("결과 저장 실패: " + str(error))
        return 1
    print(summary_text(report))
    return 0 if report["status"].startswith("completed_") else 1


if __name__ == "__main__":
    raise SystemExit(main())
