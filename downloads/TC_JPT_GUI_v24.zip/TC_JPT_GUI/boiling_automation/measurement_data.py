"""Stream aligned raw / furnace-only / final LVM temperature files."""
from __future__ import annotations
import csv
import io
import math
import time

from .calibration_common import ALL_CHANNELS
from .lvm import file_header,segment,CSV_COLUMNS

MEASUREMENT_FILES = {
    'raw':'measurements_raw.lvm',
    'tab4':'measurements_tab4.lvm',
    'tab3':'measurements_tab3.lvm',
}
MEASUREMENT_COLUMNS = CSV_COLUMNS
DATA_FORMAT = '''# 실험 LVM 데이터 파일 안내

연속 실험 이력은 실제 LabVIEW Measurement 텍스트 형식(v2, 탭 구분)으로 저장합니다.
- measurements_raw.lvm: 보정 전 TC1~12 원시온도.
- measurements_tab4.lvm: TC1~8 전기로 보정만 적용, bulk TC9~12 원시값.
- measurements_tab3.lvm: 전기로 보정 + 실측 오프셋의 최종 온도. bulk는 비등 오프셋만 적용.

세 파일의 sample_id와 X_Value(초), 출력 설정은 일치합니다. 각 파일은 온도 채널 TC1~12와
sample_id / elapsed_s / power_percent / power_index_after_sample_percent / interpolated의
17개 숫자 채널, 실제 시각 X_Value, Comment를 포함합니다. 누락 bulk는 NaN으로 표시하며
잘못된 입력 숫자 nan/inf와 구분합니다. Comment의 JSON에는 state_after_sample, sample_status,
stop_reason, temperature_basis가 있습니다. 정상 온도 샘플을 생략하거나 숫자를 반올림하지 않습니다.

파일 헤더와 각 저장 구간의 Channels, Samples, X0, Delta_X, X_Value 머리글을 포함합니다.
구간마다 실제 X_Value를 저장하므로 불규칙한 입력의 시각도 유지합니다. 0.25초 경과를 다음
입력에서 확인하거나 128행이 모이면 저장하며, 단계 기록/상승/정지/종료/다운로드 전에 비웁니다.
세 파일 모두 완료한 구간의 바이트 위치만 내보냅니다. 저장 실패는 이전 공통 완료 지점으로
되돌린 뒤 중단하며, 강제 종료 시 최근 미저장 구간이 남을 수 있습니다.

NI 실험의 20초 구간은 단계 종료 판정 시점 직전 60초를 고정해 배경 작업으로 계산합니다.
그동안 현재 출력을 유지하며 온도 수집, 임계 감시와 누수 감시는 계속합니다. 계산 결과·단계 이벤트 기록
완료 후 다음 출력으로 진행하므로 이전 선택 구간을 쓰는 누수 비교 기준을 유지합니다.
records의 recorded_at_s는 판정 시점이며 실제 상승 이벤트 시각과 소폭 다를 수 있습니다.
계산 중 임계/긴급중단이 발생하면 뒤늦게 완료된 계산으로 출력을 올리지 않습니다.
단계 계산이 비정상적으로 오래 걸리면 보호 정지하며, NI 버퍼 2초 보호도 유지합니다.

stages.csv와 selected_samples.csv는 단계 요약 및 선택 구간 파일입니다. v24부터 온도 입력 태스크 종료 후 작성합니다.
측정 중에는 메모리·events.jsonl에 단계 요약을 기록하고 전체 시각의 LVM만 계속 저장합니다.
전체 입력을 CSV 세 파일로 동시에 중복 저장하지 않습니다. 결과 ZIP에는 후처리용 연속 CSV 세 파일도 다운로드 시 생성해 포함합니다. CSV 머리글은 t_s, TC1~TC12부터 시작하며 모든 처리 샘플이 한 행씩 이어집니다. 개별 LVM 다운로드는 머리글이 한 번인 연속 형식도 선택할 수 있습니다. 내부 수집 원본은 구간별 LVM을 유지합니다. 예전 API의 CSV 다운로드 요청은
완료된 LVM 데이터를 요청 시 변환합니다. 현재 화면은 연속 CSV/LVM을 선택하며 결과 ZIP에는 연속 CSV와 원본 LVM을 함께 제공합니다.
재생은 원시 LVM 또는 예전 원시 CSV를 사용하세요. 최종 보정값을 원시값으로 다시 입력해
보정을 중복 적용하는 동작은 차단합니다.

run.json의 보정식·원시 교정점·실측 오프셋·수식 상수와 events.jsonl을 함께 보관하세요.
data_snapshot.json은 완료 샘플 수, 파일별 완료 바이트 수와 저장 설정을 기록합니다.
CSV 변환·연속 LVM 변환·ZIP 생성·기존 파일 정리는 실험/보정 수집과 요약 저장 종료 후에만 허용합니다.
변환 중에는 새 측정을 시작할 수 없습니다. 결과 생성 실패는 화면에 알리고 가능한 원본 LVM을 유지합니다.
출력 %는 가상 단계 설정이며 실제 레이저 ON/OFF 통신은 여전히 미연결입니다.
'''


def temperature_vectors(point,calibration):
    """Derive both views from preserved raw values, never from final minus an offset."""
    raw_tc=point.raw_temperatures_c or point.temperatures_c
    raw_bulk=point.raw_bulk_temperatures_c or point.bulk_temperatures_c or (None,)*4
    final_bulk=point.bulk_temperatures_c or (None,)*4
    if len(raw_tc)!=8 or len(raw_bulk)!=4 or len(point.temperatures_c)!=8 or len(final_bulk)!=4:
        raise ValueError('저장할 온도 데이터의 TC1~12 열 수를 확인하세요.')
    raw=(*raw_tc,*raw_bulk)
    initial=tuple(calibration.initial_value(v,i) if v is not None else None for i,v in enumerate(raw))
    return {'raw':raw,'tab4':initial,'tab3':(*point.temperatures_c,*final_bulk)}


class MeasurementLog:
    def __init__(self,directory,calibration,*,flush_interval_s=.25,batch_size=128):
        self.directory=directory;self.calibration=calibration
        self.count=0;self.first_t_s=None;self.last_t_s=None
        self.flush_interval_s=flush_interval_s;self.batch_size=batch_size
        self.committed_count=0;self.committed_last_t_s=None
        self.pending={basis:[] for basis in MEASUREMENT_FILES}
        self.comment_cache={}
        self.last_flush=time.monotonic()
        self.streams={};self.committed_sizes={}
        try:
            for basis,name in MEASUREMENT_FILES.items():
                stream=(directory/name).open('w',encoding='utf-8',newline='',buffering=256*1024)
                self.streams[basis]=stream
                stream.write(file_header());stream.flush()
                self.committed_sizes[basis]=stream.tell()
        except Exception:
            for stream in self.streams.values():stream.close()
            raise

    def write(self,point,power_percent,power_index_after,state,events):
        views=temperature_vectors(point,self.calibration)
        first=self.first_t_s
        if first is None and math.isfinite(point.t_s) and point.t_s>=0:first=point.t_s
        elapsed=point.t_s-first if first is not None and math.isfinite(point.t_s) else None
        reason=next((e.details['reason'] for e in events if e.kind=='shutdown_required'),'')
        status=reason if reason in ('invalid_temperature_data','temperature_data_gap') else 'ok'
        common=[self.count,point.t_s,elapsed,power_percent,power_index_after,state,status,reason,int(point.interpolated)]
        # Keep bounded rows in memory; format and flush once for a batch, not
        # three times per input sample. No samples are decimated or rounded.
        for basis,values in views.items():
            self.pending[basis].append([*common,basis,*values])
        self.first_t_s=first;self.last_t_s=point.t_s;self.count+=1
        if (self.count-self.committed_count>=self.batch_size
                or time.monotonic()-self.last_flush>=self.flush_interval_s
                or any(e.kind in ('observation_recorded','simulated_power_increased','shutdown_required') for e in events)):
            self.flush()

    def flush(self):
        if self.count==self.committed_count:return
        try:
            for basis,stream in self.streams.items():
                stream.write(segment(self.pending[basis],self.comment_cache));stream.flush()
        except Exception:
            for basis,stream in self.streams.items():
                try:stream.seek(self.committed_sizes[basis]);stream.truncate();stream.flush()
                except (OSError,ValueError):pass
            self.count=self.committed_count;self.last_t_s=self.committed_last_t_s
            if not self.count:self.first_t_s=None
            for rows in self.pending.values():rows.clear()
            raise
        self.committed_sizes={basis:stream.tell() for basis,stream in self.streams.items()}
        self.committed_count=self.count;self.committed_last_t_s=self.last_t_s
        for rows in self.pending.values():rows.clear()
        self.last_flush=time.monotonic()

    def snapshot(self):
        return {'sample_count':self.committed_count,'last_sample_id':self.committed_count-1 if self.committed_count else None,
                'last_t_s':self.committed_last_t_s if self.committed_last_t_s is not None and math.isfinite(self.committed_last_t_s) else None,
                'pending_sample_count':self.count-self.committed_count,
                'storage':{'format':'lvm','flush_interval_s':self.flush_interval_s,'batch_size':self.batch_size},
                'files':{MEASUREMENT_FILES[basis]:{'basis':basis,'committed_bytes':size} for basis,size in self.committed_sizes.items()}}
