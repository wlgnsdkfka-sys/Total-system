"""Multi-temperature TC calibration data and per-channel affine least-squares fits."""
from __future__ import annotations
from dataclasses import asdict,dataclass
from datetime import datetime,timedelta,timezone
import csv
import hashlib
import io
import json
import math
import re
import statistics
import uuid

from .calibration_common import MAIN_CHANNELS,ReferenceEvidence,finite

MAX_POINTS=500
SCHEMA='tc_initial_calibration_dataset'
SEOUL=timezone(timedelta(hours=9))
def now():return datetime.now(SEOUL).isoformat()
def identifier(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',value):
        raise ValueError('초기 보정 데이터 ID 형식을 확인하세요.')
    return value

def short_text(value,name,limit):
    if not isinstance(value,str) or len(value)>limit:raise ValueError(name+' 형식을 확인하세요.')
    return value

@dataclass(frozen=True)
class CalibrationPoint:
    point_id: str
    reference_c: float
    raw_c: tuple[float,...]
    source: str
    created_at: str
    note: str = ''
    std_c: tuple[float,...] = ()
    evidence: ReferenceEvidence | None = None

    def __post_init__(self):
        identifier(self.point_id)
        object.__setattr__(self,'reference_c',finite(self.reference_c))
        if len(self.raw_c)!=8:raise ValueError('TC1~8 원시온도 8개가 필요합니다.')
        object.__setattr__(self,'raw_c',tuple(finite(v) for v in self.raw_c))
        if len(self.std_c) not in (0,8):raise ValueError('표준편차는 8채널 모두 입력하거나 생략하세요.')
        object.__setattr__(self,'std_c',tuple(finite(v) for v in self.std_c))
        if any(v<0 for v in self.std_c):raise ValueError('표준편차는 0 이상이어야 합니다.')
        short_text(self.source,'출처',200);short_text(self.created_at,'측정 시각',80);short_text(self.note,'메모',1000)
        if self.evidence is not None:
            if not isinstance(self.evidence,ReferenceEvidence):raise ValueError('측정 근거 형식을 확인하세요.')
            if self.evidence.window_s<10:raise ValueError('전기로 측정점은 10초 이상의 안정 근거가 필요합니다.')
            if any(not math.isclose(a,b,rel_tol=0,abs_tol=1e-9) for a,b in zip(self.raw_c,self.evidence.means_c[:8])):
                raise ValueError('원시온도가 선택한 안정 구간의 평균과 다릅니다.')
            if self.std_c and any(not math.isclose(a,b,rel_tol=0,abs_tol=1e-9) for a,b in zip(self.std_c,self.evidence.std_c[:8])):
                raise ValueError('표준편차가 측정 근거와 다릅니다.')
            object.__setattr__(self,'std_c',self.evidence.std_c[:8])

    @classmethod
    def from_dict(cls,value):
        if not isinstance(value,dict):raise ValueError('측정점 형식을 확인하세요.')
        try:
            data=dict(value)
            data.setdefault('point_id',uuid.uuid4().hex);data.setdefault('source','파일 불러오기')
            data.setdefault('created_at',now())
            data['raw_c']=tuple(data['raw_c']);data['std_c']=tuple(data.get('std_c',()))
            if data.get('evidence') is not None:data['evidence']=ReferenceEvidence.from_dict(data['evidence'])
            return cls(**data)
        except (TypeError,KeyError) as error:raise ValueError('측정점의 기준온도·TC1~8 값을 확인하세요.') from error

@dataclass(frozen=True)
class CalibrationDataset:
    dataset_id: str
    revision: int
    points: tuple[CalibrationPoint,...] = ()
    modified_at: str = ''

    def __post_init__(self):
        identifier(self.dataset_id)
        if type(self.revision) is not int or self.revision<0:raise ValueError('데이터 버전이 올바르지 않습니다.')
        if len(self.points)>MAX_POINTS:raise ValueError(f'초기 보정 측정점은 최대 {MAX_POINTS}개입니다.')
        if any(not isinstance(p,CalibrationPoint) for p in self.points):raise ValueError('측정점 형식을 확인하세요.')
        if len({p.point_id for p in self.points})!=len(self.points):raise ValueError('측정점 ID가 중복됩니다.')
        short_text(self.modified_at,'저장 시각',80)

    def to_dict(self):return {'schema':SCHEMA,'schema_version':2,'channel_names':list(MAIN_CHANNELS),**asdict(self)}
    @classmethod
    def from_dict(cls,value):
        if not isinstance(value,dict) or value.get('schema')!=SCHEMA or value.get('schema_version') not in (1,2):
            raise ValueError('초기 보정 데이터 JSON 형식 또는 버전을 확인하세요.')
        if value.get('channel_names',list(MAIN_CHANNELS))!=list(MAIN_CHANNELS):raise ValueError('초기 교정은 TC1~8만 사용합니다.')
        try:
            return cls(value.get('dataset_id',uuid.uuid4().hex),value.get('revision',0),
                       tuple(project_legacy_point(p) if value['schema_version']==1 else CalibrationPoint.from_dict(p) for p in value['points']),value.get('modified_at',''))
        except (TypeError,KeyError) as error:raise ValueError('초기 보정 데이터의 points를 확인하세요.') from error
    @property
    def fingerprint(self):
        encoded=json.dumps([asdict(p) for p in self.points],ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        return hashlib.sha256(encoded).hexdigest()

@dataclass(frozen=True)
class ChannelFit:
    gain: float
    intercept_c: float
    rmse_c: float
    max_error_c: float
    r_squared: float
    raw_min_c: float
    raw_max_c: float

@dataclass(frozen=True)
class InitialProfile:
    profile_id: str
    dataset_id: str
    dataset_fingerprint: str
    created_at: str
    channels: tuple[ChannelFit,...]
    points: tuple[CalibrationPoint,...]
    method: str = 'affine_least_squares'
    range_policy: str = 'linear_extrapolation'

    def correct(self,value,channel):
        c=self.channels[channel]
        return c.gain*value+c.intercept_c
    def to_dict(self,include_points=True):
        value={'profile_id':self.profile_id,'dataset_id':self.dataset_id,
               'dataset_fingerprint':self.dataset_fingerprint,'created_at':self.created_at,
               'channel_names':list(MAIN_CHANNELS),'channels':[asdict(c) for c in self.channels],'method':self.method,'range_policy':self.range_policy}
        if include_points:value['points']=[asdict(p) for p in self.points]
        else:value['point_count']=len(self.points)
        return value
    @classmethod
    def from_dict(cls,value):
        if not isinstance(value,dict):raise ValueError('초기 보정식 형식을 확인하세요.')
        try:
            if value.get('method')!='affine_least_squares' or value.get('range_policy')!='linear_extrapolation':
                raise ValueError('지원하지 않는 초기 보정 방식입니다.')
            legacy=len(value['channels'])==12
            if legacy:
                original=[normalize_legacy_point(p) for p in value['points']]
                fingerprint=points_hash(original)
                channels=least_squares(original,12)
                points=tuple(project_legacy_point(p) for p in original)
            else:
                if len(value['channels'])!=8 or value.get('channel_names',list(MAIN_CHANNELS))!=list(MAIN_CHANNELS):
                    raise ValueError('초기 보정식은 TC1~8의 8채널이어야 합니다.')
                points=tuple(CalibrationPoint.from_dict(p) for p in value['points'])
                ds=CalibrationDataset(value['dataset_id'],0,points)
                fingerprint=ds.fingerprint;channels=fit_dataset(ds).channels
            if fingerprint!=value['dataset_fingerprint']:
                raise ValueError('초기 보정 데이터와 보정식이 일치하지 않습니다.')
            for expected,stored in zip(channels,value['channels']):
                for key,x in asdict(expected).items():
                    if not math.isclose(x,finite(stored[key]),rel_tol=1e-10,abs_tol=1e-9):
                        raise ValueError('초기 보정식은 저장된 측정점과 일치해야 합니다.')
            return fit_dataset(CalibrationDataset(value['dataset_id'],0,points),
                               profile_id=value['profile_id'],created_at=value['created_at'])
        except (TypeError,KeyError) as error:raise ValueError('초기 보정식의 측정점·계수를 확인하세요.') from error

def points_hash(points):
    encoded=json.dumps(points,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest()


def normalize_legacy_point(value):
    """Verify old 12-channel point without changing its evidence or fingerprint."""
    if not isinstance(value,dict):raise ValueError('이전 측정점 형식을 확인하세요.')
    try:
        if set(value)-{'point_id','reference_c','raw_c','source','created_at','note','std_c','evidence'}:
            raise ValueError('이전 측정점에 알 수 없는 필드가 있습니다.')
        raw=tuple(finite(v) for v in value['raw_c']);std=tuple(finite(v) for v in value.get('std_c',()))
        if len(raw)!=12 or len(std) not in (0,12):raise ValueError('이전 형식은 TC1~12 값을 포함해야 합니다.')
        if any(v<0 for v in std):raise ValueError('표준편차는 0 이상이어야 합니다.')
        proof=ReferenceEvidence.from_dict(value['evidence']) if value.get('evidence') else None
        if proof:
            if len(proof.means_c)!=12 or any(not math.isclose(a,b,rel_tol=0,abs_tol=1e-9) for a,b in zip(raw,proof.means_c)):
                raise ValueError('이전 측정점과 안정 구간의 원시온도가 다릅니다.')
            if std and any(not math.isclose(a,b,rel_tol=0,abs_tol=1e-9) for a,b in zip(std,proof.std_c)):
                raise ValueError('이전 측정점과 안정 구간의 표준편차가 다릅니다.')
            std=proof.std_c
        data={'point_id':value.get('point_id',uuid.uuid4().hex),'reference_c':finite(value['reference_c']),
              'raw_c':raw,'source':value.get('source','이전 데이터'),'created_at':value.get('created_at',now()),
              'note':value.get('note',''),'std_c':std,'evidence':asdict(proof) if proof else None}
        CalibrationPoint.from_dict({**data,'raw_c':raw[:8],'std_c':std[:8]})
        return data
    except (KeyError,TypeError) as error:raise ValueError('이전 초기 교정 데이터를 확인하세요.') from error


def project_legacy_point(value):
    data=normalize_legacy_point(value)
    # Keep old full-window evidence and its hash as provenance; fit only TC1..8.
    return CalibrationPoint.from_dict({**data,'raw_c':data['raw_c'][:8],'std_c':data['std_c'][:8]})


def least_squares(points,count):
    if len(points)<2 or len({p['reference_c'] for p in points})<2:
        raise ValueError('서로 다른 기준온도의 측정점이 최소 2개 필요합니다.')
    y=[p['reference_c'] for p in points];fits=[]
    try:
        ybar=statistics.mean(y);yy=math.fsum((v-ybar)**2 for v in y)
        for i in range(count):
            x=[p['raw_c'][i] for p in points];xbar=statistics.mean(x)
            xx=finite(math.fsum((v-xbar)**2 for v in x))
            if xx<=0:raise ValueError(f'TC{i+1}의 원시온도가 모두 같습니다. 측정값을 확인하세요.')
            gain=finite(math.fsum((a-xbar)*(b-ybar) for a,b in zip(x,y))/xx)
            if gain<=0:raise ValueError(f'TC{i+1}의 보정 기울기가 0 이하입니다. 기준온도와 채널 대응을 확인하세요.')
            intercept=finite(ybar-gain*xbar);errors=[finite(gain*a+intercept-b) for a,b in zip(x,y)]
            sse=finite(math.fsum(v*v for v in errors))
            fits.append(ChannelFit(gain,intercept,finite(math.sqrt(sse/len(points))),max(abs(v) for v in errors),
                                   finite(1-sse/yy),min(x),max(x)))
    except ArithmeticError as error:raise ValueError('측정값 범위가 너무 커 보정식을 계산할 수 없습니다.') from error
    return tuple(fits)


def fit_dataset(dataset: CalibrationDataset,profile_id=None,created_at=None):
    fits=least_squares([asdict(p) for p in dataset.points],8)
    pid=identifier(profile_id or uuid.uuid4().hex);stamp=short_text(created_at or now(),'보정 시각',80)
    return InitialProfile(pid,dataset.dataset_id,dataset.fingerprint,stamp,fits,dataset.points)

def dataset_csv(dataset):
    out=io.StringIO(newline='');writer=csv.writer(out)
    writer.writerow(['point_id','reference_c',*[f'{c}_raw_c' for c in MAIN_CHANNELS],*[f'{c}_std_c' for c in MAIN_CHANNELS],
                     'source','created_at','note','evidence_json'])
    for p in dataset.points:
        writer.writerow([p.point_id,p.reference_c,*p.raw_c,*(p.std_c or ('',)*8),p.source,p.created_at,p.note,
                         json.dumps(asdict(p.evidence),ensure_ascii=False,allow_nan=False) if p.evidence else ''])
    return out.getvalue().encode('utf-8-sig')

def import_dataset(text,kind):
    if not isinstance(text,str):raise ValueError('데이터 파일을 선택하세요.')
    if kind=='json':
        try:return CalibrationDataset.from_dict(json.loads(text.lstrip('\ufeff')))
        except json.JSONDecodeError as error:raise ValueError('초기 보정 JSON을 읽을 수 없습니다.') from error
    if kind!='csv':raise ValueError('JSON 또는 CSV를 선택하세요.')
    reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')));fields=reader.fieldnames or []
    raw=[f'{c}_raw_c' for c in MAIN_CHANNELS]
    if not set(raw).issubset(fields):raw=list(MAIN_CHANNELS)
    if 'reference_c' not in fields or not set(raw).issubset(fields) or len(fields)!=len(set(fields)):
        raise ValueError('CSV에는 reference_c와 TC1_raw_c~TC8_raw_c가 필요합니다. 열 이름 중복도 확인하세요.')
    points=[]
    for row in reader:
        try:
            std_keys=[f'{c}_std_c' for c in MAIN_CHANNELS]
            std=[] if all(row.get(c) in ('',None) for c in std_keys) else [float(row[c]) for c in std_keys]
            data={'reference_c':float(row['reference_c']),'raw_c':[float(row[c]) for c in raw],
                  'std_c':std,'source':row.get('source') or 'CSV 불러오기',
                  'created_at':row.get('created_at') or now(),'note':row.get('note') or ''}
            if row.get('point_id'):data['point_id']=row['point_id']
            if row.get('evidence_json'):data['evidence']=json.loads(row['evidence_json'])
            points.append(CalibrationPoint.from_dict(data))
            if len(points)>MAX_POINTS:raise ValueError(f'측정점은 최대 {MAX_POINTS}개입니다.')
        except (ValueError,TypeError,KeyError) as error:
            raise ValueError(f'CSV {reader.line_num}행을 확인하세요: {error}') from error
    return CalibrationDataset(uuid.uuid4().hex,0,tuple(points),now())
