"""Configurable heat-flux anomaly heuristic. It cannot confirm a water leak."""
from collections import deque
from dataclasses import asdict, dataclass
import math
import statistics

from .calculation import calculate_reading, calculate_stage, validate_settings


@dataclass(frozen=True)
class LeakConfig:
    enabled: bool = False
    action: str = "warn"
    calibration_confirmed: bool = False
    window_s: float = 20.0
    settling_s: float = 20.0
    hold_s: float = 5.0
    fluctuation_std_w_cm2: float | None = None
    drop_percent: float | None = None
    min_reference_flux_w_cm2: float = 0.0
    threshold_mode: str = "auto"
    noise_multiplier: float = 5.0

    def __post_init__(self):
        if type(self.enabled) is not bool or type(self.calibration_confirmed) is not bool:
            raise ValueError("누수 감지 사용 여부와 계산식 확인 여부를 선택하세요.")
        if self.action not in ("warn", "stop"):
            raise ValueError("누수 의심 시 동작을 선택하세요.")
        if self.threshold_mode not in ("auto", "manual"):
            raise ValueError("지원하지 않는 열유속 기준 설정입니다.")
        if self.noise_multiplier not in (3, 5, 8):
            raise ValueError("감지 민감도를 선택하세요.")
        for key, low, high in (("window_s", 2, 120), ("settling_s", 0, 180), ("hold_s", 0, 120)):
            value = getattr(self, key)
            if not math.isfinite(value) or not low <= value <= high:
                raise ValueError(f"{key}: {low}~{high}초로 입력하세요.")
        for key in ("fluctuation_std_w_cm2", "drop_percent"):
            value = getattr(self, key)
            if value is not None and (not math.isfinite(value) or value <= 0):
                raise ValueError("누수 감지 임계값은 0보다 큰 숫자여야 합니다.")
        if self.drop_percent is not None and self.drop_percent > 100:
            raise ValueError("열유속 감소율은 100% 이하여야 합니다.")
        if not math.isfinite(self.min_reference_flux_w_cm2) or self.min_reference_flux_w_cm2 < 0:
            raise ValueError("감소율 비교 기준 최소 열유속은 0 이상의 숫자여야 합니다.")
        if self.enabled and not self.calibration_confirmed:
            raise ValueError("열유속 계산식·TC 대응·부호 확인란을 선택한 뒤 감지를 켜세요.")
        if self.enabled and self.threshold_mode == "manual" and self.fluctuation_std_w_cm2 is None and self.drop_percent is None:
            raise ValueError("열유속 표준편차 또는 감소율 임계값을 입력하세요.")

    @classmethod
    def from_payload(cls, payload=None):
        if payload is None:
            return cls()
        if not isinstance(payload, dict):
            raise ValueError("누수 감지 설정 형식이 올바르지 않습니다.")
        values = asdict(cls())
        # Preserve v3 JSON/API settings; the v4 GUI explicitly selects auto mode.
        if "threshold_mode" not in payload and any(k in payload for k in ("fluctuation_std_w_cm2", "min_reference_flux_w_cm2")):
            values["threshold_mode"] = "manual"
        for key in values:
            if key not in payload:
                continue
            value = payload[key]
            if key in ("fluctuation_std_w_cm2", "drop_percent") and value in (None, ""):
                values[key] = None
            elif key not in ("enabled", "action", "calibration_confirmed", "threshold_mode"):
                try:
                    if isinstance(value, bool):
                        raise ValueError()
                    values[key] = float(value)
                except (ValueError, TypeError, OverflowError) as error:
                    raise ValueError("누수 판정 시간과 임계값을 숫자로 입력하세요.") from error
            else:
                values[key] = value
        return cls(**values)


class FluxMonitor:
    def __init__(self, config, calculation_settings):
        self.config = config
        self.settings = validate_settings(calculation_settings)
        self.points = deque()
        self.power = self.started = None
        self.reference = None
        self.pending = {}
        self.reported = set()
        self.alerts = deque(maxlen=100)
        self.latest_flux = self.mean = self.std = self.drop = None
        self.ready = False
        self.noise_reference = None
        self.threshold_std = self.minimum_reference = None

    @staticmethod
    def _numerical_floor(mean):
        # Floating point tolerance only; not an experimental heat-flux limit.
        return max(1e-12, 32 * math.ulp(abs(mean)))

    def _thresholds(self):
        if self.config.threshold_mode == "manual":
            self.threshold_std = self.config.fluctuation_std_w_cm2
            self.minimum_reference = self.config.min_reference_flux_w_cm2
            return
        noise = self.noise_reference
        self.threshold_std = (self.config.noise_multiplier * max(noise["std_w_cm2"], self._numerical_floor(noise["mean_w_cm2"]))
                              if noise else None)
        ref = self.reference
        self.minimum_reference = (max(self.config.noise_multiplier * ref["heat_flux_std"], self._numerical_floor(ref["heat_flux"]))
                                  if ref else None)

    def observe(self, reading, power_percent):
        self.latest_flux = calculate_reading(reading, self.settings)[1]
        if power_percent != self.power:
            self.power, self.started = power_percent, reading.t_s
            self.points.clear()
            self.pending.clear()
            self.reported.clear()
            self.mean = self.std = self.drop = None
        if not self.config.enabled:
            return []
        # Use only data after the per-step settling delay; never mix power steps.
        if reading.t_s - self.started < self.config.settling_s:
            self.ready = False
            return []
        self.points.append((reading.t_s, self.latest_flux))
        cutoff = reading.t_s - self.config.window_s
        while len(self.points) > 1 and self.points[1][0] <= cutoff:
            self.points.popleft()
        self.ready = len(self.points) >= 2 and self.points[0][0] <= cutoff
        if not self.ready:
            return []
        points = list(self.points)
        if points[0][0] < cutoff:
            a, b = points[:2]
            points[0] = (cutoff, a[1] + (b[1] - a[1]) * (cutoff - a[0]) / (b[0] - a[0]))
        values = [p[1] for p in points]
        self.mean, self.std = statistics.fmean(values), statistics.stdev(values)
        if self.noise_reference is None:
            self.noise_reference = {"source": "first_observation", "power_percent": power_percent,
                                    "mean_w_cm2": self.mean, "std_w_cm2": self.std, "t_s": reading.t_s}
        self._thresholds()
        reference = self.reference
        drop = (100 * (reference["heat_flux"] - self.mean) / reference["heat_flux"]
                if reference and reference["power_percent"] < power_percent
                and self.minimum_reference is not None and reference["heat_flux"] > self.minimum_reference else None)
        if drop is not None and not math.isfinite(drop):
            raise ValueError("열유속 감소율을 계산할 수 없습니다. 최소 비교 열유속과 계산식을 확인하세요.")
        self.drop = drop
        rules = {
            "flux_fluctuation": (self.threshold_std is not None and self.std >= self.threshold_std),
            "flux_drop_after_increase": (self.config.drop_percent is not None and self.drop is not None
                                         and self.drop >= self.config.drop_percent),
        }
        alerts = []
        for rule, matches in rules.items():
            if not matches:
                self.pending.pop(rule, None)
                continue
            self.pending.setdefault(rule, reading.t_s)
            if reading.t_s - self.pending[rule] < self.config.hold_s or rule in self.reported:
                continue
            self.reported.add(rule)
            alert = {"rule": rule, "action": self.config.action, "power_percent": power_percent,
                     "heat_flux_w_cm2": self.latest_flux, "window_mean_w_cm2": self.mean,
                     "window_std_w_cm2": self.std, "drop_percent": self.drop,
                     "reference": reference, "window_s": self.config.window_s,
                     "hold_s": self.config.hold_s, "threshold_std_w_cm2": self.threshold_std,
                     "threshold_mode": self.config.threshold_mode, "noise_reference": self.noise_reference,
                     "minimum_reference_flux_w_cm2": self.minimum_reference,
                     "threshold_drop_percent": self.config.drop_percent,
                     "diagnosis": "suspected_leak_or_heat_transfer_change", "t_s": reading.t_s}
            self.alerts.append(alert)
            alerts.append(alert)
        return alerts

    def record(self, record, calculated=None):
        result = calculate_stage(record, self.settings) if calculated is None else calculated
        self.reference = {"power_percent": record.power_percent, "heat_flux": result["heat_flux"],
                          "heat_flux_std": result["heat_flux_std"],
                          "recorded_at_s": record.recorded_at_s}
        if not self.reported:
            self.noise_reference = {"source": "selected_segment", "power_percent": record.power_percent,
                                    "mean_w_cm2": result["heat_flux"], "std_w_cm2": result["heat_flux_std"],
                                    "t_s": record.recorded_at_s}
        self._thresholds()
        return []

    def snapshot(self):
        return {"config": asdict(self.config), "ready": self.ready,
                "status": "disabled" if not self.config.enabled else "suspected" if self.alerts else "watching" if self.ready else "warming_up",
                "heat_flux_w_cm2": self.latest_flux, "window_mean_w_cm2": self.mean,
                "window_std_w_cm2": self.std, "drop_percent": self.drop,
                "threshold_std_w_cm2": self.threshold_std, "minimum_reference_flux_w_cm2": self.minimum_reference,
                "noise_reference": self.noise_reference,
                "reference": self.reference, "alerts": list(self.alerts)}
