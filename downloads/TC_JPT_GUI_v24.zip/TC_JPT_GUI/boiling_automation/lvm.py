"""LabVIEW Measurement text files with numeric channels and explicit time values."""
import csv
from datetime import datetime,timedelta,timezone
import io
import json
import math

from .calibration_common import ALL_CHANNELS

CSV_COLUMNS=('sample_id','t_s','elapsed_s','power_percent','power_index_after_sample_percent',
             'state_after_sample','sample_status','stop_reason','interpolated','temperature_basis',*ALL_CHANNELS)
Y_COLUMNS=(*ALL_CHANNELS,'sample_id','elapsed_s','power_percent','power_index_after_sample_percent','interpolated')
EXPORT_COLUMNS=('t_s',*ALL_CHANNELS,*(c for c in CSV_COLUMNS if c not in ('t_s',*ALL_CHANNELS)))


def file_header():
    stamp=datetime.now(timezone(timedelta(hours=9)))
    fields=[('Writer_Version','2'),('Reader_Version','2'),('Separator','Tab'),
            ('Decimal_Separator','.'),('Multi_Headings','Yes'),('X_Columns','One'),
            ('Time_Pref','Relative'),('Date',stamp.strftime('%Y/%m/%d')),('Time',stamp.strftime('%H:%M:%S.%f'))]
    return 'LabVIEW Measurement\n'+''.join(k+'\t'+v+'\n' for k,v in fields)+'***End_of_Header***\n\n'


def _segment_header(rows,n):
    count=len(Y_COLUMNS)
    def header(key,values):return key+'\t'+'\t'.join(map(str,values))+'\n'
    delta=float(rows[1][1])-float(rows[0][1]) if n>1 else 0.
    if not isinstance(delta,(int,float)) or not math.isfinite(delta):delta=0.
    origin=float(rows[0][1]) if math.isfinite(float(rows[0][1])) else 0.
    return ''.join([header('Channels',[count]),header('Samples',[n]*count),
            header('Y_Unit_Label',['Celsius']*12+['Index','s','Percent','Percent','Boolean']),
            header('X_Dimension',['Time']*count),header('X0',[origin]*count),
            header('Delta_X',[delta]*count),'***End_of_Header***\n',
            header('X_Value',[*Y_COLUMNS,'Comment'])])


def _data_line(row,comment_cache):
    key=(row[5],row[6],row[7],row[9])
    if key not in comment_cache:
        comment_cache[key]=json.dumps(dict(zip(('state_after_sample','sample_status','stop_reason','temperature_basis'),key)),separators=(',',':'),ensure_ascii=True)
    numeric=[row[1],*row[10:],row[0],row[2],row[3],row[4],row[8]]
    return '\t'.join('NaN' if v is None else str(v) for v in numeric)+'\t'+comment_cache[key]+'\n'


def segment(rows,comment_cache):
    return _segment_header(rows,len(rows))+''.join(_data_line(row,comment_cache) for row in rows)+'\n'


def measurement_rows(body,*,recover_metadata=False):
    """Decode our complete LVM segments, including lossless status comments."""
    text=body.decode('utf-8-sig') if isinstance(body,bytes) else body.lstrip('\ufeff')
    if not text.startswith('LabVIEW Measurement'):raise ValueError('LVM 파일 머리글을 확인하세요.')
    first=text.find('\n');second=text.find('\n',first+1)
    if first<0 or second<0:raise ValueError('LVM 파일 머리글이 불완전합니다.')
    remaining=0;columns=None;expected=None
    separator='\t' if '\t' in text[first+1:second] else ','
    for fields in csv.reader(io.StringIO(text),delimiter=separator):
        if not fields or not any(fields):continue
        if remaining:
            if columns is None or len(fields)!=len(columns):raise ValueError('LVM 온도 행이 불완전합니다.')
            values=dict(zip(columns,fields))
            try:comment=json.loads(values['Comment'])
            except (KeyError,ValueError,TypeError) as error:
                if not recover_metadata:raise ValueError('LVM 측정 상태 정보를 확인하세요.') from error
                comment={'state_after_sample':'','sample_status':'','stop_reason':'','temperature_basis':'unknown'}
            if (not isinstance(comment,dict) or set(comment)!={'state_after_sample','sample_status','stop_reason','temperature_basis'}
                    or any(not isinstance(v,str) for v in comment.values())):
                if not recover_metadata:raise ValueError('LVM 측정 상태 필드가 올바르지 않습니다.')
                comment={'state_after_sample':'','sample_status':'','stop_reason':'','temperature_basis':'unknown'}
            out={'t_s':values['X_Value'],**{key:values[key] for key in Y_COLUMNS},**comment}
            yield {key:'' if out[key]=='NaN' else out[key] for key in CSV_COLUMNS}
            remaining-=1
        elif fields[0]=='Samples':
            try:
                if expected is not None:raise ValueError('중복된 미완료 구간')
                counts=[int(v) for v in fields[1:] if v!='']
                if len(counts) not in (1,len(Y_COLUMNS)) or len(set(counts))!=1:raise ValueError('채널별 샘플 수 불일치')
                expected=counts[0]
            except (ValueError,IndexError) as error:raise ValueError('LVM 샘플 수를 확인하세요.') from error
        elif fields[0]=='X_Value':
            if fields!=['X_Value',*Y_COLUMNS,'Comment'] or expected is None or expected<1:
                raise ValueError('지원하는 TC1~12 실험 LVM 형식이 아닙니다.')
            columns=fields;remaining=expected;expected=None
    if remaining or expected is not None:raise ValueError('LVM 마지막 저장 구간이 불완전합니다.')


def to_csv(body):
    output=io.StringIO(newline='');writer=csv.DictWriter(output,fieldnames=EXPORT_COLUMNS)
    writer.writeheader();writer.writerows(measurement_rows(body))
    return output.getvalue().encode('utf-8')


def continuous_lvm(body):
    """A download with one global header and one uninterrupted data segment."""
    text=body.decode('utf-8-sig') if isinstance(body,bytes) else body.lstrip('\ufeff')
    count=0;first_rows=[]
    def ordered(r):
        return [r[c] if r[c]!='' or c in ('state_after_sample','sample_status','stop_reason','temperature_basis') else None for c in CSV_COLUMNS]
    for row in measurement_rows(text):
        count+=1
        if len(first_rows)<2:first_rows.append(ordered(row))
    end=text.index('***End_of_Header***')+len('***End_of_Header***')
    prefix=text[:end].replace('Multi_Headings\tYes','Multi_Headings\tNo')+'\n\n'
    if not count:return prefix.encode('utf-8')
    output=io.StringIO();output.write(prefix);output.write(_segment_header(first_rows,count));cache={}
    for row in measurement_rows(text):output.write(_data_line(ordered(row),cache))
    output.write('\n');return output.getvalue().encode('utf-8')


def flatten_input(text):
    """Recover numeric samples from an existing LVM/Excel-resaved CSV file.

    Never infer missing status/basis metadata or round the original numeric text.
    """
    if not isinstance(text,str):raise ValueError('정리할 LVM 또는 CSV 파일을 선택하세요.')
    text=text.lstrip('\ufeff')
    if text.startswith('LabVIEW Measurement'):
        data=list(measurement_rows(text,recover_metadata=True))
        segments=sum(line.startswith(('X_Value\t','X_Value,')) for line in text.splitlines())
    else:
        reader=csv.DictReader(io.StringIO(text))
        if reader.fieldnames and len(set(reader.fieldnames))!=len(reader.fieldnames):
            raise ValueError('CSV에 중복된 열 이름이 있습니다. 온도 열을 확인하세요.')
        if not {'t_s',*ALL_CHANNELS[:8]}.issubset(reader.fieldnames or ()):
            raise ValueError('CSV에는 t_s와 TC1~TC8 열이 필요합니다.')
        data=[{key:r.get(key,'') or '' for key in CSV_COLUMNS} for r in reader]
        for row in data:
            if not row['temperature_basis']:row['temperature_basis']='unknown'
        segments=1
    if not data:raise ValueError('파일에서 정리할 온도 샘플을 찾지 못했습니다.')
    from decimal import Decimal,InvalidOperation
    invalid_times=0;ordered=True;previous=None
    for row in data:
        try:t=Decimal(row['t_s'])
        except InvalidOperation as error:raise ValueError('데이터 행에 숫자가 아닌 측정 시각이 있습니다.') from error
        if t.is_finite():
            if previous is not None and t<=previous:ordered=False
            previous=t
        else:invalid_times+=1
        for name in ALL_CHANNELS:
            if row[name]:
                try:Decimal(row[name])
                except InvalidOperation as error:raise ValueError(name+' 온도에 숫자가 아닌 값이 있습니다.') from error
    output=io.StringIO(newline='');writer=csv.DictWriter(output,fieldnames=EXPORT_COLUMNS)
    writer.writeheader();writer.writerows(data)
    report={'sample_count':len(data),'source_segments':segments,'first_t_s':data[0]['t_s'],
            'last_t_s':data[-1]['t_s'],'strictly_increasing':ordered and invalid_times==0,'invalid_time_count':invalid_times,
            'missing_metadata_rows':sum(r['temperature_basis']=='unknown' for r in data),
            'numeric_text_preserved':True,'rows_sorted_or_removed':False}
    return output.getvalue(),report
