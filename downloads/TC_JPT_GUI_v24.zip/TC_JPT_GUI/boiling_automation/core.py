"""Temperature decisions and an offline experiment replay.

This module never opens a serial port, calls NI-DAQmx, or operates a laser.
Its output is a plan for validation, not confirmation of physical actuation.
"""

from __future__ import annotations

from bisect import bisect_left, bisect_right
from collections import deque
from dataclasses import dataclass, replace
import math
import statistics
import time
from typing import Sequence


CHANNELS = tuple(f"TC{i}" for i in range(1, 9))
BULK_CHANNELS = tuple(f"TC{i}" for i in range(9, 13))


@dataclass(frozen=True)
class Config:
    critical_c: float
    allowed_std_c: float | None = None
    observation_s: float = 60.0
    segment_s: float = 20.0
    step_duration_s: float = 300.0
    max_sample_gap_s: float = 2.0
    max_power_percent: int = 100
    minimum_step_s: float = 90.0
    stability_window_s: float = 30.0

    def __post_init__(self) -> None:
        if not math.isfinite(self.critical_c):
            raise ValueError("An explicit finite critical temperature is required")
        if self.allowed_std_c is not None and (
            not math.isfinite(self.allowed_std_c) or self.allowed_std_c < 0
        ):
            raise ValueError("allowed_std_c must be finite and nonnegative")
        for name in ("observation_s", "segment_s", "step_duration_s", "max_sample_gap_s", "minimum_step_s", "stability_window_s"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if self.segment_s > self.observation_s:
            raise ValueError("segment_s cannot exceed observation_s")
        if self.step_duration_s < self.observation_s:
            raise ValueError("step_duration_s must cover a complete observation")
        if self.step_duration_s > 300:
            raise ValueError("A power step cannot exceed the five-minute limit")
        if self.minimum_step_s < 90 or self.minimum_step_s > self.step_duration_s:
            raise ValueError("Each power step requires at least 90 seconds before advancement")
        if self.stability_window_s > self.observation_s:
            raise ValueError("The observation must cover the stability window")
        if self.max_sample_gap_s >= self.segment_s:
            raise ValueError("Sample gaps must be shorter than the selected segment")
        if type(self.max_power_percent) is not int or not 0 <= self.max_power_percent <= 100:
            raise ValueError("max_power_percent must be an integer from 0 to 100")


@dataclass(frozen=True)
class Reading:
    t_s: float
    temperatures_c: tuple[float, ...]
    interpolated: bool = False
    bulk_temperatures_c: tuple[float | None, ...] = ()
    raw_temperatures_c: tuple[float, ...] = ()
    raw_bulk_temperatures_c: tuple[float | None, ...] = ()


@dataclass(frozen=True)
class ChannelStats:
    mean_c: float
    minimum_c: float
    maximum_c: float
    std_c: float

    @property
    def range_c(self) -> float:
        return self.maximum_c - self.minimum_c


@dataclass(frozen=True)
class Segment:
    start_s: float
    end_s: float
    channels: tuple[ChannelStats, ...]

    @property
    def worst_range_c(self) -> float:
        return max(c.range_c for c in self.channels)

    @property
    def worst_std_c(self) -> float:
        return max(c.std_c for c in self.channels)


@dataclass(frozen=True)
class StageRecord:
    power_percent: int
    recorded_at_s: float
    segment: Segment
    selected_samples: tuple[Reading, ...]
    completion_reason: str
    current_range_c: float
    current_std_c: float
    # A relative ranking is deliberately not a claim of absolute stability.
    selection: str = "best_observed_segment"


@dataclass(frozen=True)
class Event:
    kind: str
    t_s: float
    details: dict


def _boundary(points: Sequence[Reading], times: list[float], t: float) -> Reading:
    """Interpolate an interval endpoint; trip detection never uses interpolation."""
    i = bisect_left(times, t)
    if i < len(points) and times[i] == t:
        return points[i]
    if i == 0 or i == len(points):
        raise ValueError("The input does not cover the requested interval")
    left, right = points[i - 1], points[i]
    fraction = (t - left.t_s) / (right.t_s - left.t_s)
    bulk = tuple(a + fraction * (b - a) if a is not None and b is not None else None
                 for a, b in zip(left.bulk_temperatures_c, right.bulk_temperatures_c))
    raw = tuple(a + fraction * (b - a) for a, b in zip(
        left.raw_temperatures_c, right.raw_temperatures_c))
    raw_bulk = tuple(a + fraction * (b - a) if a is not None and b is not None else None
                     for a, b in zip(left.raw_bulk_temperatures_c, right.raw_bulk_temperatures_c))
    return Reading(t, tuple(a + fraction * (b - a) for a, b in zip(
        left.temperatures_c, right.temperatures_c
    )), interpolated=True, bulk_temperatures_c=bulk,
        raw_temperatures_c=raw, raw_bulk_temperatures_c=raw_bulk)


def _interval(points: Sequence[Reading], start: float, end: float) -> list[Reading]:
    times = [p.t_s for p in points]
    return [
        _boundary(points, times, start),
        *(p for p in points if start < p.t_s < end),
        _boundary(points, times, end),
    ]


def _statistics(points: Sequence[Reading]) -> tuple[ChannelStats, ...]:
    """Arithmetic mean and sample standard deviation of the saved interval.

    Use exactly the exported samples, including explicitly marked interpolated
    endpoints. The sample standard deviation uses N-1, matching statistics.stdev.
    """
    result = []
    for channel in range(8):
        values = [p.temperatures_c[channel] for p in points]
        # Shift before squaring to retain small fluctuations on large baselines.
        shifted = [v-values[0] for v in values]
        try:
            center = statistics.fmean(shifted)
            variance = math.fsum((v-center)**2 for v in shifted)/(len(values)-1)
            std = math.sqrt(variance) if math.isfinite(variance) else statistics.stdev(values)
        except (ArithmeticError, ValueError):
            std = statistics.stdev(values)
        result.append(ChannelStats(statistics.fmean(values), min(values), max(values), std))
    return tuple(result)


def _select_best_segment_reference(points: Sequence[Reading], config: Config) -> Segment | None:
    """Select a common 20s interval from a complete recent 60s observation.

    Candidate starts align to samples, plus the observation's exact left edge.
    The largest TC1..8 sample standard deviation is minimized, then the range.
    Exact ties favor the most recent interval. All channels use the same interval.
    """
    if len(points) < 2 or points[-1].t_s - points[0].t_s < config.observation_s:
        return None
    end = points[-1].t_s
    start = end - config.observation_s
    observation = _interval(points, start, end)
    candidates = []
    starts = {start, end - config.segment_s}
    starts.update(p.t_s for p in observation if p.t_s <= end - config.segment_s)
    for candidate_start in sorted(starts):
        candidate_end = candidate_start + config.segment_s
        selected = _interval(observation, candidate_start, candidate_end)
        candidates.append(Segment(candidate_start, candidate_end, _statistics(selected)))
    return min(candidates, key=lambda s: (
        s.worst_std_c, s.worst_range_c, -s.start_s
    )) if candidates else None


def select_best_segment(points: Sequence[Reading], config: Config) -> Segment | None:
    """Query balanced variance aggregates instead of rescanning every 20s window.

    All original candidate starts and interpolated endpoints are retained. Close
    numeric contenders are recomputed from their full samples before ranking.
    """
    if len(points)<2 or points[-1].t_s-points[0].t_s<config.observation_s:return None
    end=points[-1].t_s;start=end-config.observation_s
    observation=_interval(points,start,end);times=[p.t_s for p in observation]
    starts=sorted({start,end-config.segment_s}|{t for t in times if t<=end-config.segment_s})
    def leaf(point):
        v=point.temperatures_c
        return (1,v,(0.,)*8,v,v)
    def merge(a,b):
        if a is None:return b
        if b is None:return a
        n=a[0]+b[0];weight=b[0]/n;scale=a[0]*b[0]/n
        means=[];squares=[];mins=[];maxs=[]
        for i in range(8):
            delta=b[1][i]-a[1][i]
            means.append(a[1][i]+delta*weight)
            squares.append(a[2][i]+b[2][i]+delta*delta*scale)
            mins.append(min(a[3][i],b[3][i]));maxs.append(max(a[4][i],b[4][i]))
        return n,tuple(means),tuple(squares),tuple(mins),tuple(maxs)
    size=1
    while size<len(observation):size*=2
    tree=[None]*(2*size)
    for i,p in enumerate(observation):tree[size+i]=leaf(p)
    for i in range(size-1,0,-1):tree[i]=merge(tree[2*i],tree[2*i+1])
    def query(left,right):
        left+=size;right+=size;a=b=None
        while left<right:
            if left&1:a=merge(a,tree[left]);left+=1
            if right&1:right-=1;b=merge(tree[right],b)
            left//=2;right//=2
        return merge(a,b)
    scores=[];zero_starts=[]
    for s in starts:
        e=s+config.segment_s
        a=merge(leaf(_boundary(observation,times,s)),query(bisect_right(times,s),bisect_left(times,e)))
        a=merge(a,leaf(_boundary(observation,times,e)))
        if any(not math.isfinite(v) or v<0 for v in a[2]):
            return _select_best_segment_reference(points,config)
        spread=max(hi-lo for lo,hi in zip(a[3],a[4]))
        if spread==0:zero_starts.append(s)
        elif any(v==0 and hi>lo for v,lo,hi in zip(a[2],a[3],a[4])):
            return _select_best_segment_reference(points,config)
        scores.append((s,math.sqrt(max(a[2])/(a[0]-1))))
    if zero_starts:
        s=max(zero_starts)
        return Segment(s,s+config.segment_s,_statistics(_interval(observation,s,s+config.segment_s)))
    best=min(v for _,v in scores)
    magnitude=max(1.,max(abs(v) for p in observation for v in p.temperatures_c))
    tolerance=128*math.ulp(magnitude)*(1+math.log2(len(observation)))
    finalists=[]
    for s,estimate in scores:
        if estimate<=best+tolerance:
            finalists.append(Segment(s,s+config.segment_s,_statistics(_interval(observation,s,s+config.segment_s))))
    return min(finalists,key=lambda s:(s.worst_std_c,s.worst_range_c,-s.start_s))


def _analyse_stage(points,config,power,t,reason,current_range,current_std,flux_settings):
    best=select_best_segment(points,config)
    if best is None:raise ValueError('완성된 단계의 20초 기록 구간을 선택하지 못했습니다.')
    record=StageRecord(power,t,best,tuple(_interval(points,best.start_s,best.end_s)),reason,current_range,current_std)
    if flux_settings is None:return record,None
    from .calculation import calculate_stage
    return record,calculate_stage(record,flux_settings)


class ReplayController:
    """Offline-only state machine; power changes are assumed to apply instantly.

    A hardware controller needs confirmed commands and an independent shutdown
    path. Do not attach device writes to this replay implementation.
    """

    def __init__(self, config: Config, flux_monitor=None, *, stage_executor=None):
        self.config = config
        self.power_percent = 0
        self.state = "waiting_for_data"
        self.records: list[StageRecord] = []
        self._history: deque[Reading] = deque()
        self._last_sample_s: float | None = None
        self._last_reading: Reading | None = None
        self._step_started_s: float | None = None
        self.flux_monitor = flux_monitor
        self.stage_executor=stage_executor
        self.analysis_future=None
        self.analysis_started_s=None
        self.analysis_started_wall=None

    def collect_analysis(self,*,wait=False,allow_advance=True):
        future=self.analysis_future
        if future is None or (not wait and not future.done()):return []
        try:record,calculated=future.result(timeout=2 if wait else 0)
        finally:self.analysis_future=None
        return self._complete_record(record,self._last_reading,calculated,allow_advance)

    def _complete_record(self,record,reading,calculated=None,allow_advance=True):
        self.records.append(record)
        t=reading.t_s
        events=[Event('observation_recorded',t,{'record':record})]
        # Completed historic records may still be archived after an emergency;
        # that must never issue a new output increase or change the trip state.
        if self.terminal or not allow_advance:return events
        if self.flux_monitor:
            events+=self._flux_alerts(self.flux_monitor.record(record,calculated),t)
            if self.terminal:return events
        if self.power_percent==self.config.max_power_percent:
            events+=self._shutdown('maximum_output_reached',t,completed=True)
        else:
            self.power_percent+=1;self._step_started_s=t;self._history.clear();self._history.append(reading)
            events.append(Event('simulated_power_increased',t,{'power_percent':self.power_percent,
                          'power_index_percent':self.power_percent,'laser_emission_assumed':'on'}))
        return events

    def _flux_alerts(self, alerts, t_s):
        events = [Event("suspected_leak", t_s, alert) for alert in alerts]
        if alerts and self.flux_monitor.config.action == "stop":
            events += self._shutdown("suspected_leak", t_s, alerts=alerts)
        return events

    @property
    def terminal(self) -> bool:
        return self.state in ("tripped", "completed")

    @property
    def power_index_percent(self) -> int:
        """OFF has its own index; a 0% setpoint still assumes emission ON."""
        return self.power_percent if self.state == "running" else -1

    def _shutdown(self, reason: str, t_s: float, *, completed: bool = False, **extra) -> list[Event]:
        if self.terminal:
            return []
        self.state = "completed" if completed else "tripped"
        self._history.clear()
        return [Event("shutdown_required", t_s, {
            "reason": reason,
            "state": self.state,
            "power_percent": self.power_percent,
            "power_index_percent": -1,
            "previous_power_percent": self.power_percent,
            "laser_emission_assumed": "off",
            # A decision requiring both actions; no physical actions run here.
            "independent_actions": ["shutter_close", "laser_emission_off"],
            **extra,
        })]

    def process(self, reading: Reading) -> list[Event]:
        if self.terminal:
            return []
        t = reading.t_s
        valid_time = math.isfinite(t) and t >= 0
        event_time = t if valid_time else (self._last_sample_s or 0.0)
        if (
            not valid_time or len(reading.temperatures_c) != 8
            or not all(math.isfinite(v) for v in reading.temperatures_c)
            or (self._last_sample_s is not None and t <= self._last_sample_s)
        ):
            return self._shutdown("invalid_temperature_data", event_time)

        # First priority: per-sample TC thresholds, before averaging or increase.
        hot = [CHANNELS[i] for i, v in enumerate(reading.temperatures_c)
               if v >= self.config.critical_c]
        if hot:
            return self._shutdown("critical_temperature", t, channels=hot,
                                  temperatures_c=reading.temperatures_c,
                                  raw_temperatures_c=reading.raw_temperatures_c or reading.temperatures_c)
        if self._last_sample_s is not None and t - self._last_sample_s > self.config.max_sample_gap_s:
            return self._shutdown("temperature_data_gap", t)
        self._last_sample_s = t
        self._last_reading = reading

        events = []
        if self.state == "waiting_for_data":
            self.state = "running"
            self._step_started_s = t
            events.append(Event("simulated_step_started", t, {
                "power_percent": 0, "power_index_percent": 0, "laser_emission_assumed": "on"
            }))

        if self.flux_monitor:
            events += self._flux_alerts(self.flux_monitor.observe(reading, self.power_percent), t)
            if self.terminal:
                return events

        self._history.append(reading)
        cutoff = t - self.config.observation_s
        while len(self._history) > 1 and self._history[1].t_s <= cutoff:
            self._history.popleft()
        if self.analysis_future is not None:
            if self.analysis_future.done():return events+self.collect_analysis()
            if time.monotonic()-self.analysis_started_wall>2:
                raise ValueError('단계 배경 계산이 2초 넘게 지연됐습니다. 온도 측정과 차단 감시를 유지한 뒤 중단합니다.')
            return events
        points = list(self._history)
        complete_observation = t - points[0].t_s >= self.config.observation_s
        if not complete_observation or t - self._step_started_s < self.config.minimum_step_s:
            return events
        current = _statistics(_interval(points, t - self.config.stability_window_s, t))
        current_range = max(c.range_c for c in current)
        current_std = max(c.std_c for c in current)
        # A quiet interval in the past is insufficient to establish stability now.
        stable_now = (self.config.allowed_std_c is not None
                      and current_std <= self.config.allowed_std_c)
        due = t - self._step_started_s >= self.config.step_duration_s
        if self.stage_executor is not None and (due or stable_now):
            reason='stable' if stable_now else 'maximum_step_time'
            self.analysis_started_s=t;self.analysis_started_wall=time.monotonic()
            self.analysis_future=self.stage_executor.submit(_analyse_stage,tuple(points),self.config,self.power_percent,
                t,reason,current_range,current_std,self.flux_monitor.settings if self.flux_monitor else None)
            events.append(Event('stage_analysis_pending',t,{'power_percent':self.power_percent,
                          'observation_start_s':t-self.config.observation_s,'observation_end_s':t,'completion_reason':reason}))
            return events
        best = select_best_segment(points, self.config) if due or stable_now else None
        if best is not None:
            selected = tuple(_interval(list(self._history), best.start_s, best.end_s))
            reason = "stable" if stable_now else "maximum_step_time"
            record = StageRecord(self.power_percent, t, best, selected, reason, current_range, current_std)
            events+=self._complete_record(record,reading)
        return events

    def update_critical_temperature(self, value: float) -> list[Event]:
        """Apply a threshold without restarting a stage; recheck the latest TC sample."""
        if self.terminal:
            raise ValueError("종료된 실험의 임계온도는 변경할 수 없습니다.")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("임계온도는 유한한 숫자여야 합니다.")
        updated = replace(self.config, critical_c=float(value))
        old = self.config.critical_c
        if updated.critical_c == old:
            return []
        self.config = updated
        t = self._last_sample_s or 0.0
        events = [Event("critical_temperature_changed", t, {
            "old_critical_c": old, "new_critical_c": updated.critical_c,
        })]
        if self._last_reading:
            values = self._last_reading.temperatures_c
            hot = [CHANNELS[i] for i, v in enumerate(values) if v >= updated.critical_c]
            if hot:
                events += self._shutdown("critical_temperature", t, channels=hot,
                                         temperatures_c=values, trigger="threshold_change",
                                         raw_temperatures_c=self._last_reading.raw_temperatures_c or values)
        return events

    def check_clock(self, t_s: float) -> list[Event]:
        """Replay a watchdog tick. A live watchdog must run independently."""
        if self.terminal:
            return []
        if not math.isfinite(t_s) or t_s < 0:
            return self._shutdown("invalid_clock", self._last_sample_s or 0.0)
        if self._last_sample_s is not None and t_s - self._last_sample_s > self.config.max_sample_gap_s:
            return self._shutdown("temperature_data_stale", t_s)
        return []

    def finish(self) -> list[Event]:
        """EOF is an incomplete run, not evidence that the experiment succeeded."""
        return self._shutdown("input_ended_before_completion", self._last_sample_s or 0.0)

    def abort(self, reason: str) -> list[Event]:
        return self._shutdown(reason, self._last_sample_s or 0.0)
