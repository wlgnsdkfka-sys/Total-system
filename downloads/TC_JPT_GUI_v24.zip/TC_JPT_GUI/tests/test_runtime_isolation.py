"""Acquisition and offline work never overlap; finalization releases resources."""
import csv
import http.client
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from boiling_automation.core import Config,Reading,ReplayController
from boiling_automation.gui import GuiServer,GuiSession,ResultWriter
from boiling_automation.initial_calibration import import_dataset
from boiling_automation.lvm import measurement_rows


def source(seconds=91,value=99):
    return 't_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n'+'\n'.join(
        str(t)+','+','.join([str(value)]*12) for t in range(seconds))


class RuntimeIsolationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.s=GuiSession(self.root)

    def tearDown(self):
        self.s.stop()
        for worker in (self.s.worker,self.s.capture_worker):
            if worker and worker.is_alive():worker.join(5)
        self.tmp.cleanup()

    def run_complete(self):
        self.s.start({'source':'csv','csv_text':source(),'critical_c':200,'allowed_std_c':.1,'max_power_percent':0,'speed':300})
        self.s.worker.join(5);self.assertFalse(self.s.worker.is_alive())

    def test_export_lease_prevents_experiment_and_calibration_start(self):
        self.run_complete();entered=threading.Event();release=threading.Event();errors=[]
        def convert(body):
            entered.set();release.wait(5)
            from boiling_automation.lvm import to_csv
            return to_csv(body)
        def export():
            try:self.s.export_measurements('raw')
            except Exception as error:errors.append(error)
        with patch('boiling_automation.gui.lvm_to_csv',side_effect=convert):
            worker=threading.Thread(target=export);worker.start()
            try:
                self.assertTrue(entered.wait(2));self.assertTrue(self.s.snapshot()['postprocessing_busy'])
                with self.assertRaisesRegex(ValueError,'파일 변환'):self.s.start({'critical_c':200})
                with self.assertRaisesRegex(ValueError,'파일 변환'):self.s.start_calibration_capture({'source':'demo'})
            finally:release.set();worker.join(5)
        self.assertFalse(errors);self.assertFalse(self.s.snapshot()['postprocessing_busy'])
        self.run_complete()

    def test_conversion_failure_releases_lease(self):
        self.run_complete()
        with patch('boiling_automation.gui.lvm_to_csv',side_effect=OSError('conversion failed')):
            with self.assertRaisesRegex(OSError,'conversion failed'):self.s.export_measurements('raw')
        self.assertEqual(self.s.postprocessing_count,0)
        self.run_complete()

    def test_calibration_capture_blocks_all_large_exports(self):
        with patch.object(threading.Thread,'start'):
            self.s.start_calibration_capture({'source':'demo','window_s':10})
        for export in (self.s.export,lambda:self.s.export_measurements('raw'),self.s.export_calibration_capture):
            with self.assertRaisesRegex(ValueError,'측정 중'):export()

    def test_summary_csv_waits_until_input_generator_has_closed(self):
        input_closed=threading.Event();inspected=threading.Event();checks=[]
        def readings(*args,**kwargs):
            input_closed.clear()
            try:
                for t in range(100):
                    if self.s.cancel.is_set():break
                    yield Reading(t,(99.,)*8,bulk_temperatures_c=(99.,)*4)
                    if t==90:
                        # The stage is visible/logged but CSV bodies are still empty.
                        checks.append((len(self.s.controller.records),self.s.writer.saved_stage_records))
                        inspected.set()
            finally:input_closed.set()
        original=ResultWriter._flush_stage_csv
        def flush(writer):
            if writer.pending_stage_records:self.assertTrue(input_closed.is_set())
            return original(writer)
        with patch('boiling_automation.gui.csv_readings',side_effect=readings),patch.object(ResultWriter,'_flush_stage_csv',flush):
            self.s.start({'source':'csv','csv_text':source(100),'critical_c':200,'allowed_std_c':.1,'max_power_percent':1,'speed':300})
            self.s.worker.join(5)
        self.assertTrue(inspected.is_set());self.assertEqual(checks,[(1,0)])
        rows=list(csv.DictReader(io.StringIO((self.s.writer.directory/'stages.csv').read_text())))
        self.assertEqual(len(rows),1);self.assertEqual(self.s.writer.saved_stage_records,1)
        self.assertTrue(self.s.writer.closed)

    def test_close_error_closes_every_remaining_stream_and_reports_first_failure(self):
        writer=ResultWriter(self.root/'isolated',Config(200),'demo')
        first=writer.streams[0]
        with patch.object(first,'close',side_effect=OSError('first close failed')):
            with self.assertRaisesRegex(OSError,'first close failed'):writer.close()
        self.assertTrue(writer.closed);self.assertTrue(all(s.closed for s in writer.streams[1:]))
        first.close()

    def test_summary_failure_is_visible_and_full_lvm_remains_readable(self):
        original=ResultWriter._flush_stage_csv
        def fail(writer):
            if writer.pending_stage_records:raise OSError('summary disk failed')
            return original(writer)
        with patch.object(ResultWriter,'_flush_stage_csv',fail):self.run_complete()
        s=self.s.snapshot()
        self.assertIn('summary disk failed',s['error']);self.assertFalse(s['running'])
        self.assertTrue(self.s.writer.closed);self.assertTrue(all(f.closed for f in self.s.writer.streams))
        body,_=self.s.export_measurements('raw',format='lvm')
        self.assertEqual(len(list(measurement_rows(body))),91)

    def test_stop_waits_for_ni_task_release_before_summary_close_and_exports(self):
        received=threading.Event();closing=threading.Event();release=threading.Event()
        def readings(settings,cancel,**kwargs):
            try:
                yield Reading(0,(99.,)*8,bulk_temperatures_c=(99.,)*4)
                received.set();cancel.wait(5)
            finally:closing.set();release.wait(5)
        settings={'physical_channels':[f'Dev1/ai{i}' for i in range(12)],'thermocouple_types':['K']*12}
        with patch('boiling_automation.gui.load_driver'),patch('boiling_automation.gui.ni_readings',side_effect=readings):
            self.s.start({'source':'ni','ni_settings':settings,'critical_c':200})
            try:
                self.assertTrue(received.wait(2));self.s.stop();self.assertTrue(closing.wait(2))
                self.assertTrue(self.s.snapshot()['finalizing']);self.assertFalse(self.s.writer.closed)
                with self.assertRaisesRegex(ValueError,'종료'):self.s.export()
                with self.assertRaisesRegex(ValueError,'종료'):self.s.start_calibration_capture({'source':'demo'})
                with self.assertRaisesRegex(ValueError,'종료'):self.s.return_to_standby({'run_name':self.s.writer.directory.name})
            finally:release.set();self.s.worker.join(5)
        self.assertFalse(self.s.snapshot()['finalizing']);self.assertTrue(self.s.writer.closed)
        self.assertEqual(len(list(measurement_rows(self.s.export_measurements('raw',format='lvm')[0]))),1)

    def test_partial_summary_write_rolls_back_and_retry_does_not_duplicate_rows(self):
        writer=ResultWriter(self.root/'transaction',Config(200,allowed_std_c=.1,max_power_percent=0),'demo')
        controller=ReplayController(Config(200,allowed_std_c=.1,max_power_percent=0))
        try:
            for t in range(91):writer.write(controller.process(Reading(t,(99.,)*8)))
            self.assertEqual(writer.saved_stage_records,0)
            stage_before=(writer.directory/'stages.csv').read_bytes()
            samples_before=(writer.directory/'selected_samples.csv').read_bytes()
            class PartialFailure:
                def writerow(_,row):
                    writer.samples.write('partial bad row\n');raise OSError('sample row failed')
            real=writer.sample_csv;writer.sample_csv=PartialFailure()
            with self.assertRaisesRegex(OSError,'sample row failed'):writer.flush()
            self.assertEqual((writer.directory/'stages.csv').read_bytes(),stage_before)
            self.assertEqual((writer.directory/'selected_samples.csv').read_bytes(),samples_before)
            writer.sample_csv=real;writer.flush();writer.flush()
            self.assertEqual(len(list(csv.DictReader(io.StringIO((writer.directory/'stages.csv').read_text())))),1)
            self.assertEqual(len(list(csv.DictReader(io.StringIO((writer.directory/'selected_samples.csv').read_text())))),21)
        finally:writer.close()

    def test_furnace_ten_second_evidence_fits_saves_loads_and_applies(self):
        for reference in (100,120):
            self.s.start_calibration_capture({'purpose':'furnace','source':'csv','csv_text':source(11,reference-2),
                                             'window_s':10,'speed':300})
            self.s.capture_worker.join(5);capture=self.s.calibration_capture
            ds=self.s.initial_dataset
            self.s.update_initial_data({'expected_dataset_id':ds.dataset_id,'expected_revision':ds.revision,
                'action':'add_capture','capture_id':capture.capture_id,'reference_c':reference})
        for kind in ('json','csv'):
            restored=import_dataset(self.s.export_initial_data(kind).decode(),kind)
            self.assertEqual([p.evidence.window_s for p in restored.points],[10,10])
        ds=self.s.initial_dataset;version={'expected_dataset_id':ds.dataset_id,'expected_revision':ds.revision}
        self.s.fit_initial_data(version)
        self.s.activate_initial_calibration({**version,'action':'apply','fit_id':self.s.initial_fit.profile_id,
                                            'expected_profile_id':self.s.temperature_calibration.profile_id})
        restored=GuiSession(self.root)
        self.assertEqual([p.evidence.window_s for p in restored.initial_dataset.points],[10,10])
        self.assertAlmostEqual(restored.temperature_calibration.correct_value(108,0),110)
        self.assertEqual(restored.temperature_calibration.correct_value(98,8),98)


class LiveConversionHttpTests(unittest.TestCase):
    def test_direct_http_converter_rejects_active_input_before_parsing_file(self):
        with tempfile.TemporaryDirectory() as folder:
            server=GuiServer(('127.0.0.1',0),Path(folder));worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
            with patch.object(threading.Thread,'start'):
                server.session.start({'critical_c':200})
            server.session.worker=None
            connection=http.client.HTTPConnection(*server.server_address)
            try:
                with patch('boiling_automation.gui.flatten_input') as converter:
                    connection.request('POST','/api/measurements/flatten',json.dumps({'text':source(1)}),{'X-App-Token':server.token})
                    response=connection.getresponse();body=json.loads(response.read())
                    self.assertEqual(response.status,400);self.assertIn('측정 중',body['error']);converter.assert_not_called()
                self.assertTrue(server.session.running)
            finally:
                connection.close();server.session.stop();server.shutdown();server.server_close();worker.join(3)
