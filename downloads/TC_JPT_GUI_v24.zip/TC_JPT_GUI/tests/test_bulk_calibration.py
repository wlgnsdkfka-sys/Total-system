"""Bulk is excluded from furnace acquisition/fitting and uses a 100 C offset only."""
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
import csv,hashlib,io,json,math,tempfile,unittest,zipfile
from unittest.mock import patch
from boiling_automation.calibration_capture import CalibrationCapture,CaptureConfig
from boiling_automation.calibration_common import ReferenceEvidence
from boiling_automation.initial_calibration import (CalibrationDataset,CalibrationPoint,InitialProfile,fit_dataset,
                                                  import_dataset,dataset_csv)
from boiling_automation.temperature_calibration import TemperatureCalibration
from boiling_automation.gui import GuiSession,csv_readings
from boiling_automation.ni_temperature import NISettings,DEFAULT_CHANNELS,readings
from boiling_automation.core import Reading


def dataset(gain=1.1):
    return CalibrationDataset('eight',0,tuple(CalibrationPoint('p'+str(i),v,((v+2)/gain,)*8,'test','')
                 for i,v in enumerate((99.,110.,130.))))

def legacy():
    points=[]
    for i,v in enumerate((99.,110.,130.)):
        points.append({'point_id':'p'+str(i),'reference_c':v,
          'raw_c':[(v+2-j*.1)/(1.1+j*.01) for j in range(12)],'source':'v11','created_at':'2026-10-22',
          'note':'','std_c':[],'evidence':None})
    fingerprint=hashlib.sha256(json.dumps(points,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    channels=[{'gain':1.1+i*.01,'intercept_c':-2+i*.1,'rmse_c':0.,'max_error_c':0.,'r_squared':1.,
               'raw_min_c':points[0]['raw_c'][i],'raw_max_c':points[-1]['raw_c'][i]} for i in range(12)]
    model={'profile_id':'v11_model','dataset_id':'v11_dataset','dataset_fingerprint':fingerprint,'created_at':'2026-10-22',
           'channels':channels,'points':points,'method':'affine_least_squares','range_policy':'linear_extrapolation'}
    return model

class BulkMathTests(unittest.TestCase):
    def test_furnace_affects_only_tc1_to_eight(self):
        p=TemperatureCalibration(initial_calibration=fit_dataset(dataset()))
        raw=Reading(0,(110,)*8,bulk_temperatures_c=(98.7,99.2,97.9,None));out=p.apply(raw)
        self.assertAlmostEqual(out.temperatures_c[0],119)
        self.assertEqual(out.bulk_temperatures_c,raw.bulk_temperatures_c)
        self.assertEqual(out.raw_bulk_temperatures_c,raw.bulk_temperatures_c)
        for i in range(8,12):self.assertEqual(p.raw_for_corrected(101,i),101)
    def test_legacy_model_checks_full_integrity_then_keeps_only_eight_coefficients(self):
        model=legacy();new=InitialProfile.from_dict(model)
        self.assertEqual(len(new.channels),8);self.assertTrue(all(len(p.raw_c)==8 for p in new.points))
        for i,c in enumerate(new.channels):self.assertAlmostEqual(c.gain,model['channels'][i]['gain'])
        self.assertEqual(InitialProfile.from_dict(new.to_dict()),new)
        model['channels'][11]['gain']+=.1
        with self.assertRaises(ValueError):InitialProfile.from_dict(model)
    def test_legacy_combined_profile_rebases_bulk_to_raw_plus_offset(self):
        model=legacy();raw=[(102+2-i*.1)/(1.1+i*.01) for i in range(12)]
        old={'enabled':True,'reference_c':100.,'reference_raw_c':raw,'offsets_c':[-2.]*12,
             'profile_id':'old_combined','created_at':'','source':'v11','reference_evidence':None,'initial_calibration':model}
        p=TemperatureCalibration.from_dict(old)
        for i in range(12):self.assertAlmostEqual(p.correct_value(raw[i],i),100)
        for i in range(8,12):self.assertAlmostEqual(p.correct_value(raw[i]+.5,i),100.5)
        self.assertEqual(TemperatureCalibration.from_dict(p.to_dict()),p)
        self.assertTrue(all(math.isclose(v,-2,abs_tol=1e-9) for v in p.offsets_c[:8]))
    def test_bulk_reference_is_one_hundred_even_when_surface_reference_differs(self):
        old={'enabled':True,'reference_c':95.,'reference_raw_c':[99.]*12,'offsets_c':[-4.]*12}
        p=TemperatureCalibration.from_dict(old)
        self.assertEqual(p.correct_value(99,0),95);self.assertEqual(p.correct_value(99,8),100)
        saved=p.to_dict();saved['offsets_c']=(-4.,)*12
        with self.assertRaises(ValueError):TemperatureCalibration.from_dict(saved)
    def test_legacy_json_and_csv_keep_main_points_without_bulk_fit(self):
        old=legacy();v={'schema':'tc_initial_calibration_dataset','schema_version':1,'dataset_id':'old','revision':0,'points':old['points']}
        ds=import_dataset(json.dumps(v),'json');self.assertTrue(all(len(p.raw_c)==8 for p in ds.points))
        out=ds.to_dict();self.assertEqual(out['schema_version'],2);self.assertEqual(out['channel_names'],['TC'+str(i) for i in range(1,9)])
        self.assertEqual(import_dataset(json.dumps(out),'json').points,ds.points)
        csv_text=dataset_csv(ds).decode('utf-8-sig');self.assertNotIn('TC9_raw_c',csv_text)
        self.assertEqual(import_dataset(csv_text,'csv').points,ds.points)
    def test_legacy_evidence_is_retained_as_original_provenance(self):
        old=legacy()['points'][0];old['std_c']=[0.]*12
        ev=ReferenceEvidence('capture','reference','csv',0,180,180,181,tuple(old['raw_c']),(0.,)*12,(0.,)*12,.1,.5,'now','a'*64)
        old['evidence']=asdict(ev)
        ds=import_dataset(json.dumps({'schema':'tc_initial_calibration_dataset','schema_version':1,'points':[old]}),'json')
        p=ds.points[0];self.assertEqual(len(p.raw_c),8);self.assertEqual(p.std_c,(0.,)*8)
        self.assertEqual(p.evidence,ev);self.assertEqual(p.evidence.samples_sha256,'a'*64)
        self.assertEqual(import_dataset(dataset_csv(ds).decode('utf-8-sig'),'csv').points,ds.points)
    def test_furnace_csv_ignores_unneeded_bulk_columns_including_invalid_strings(self):
        text='t_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n0,'+','.join(['99']*8+['disconnected','nan','','invalid'])+'\n'
        p=next(csv_readings(text,include_bulk=False));self.assertEqual(p.temperatures_c,(99,)*8);self.assertEqual(p.bulk_temperatures_c,())
        with self.assertRaises(ValueError):next(csv_readings(text))

class BulkSessionTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.s=GuiSession(Path(self.tmp.name))
    def tearDown(self):
        self.s.stop()
        for w in (self.s.worker,self.s.capture_worker):
            if w and w.is_alive():w.join(5)
        self.tmp.cleanup()
    def expected(self):return {'expected_dataset_id':self.s.initial_dataset.dataset_id,'expected_revision':self.s.initial_dataset.revision}
    def activate(self,gain):
        self.s.update_initial_data({**self.expected(),'action':'import','format':'json','text':json.dumps(dataset(gain).to_dict())})
        self.s.fit_initial_data(self.expected())
        self.s.activate_initial_calibration({**self.expected(),'action':'apply','fit_id':self.s.initial_fit.profile_id,
            'expected_profile_id':self.s.temperature_calibration.profile_id})
    def test_boiling_bulk_calibrates_to_one_hundred_then_tracks_actual_change(self):
        self.activate(1.1);raw=[104/1.1]*8+[98.7,99.2,97.9,99.9]
        self.s.save_temperature_calibration({'action':'apply','reference_c':110,'reference_raw_c':raw,
            'expected_profile_id':self.s.temperature_calibration.profile_id})
        p=self.s.temperature_calibration
        for i in range(8):self.assertAlmostEqual(p.correct_value(raw[i],i),110)
        for i in range(8,12):
            self.assertAlmostEqual(p.correct_value(raw[i],i),100)
            self.assertAlmostEqual(p.correct_value(raw[i]+.75,i),100.75)
        self.assertAlmostEqual(p.offsets_c[8],1.3)
    def test_apply_disable_or_change_furnace_model_never_changes_bulk_offsets(self):
        self.s.save_temperature_calibration({'action':'apply','reference_c':100,'reference_raw_c':[99]*8+[98.7,99.2,97.9,99.9],
            'expected_profile_id':self.s.temperature_calibration.profile_id})
        offsets=self.s.temperature_calibration.offsets_c[8:]
        for gain in (1.1,1.2):
            self.activate(gain);self.assertEqual(self.s.temperature_calibration.offsets_c[8:],offsets)
        self.s.activate_initial_calibration({'action':'disable','expected_profile_id':self.s.temperature_calibration.profile_id})
        self.assertEqual(self.s.temperature_calibration.offsets_c[8:],offsets)
        self.s.save_temperature_calibration({'action':'disable','expected_profile_id':self.s.temperature_calibration.profile_id})
        self.assertEqual(self.s.temperature_calibration.correct_value(98.7,8),98.7)
    def test_furnace_stability_and_export_require_only_eight_channels(self):
        cap=CalibrationCapture(self.s.results_root/'furnace',CaptureConfig(),'csv',300,purpose='furnace')
        self.s.calibration_capture=cap;self.s.calibration_captures['furnace']=cap
        for t in range(181):cap.observe(Reading(t,(99.,)*8,bulk_temperatures_c=(float('nan'),None,t,0)))
        self.assertTrue(cap.stable);self.assertEqual(len(cap.stats['std_c']),8)
        self.s.update_initial_data({**self.expected(),'action':'add_capture','capture_id':cap.capture_id,'reference_c':100})
        self.assertEqual(len(self.s.initial_dataset.points[0].raw_c),8)
        cap.finish('user_stop')
        body,_=self.s.export_calibration_capture('furnace')
        with zipfile.ZipFile(io.BytesIO(body)) as z:
            rows=list(csv.DictReader(io.StringIO(z.read('raw_samples.csv').decode())))
            self.assertNotIn('TC9',rows[0]);self.assertEqual(len(rows),181)
            meta=json.loads(z.read('capture.json'));self.assertEqual(len(meta['channel_names']),8)
        cap.finish('user_stop')
    def test_furnace_replay_with_no_bulk_columns_collects_and_adds_point(self):
        text='t_s,'+','.join('TC'+str(i) for i in range(1,9))+'\n'+'\n'.join(str(t)+','+','.join(['99']*8) for t in range(181))
        self.s.start_calibration_capture({'source':'csv','purpose':'furnace','speed':300,'csv_text':text})
        self.s.capture_worker.join(5);self.assertTrue(self.s.calibration_capture.stable)
        cap=self.s.calibration_capture
        self.s.update_initial_data({**self.expected(),'action':'add_capture','capture_id':cap.capture_id,'reference_c':100})
        self.assertEqual(self.s.initial_dataset.points[0].raw_c,(99,)*8)
    def test_offset_still_requires_all_twelve_channels(self):
        cap=CalibrationCapture(self.s.results_root/'offset',CaptureConfig(),'csv',300,purpose='offset')
        try:
            with self.assertRaises(ValueError):cap.observe(Reading(0,(99,)*8))
            for t in range(181):cap.observe(Reading(t,(99,)*8,bulk_temperatures_c=(99,99,99,99+t*.1)))
            self.assertFalse(cap.stable)
        finally:cap.finish('user_stop')

class BulkNITests(unittest.TestCase):
    def test_furnace_creates_only_eight_ai_channels_and_accepts_eight_readings(self):
        task=SimpleNamespace();channels=[];closed=[];clock=[0.];waits=[0]
        class Task:
            ai_channels=SimpleNamespace(add_ai_thrmcpl_chan=lambda *args,**kwargs:(channels.append((args,kwargs)),SimpleNamespace())[1])
            def __enter__(self):return self
            def __exit__(self,*args):closed.append(True)
            def start(self):pass
            def read(self,**kwargs):return [99.]*8
        class Cancel:
            def is_set(self):return False
            def wait(self,delay):
                clock[0]+=delay;waits[0]+=1;return waits[0]>=3
        constants=SimpleNamespace(TemperatureUnits=SimpleNamespace(DEG_C='C'),ThermocoupleType=SimpleNamespace(K='K'),CJCSource=SimpleNamespace(BUILT_IN='builtIn'),ADCTimingMode=SimpleNamespace(HIGH_RESOLUTION='highResolution'))
        payload={'physical_channels':DEFAULT_CHANNELS[:8],'thermocouple_types':['K']*8}
        settings=NISettings.from_payload(payload,8)
        with patch('boiling_automation.ni_temperature.time.monotonic',side_effect=lambda:clock[0]), patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=Task),constants)):
            rows=list(readings(settings,Cancel()))
        self.assertEqual(len(channels),8);self.assertEqual(rows[0].bulk_temperatures_c,());self.assertTrue(closed)
        with self.assertRaises(ValueError):NISettings.from_payload(payload,12)
        payload['physical_channels']=DEFAULT_CHANNELS;payload['thermocouple_types']=['K']*12
        with self.assertRaises(ValueError):NISettings.from_payload(payload,8)

if __name__=='__main__':unittest.main()
