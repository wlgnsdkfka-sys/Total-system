from concurrent.futures import Future
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from boiling_automation.core import Config,Reading,ReplayController,_analyse_stage
from boiling_automation.gui import GuiSession
from boiling_automation.leak import FluxMonitor,LeakConfig
from boiling_automation.calculation import default_settings
from boiling_automation.ni_temperature import DEFAULT_CHANNELS


class ControlledExecutor:
    def __init__(self):self.future=Future();self.call=None
    def submit(self,fn,*args):self.call=(fn,args);return self.future
    def finish(self):
        fn,args=self.call;self.future.set_result(fn(*args))


class BackgroundStageTests(unittest.TestCase):
    def test_measurements_continue_at_same_power_until_record_and_leak_reference_are_ready(self):
        executor=ControlledExecutor();monitor=FluxMonitor(LeakConfig(),default_settings())
        c=ReplayController(Config(200,allowed_std_c=.1,max_power_percent=1),monitor,stage_executor=executor)
        for t in range(91):events=c.process(Reading(t,(100.,)*8))
        self.assertTrue(any(e.kind=='stage_analysis_pending' for e in events))
        self.assertEqual(c.records,[]);self.assertEqual(c.power_percent,0)
        self.assertEqual(c.process(Reading(90.1,(100.,)*8)),[])
        self.assertEqual(c._last_reading.t_s,90.1);self.assertEqual(c.power_percent,0)
        executor.finish();events=c.process(Reading(90.2,(100.,)*8))
        self.assertEqual([e.kind for e in events],['observation_recorded','simulated_power_increased'])
        self.assertEqual(c.records[0].recorded_at_s,90.)
        self.assertEqual(c.records[0].segment.end_s,90.)
        self.assertEqual(c._step_started_s,90.2)
        self.assertEqual(monitor.reference['power_percent'],0)
        self.assertEqual(monitor.noise_reference['source'],'selected_segment')
        self.assertEqual(c.power_percent,1)

    def test_trip_has_priority_over_pending_analysis_and_late_results_never_increase_power(self):
        executor=ControlledExecutor()
        c=ReplayController(Config(200,allowed_std_c=.1,max_power_percent=1),stage_executor=executor)
        for t in range(91):c.process(Reading(t,(100.,)*8))
        events=c.process(Reading(90.1,(250.,)*8))
        self.assertEqual(events[0].details['reason'],'critical_temperature')
        executor.finish();events=c.collect_analysis(wait=True)
        self.assertEqual([e.kind for e in events],['observation_recorded'])
        self.assertEqual(c.state,'tripped');self.assertEqual(c.power_index_percent,-1)

    def test_ni_worker_keeps_reading_and_requests_shutdown_while_analysis_is_blocked(self):
        with tempfile.TemporaryDirectory() as folder:
            s=GuiSession(Path(folder));entered=threading.Event();release=threading.Event()
            advanced=threading.Event();hot=threading.Event();closed=threading.Event()
            def analyse(*args):
                entered.set();release.wait(2);return _analyse_stage(*args)
            def source(settings,cancel,*,mode,on_configured):
                on_configured({'sample_rate_hz_per_channel':10,'mode':'experiment'})
                for i in range(906):
                    if cancel.is_set():return
                    yield Reading(i/10,(100.,)*8,bulk_temperatures_c=(99.,)*4)
                advanced.set()
                while not hot.wait(.001):
                    if cancel.is_set():return
                yield Reading(90.6,(250.,)*8,bulk_temperatures_c=(99.,)*4)
            original=s.manual_controls.request_close
            def close(reason,*args,**kwargs):
                original(reason,*args,**kwargs)
                if reason=='critical_temperature':closed.set()
            with patch('boiling_automation.gui.load_driver'),patch('boiling_automation.gui.ni_readings',side_effect=source), \
                    patch('boiling_automation.core._analyse_stage',side_effect=analyse), \
                    patch.object(s.manual_controls,'request_close',side_effect=close):
                try:
                    s.start({'source':'ni','critical_c':200,'allowed_std_c':.1,'max_power_percent':1,'speed':1,
                             'ni_settings':{'physical_channels':DEFAULT_CHANNELS,'thermocouple_types':['K']*12}})
                    self.assertTrue(entered.wait(2));self.assertTrue(advanced.wait(1))
                    self.assertTrue(s.snapshot()['stage_analysis_pending'])
                    self.assertEqual(s.snapshot()['latest']['t_s'],90.5)
                    hot.set();self.assertTrue(closed.wait(1))
                finally:release.set();hot.set();s.worker.join(5)
            result=s.snapshot()
            self.assertFalse(s.worker.is_alive());self.assertEqual(result['reason'],'critical_temperature')
            self.assertEqual(len(result['records']),1)
            self.assertFalse(any(e['kind']=='simulated_power_increased' for e in result['events']))
