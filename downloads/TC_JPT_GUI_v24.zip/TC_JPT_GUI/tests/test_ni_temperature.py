from types import SimpleNamespace
import unittest
from unittest.mock import patch

from boiling_automation.ni_temperature import NISettings,DEFAULT_CHANNELS,readings,load_driver


class Cancel:
    def __init__(self,clock,limit=3):self.stopped=False;self.clock=clock;self.limit=limit;self.waits=0
    def is_set(self):return self.stopped
    def wait(self,delay):
        self.clock[0]+=delay;self.waits+=1
        self.stopped=self.limit is not None and self.waits>=self.limit
        return self.stopped


class FakeTask:
    def __init__(self,values=None,failure=None):
        self.channels=[];self.started=False;self.closed=False;self.failure=failure;self.read_calls=[];self.clock_request=None;self.committed=None
        self.timing=SimpleNamespace(samp_clk_max_rate=8.,samp_clk_rate=7.5,cfg_samp_clk_timing=self.configure_clock)
        self.in_stream=SimpleNamespace(avail_samp_per_chan=0)
        self.values=values if values is not None else [99+i*.1 for i in range(12)]
        self.ai_channels=SimpleNamespace(add_ai_thrmcpl_chan=self.add)
    def add(self,*args,**kwargs):
        channel=SimpleNamespace();self.channels.append((args,kwargs,channel));return channel
    def configure_clock(self,*args,**kwargs):self.clock_request=(args,kwargs)
    def control(self,mode):self.committed=mode
    def __enter__(self):return self
    def __exit__(self,*args):self.closed=True
    def start(self):self.started=True
    def read(self,**kwargs):
        self.read_calls.append(kwargs)
        if self.failure:raise self.failure
        return self.values


def constants():
    return SimpleNamespace(TemperatureUnits=SimpleNamespace(DEG_C='degC'),
        ThermocoupleType=SimpleNamespace(**{k:k for k in ('B','E','J','K','N','R','S','T')}),
        CJCSource=SimpleNamespace(BUILT_IN='builtIn'),
        ADCTimingMode=SimpleNamespace(HIGH_RESOLUTION='highResolution',HIGH_SPEED='highSpeed'),
        AcquisitionType=SimpleNamespace(CONTINUOUS='continuous'),TaskMode=SimpleNamespace(TASK_COMMIT='commit'))


class NIReadOnlyTests(unittest.TestCase):
    def setUp(self):
        self.clock=[0.]
        patcher=patch('boiling_automation.ni_temperature.time.monotonic',side_effect=lambda:self.clock[0]);patcher.start();self.addCleanup(patcher.stop)
    def cancel(self,limit=3):return Cancel(self.clock,limit)
    def settings(self,**extra):return NISettings(DEFAULT_CHANNELS,('K',)*12,**extra)
    def test_candidate_channel_order_and_cold_junction_units_are_explicit(self):
        task=FakeTask();cancel=self.cancel()
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            rows=list(readings(self.settings(),cancel))
        self.assertEqual(len(rows),1);self.assertTrue(task.started);self.assertTrue(task.closed)
        self.assertEqual(len(task.channels),12)
        self.assertEqual([row[0][0] for row in task.channels],list(DEFAULT_CHANNELS))
        self.assertEqual([row[0][0] for row in task.channels][-4:],['cDAQ1Mod3/ai15','cDAQ1Mod3/ai14','cDAQ1Mod3/ai13','cDAQ1Mod3/ai12'])
        self.assertTrue(all(v[1]['units']=='degC' and v[1]['cjc_source']=='builtIn' for v in task.channels))
        self.assertEqual(rows[0].temperatures_c[0],99);self.assertEqual(rows[0].bulk_temperatures_c[-1],100.1)
        self.assertEqual(rows[0].t_s,0)
    def test_task_is_closed_on_bad_shape_out_of_range_or_driver_failure(self):
        for values,failure in (([100]*11,None),([float('nan')]*12,None),([9999]*12,None),(None,RuntimeError('read failed'))):
            task=FakeTask(values,failure)
            with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
                with self.assertRaises((ValueError,RuntimeError)):list(readings(self.settings(),self.cancel()))
            self.assertTrue(task.closed)
    def test_closing_generator_releases_ni_resource(self):
        task=FakeTask()
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            source=readings(self.settings(),self.cancel());next(source);source.close()
        self.assertTrue(task.closed)
    def test_cancel_before_start_does_not_start_ai(self):
        task=FakeTask();cancel=self.cancel();cancel.stopped=True
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            self.assertEqual(list(readings(self.settings(),cancel)),[])
        self.assertFalse(task.started);self.assertTrue(task.closed)
    def test_mixed_thermocouple_types_are_supported(self):
        task=FakeTask();settings=NISettings(DEFAULT_CHANNELS,('K',)*8+('T',)*4)
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            list(readings(settings,self.cancel()))
        self.assertEqual([c[1]['thermocouple_type'] for c in task.channels],['K']*8+['T']*4)
    def test_startup_transients_are_discarded_before_validation_and_elapsed_origin(self):
        task=FakeTask();sequence=iter([[9999]*12,[float('nan')]*12,[100]*12])
        with patch.object(task,'read',side_effect=lambda **kwargs:next(sequence)), patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            rows=list(readings(self.settings(),self.cancel()))
        self.assertEqual(len(rows),1);self.assertEqual(rows[0].t_s,0)
        self.assertEqual(rows[0].temperatures_c,(100,)*8)
        self.assertGreaterEqual(self.clock[0],2)
        self.assertTrue(all(c[2].ai_adc_timing_mode=='highResolution' for c in task.channels))
        self.assertIsNone(task.clock_request)
    def test_slow_first_conversion_is_also_discarded(self):
        task=FakeTask();first=[True]
        def read(**kwargs):
            if first[0]:first[0]=False;self.clock[0]+=3;return [9999]*12
            return [100]*12
        with patch.object(task,'read',side_effect=read), patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            source=readings(self.settings(),self.cancel());row=next(source);source.close()
        self.assertEqual(row.t_s,0);self.assertEqual(row.temperatures_c,(100,)*8);self.assertTrue(task.closed)
    def test_cancel_during_startup_excludes_all_samples_and_releases_task(self):
        task=FakeTask(values=[9999]*12)
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            self.assertEqual(list(readings(self.settings(),self.cancel(1))),[])
        self.assertTrue(task.closed)
    def test_persistent_bad_input_after_startup_identifies_channel_value_and_bounds(self):
        task=FakeTask(values=[100]*8+[1200]+[100]*3)
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            with self.assertRaisesRegex(ValueError,r'TC9.*cDAQ1Mod3/ai15.*1200.*0~300'):
                list(readings(self.settings(),self.cancel()))
        self.assertTrue(task.closed)
    def test_fast_input_uses_driver_limit_committed_rate_hardware_time_and_no_sleep(self):
        task=FakeTask();cancel=self.cancel(None);configured=[]
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            source=readings(self.settings(),cancel,mode='experiment',on_configured=configured.append)
            rows=[next(source) for _ in range(3)];source.close()
        self.assertEqual([r.t_s for r in rows],[0,1/7.5,2/7.5])
        self.assertEqual(cancel.waits,0);self.assertTrue(task.closed)
        self.assertTrue(all(c[2].ai_adc_timing_mode=='highSpeed' for c in task.channels))
        self.assertEqual(task.clock_request[0],(8.,));self.assertEqual(task.committed,'commit')
        self.assertEqual(configured[0]['sample_rate_hz_per_channel'],7.5)
        self.assertEqual(configured[0]['target_sample_rate_hz_per_channel'],20.)
        self.assertEqual(configured[0]['requested_sample_rate_hz_per_channel'],8.)
        self.assertEqual(configured[0]['startup_discard_s'],0)
        self.assertTrue(all(c['number_of_samples_per_channel']==1 for c in task.read_calls))
    def test_experiment_requests_twenty_hz_hardware_clock_and_keeps_every_frame(self):
        task=FakeTask();task.timing.samp_clk_max_rate=100.;task.timing.samp_clk_rate=20.
        configured=[];cancel=self.cancel(None)
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            source=readings(self.settings(),cancel,mode='experiment',on_configured=configured.append)
            rows=[next(source) for _ in range(4)];source.close()
        self.assertEqual(task.clock_request[0],(20.,))
        self.assertEqual([r.t_s for r in rows],[0.,.05,.1,.15])
        self.assertEqual(len(task.read_calls),4);self.assertEqual(cancel.waits,0)
        self.assertEqual(configured[0]['max_supported_sample_rate_hz_per_channel'],100.)
        self.assertEqual(configured[0]['requested_sample_rate_hz_per_channel'],20.)
        self.assertEqual(configured[0]['sample_rate_hz_per_channel'],20.)
    def test_hardware_coercion_is_reported_and_timestamped_using_actual_rate(self):
        task=FakeTask();task.timing.samp_clk_max_rate=100.;task.timing.samp_clk_rate=19.2;configured=[]
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            source=readings(self.settings(),self.cancel(None),mode='experiment',on_configured=configured.append)
            rows=[next(source) for _ in range(3)];source.close()
        self.assertEqual(task.clock_request[0],(20.,))
        self.assertEqual(configured[0]['sample_rate_hz_per_channel'],19.2)
        self.assertEqual(rows[2].t_s,2/19.2)
    def test_user_selected_rates_reach_the_hardware_clock_with_device_limit(self):
        for target,request in ((5.,5.),(12.5,12.5),(40.,40.),(150.,100.)):
            task=FakeTask();task.timing.samp_clk_max_rate=100.;task.timing.samp_clk_rate=request;configured=[]
            with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
                source=readings(self.settings(sample_rate_hz=target),self.cancel(None),mode='experiment',on_configured=configured.append)
                next(source);source.close()
            self.assertEqual(task.clock_request[0],(request,))
            self.assertEqual(configured[0]['target_sample_rate_hz_per_channel'],target)
            self.assertEqual(configured[0]['requested_sample_rate_hz_per_channel'],request)
    def test_invalid_sampling_rates_are_rejected_before_any_task_is_created(self):
        for target in (0,.49,-1,True,float('nan'),float('inf'),'20'):
            with self.assertRaises(ValueError):self.settings(sample_rate_hz=target)
    def test_twenty_hz_backlog_limit_still_represents_two_seconds(self):
        for queued in (40,41):
            task=FakeTask();task.timing.samp_clk_max_rate=100.;task.timing.samp_clk_rate=20.
            task.in_stream.avail_samp_per_chan=queued
            with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
                source=readings(self.settings(),self.cancel(None),mode='experiment')
                if queued==40:next(source);source.close();self.assertEqual(len(task.read_calls),1)
                else:
                    with self.assertRaisesRegex(ValueError,'2초 이상 지연'):next(source)
                    self.assertEqual(task.read_calls,[])
    def test_fast_mode_does_not_discard_a_first_critical_or_invalid_value(self):
        task=FakeTask(values=[9999]*12)
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            with self.assertRaisesRegex(ValueError,'TC1'):
                next(readings(self.settings(),self.cancel(None),mode='experiment'))
        self.assertEqual(len(task.read_calls),1);self.assertTrue(task.closed)
    def test_fast_mode_refuses_a_backlog_instead_of_presenting_old_data_as_live(self):
        task=FakeTask();task.in_stream.avail_samp_per_chan=16
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            with self.assertRaisesRegex(ValueError,'2초 이상 지연') as caught:
                next(readings(self.settings(),self.cancel(None),mode='experiment'))
            self.assertIn('대기 16샘플/채널',str(caught.exception))
            self.assertIn('추정 대기',str(caught.exception))
        self.assertEqual(task.read_calls,[]);self.assertTrue(task.closed)
    def test_invalid_fast_rate_fails_without_starting_task(self):
        for rate in (0,float('nan'),.1):
            task=FakeTask();task.timing.samp_clk_max_rate=rate
            with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
                with self.assertRaises(ValueError):next(readings(self.settings(),self.cancel(None),mode='experiment'))
            self.assertFalse(task.started);self.assertTrue(task.closed)
    def test_discarded_startup_is_absent_from_saved_data_and_three_minute_reference(self):
        import csv,io,json,tempfile
        from pathlib import Path
        from boiling_automation.calibration_capture import CalibrationCapture,CaptureConfig
        task=FakeTask();calls=[0]
        def sample(**kwargs):
            calls[0]+=1
            return [9999]*12 if calls[0]<=2 else [100]*12
        with tempfile.TemporaryDirectory() as folder:
            capture=CalibrationCapture(Path(folder)/'capture',CaptureConfig(),'ni',1)
            try:
                with patch.object(task,'read',side_effect=sample),patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
                    source=readings(self.settings(),self.cancel(183))
                    for n,row in enumerate(source):
                        capture.observe(row)
                        if n<180:self.assertFalse(capture.stable)
                self.assertEqual(capture.count,181);self.assertTrue(capture.stable)
                ref=capture.select_reference();self.assertEqual(ref['evidence']['start_s'],0)
                self.assertEqual(ref['evidence']['end_s'],180)
                capture.finish()
                saved=list(csv.DictReader(io.StringIO((capture.directory/'raw_samples.csv').read_text())))
                self.assertEqual(len(saved),181);self.assertTrue(all(row['TC1']=='100.0' for row in saved))
                metadata=json.loads((capture.directory/'capture.json').read_text())
                self.assertEqual(metadata['startup_discard_s'],2)
                self.assertEqual(metadata['adc_timing_mode'],'HIGH_RESOLUTION')
            finally:capture.close()
    def test_ambiguous_channels_missing_types_and_ranges_are_rejected(self):
        for kwargs in ({'physical_channels':DEFAULT_CHANNELS[:-1]},
                       {'physical_channels':('cDAQ1Mod3/ai0:11',)*12},
                       {'physical_channels':('Dev1/port0/line0',)*12},
                       {'physical_channels':('Dev1/ai0',)*12},
                       {'thermocouple_types':('',)*12},
                       {'minimum_c':300,'maximum_c':100}):
            data={'physical_channels':DEFAULT_CHANNELS,'thermocouple_types':('K',)*12,**kwargs}
            with self.assertRaises(ValueError):NISettings.from_payload(data)
    def test_missing_driver_has_installation_guidance(self):
        with patch('boiling_automation.ni_temperature.importlib.import_module',side_effect=ModuleNotFoundError()):
            with self.assertRaisesRegex(ValueError,'NI-DAQmx'):load_driver()
