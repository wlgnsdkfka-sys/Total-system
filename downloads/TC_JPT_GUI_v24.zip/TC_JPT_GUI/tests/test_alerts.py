import http.client
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile

from boiling_automation.core import Config, Reading, ReplayController
from boiling_automation.gui import GuiServer, GuiSession


class ThresholdChangeTests(unittest.TestCase):
    def test_raise_preserves_stage_history_and_ninety_second_minimum(self):
        c=ReplayController(Config(100,allowed_std_c=.1))
        for t in range(80):c.process(Reading(t,(25,)*8))
        before=list(c._history)
        changes=c.update_critical_temperature(120)
        self.assertEqual(changes[0].details,{'old_critical_c':100,'new_critical_c':120})
        self.assertEqual(list(c._history),before)
        self.assertEqual(c._step_started_s,0)
        for t in range(80,91):c.process(Reading(t,(25,)*8))
        self.assertEqual(c.records[0].recorded_at_s,90)
        self.assertEqual(c.power_percent,1)

    def test_lower_checks_all_raw_channels_immediately_and_latches(self):
        c=ReplayController(Config(100))
        c.process(Reading(0,(25,)*7+(50,)))
        events=c.update_critical_temperature(50)
        self.assertEqual([e.kind for e in events],['critical_temperature_changed','shutdown_required'])
        self.assertEqual(events[-1].details['channels'],['TC8'])
        self.assertEqual(events[-1].details['trigger'],'threshold_change')
        self.assertEqual(events[-1].details['independent_actions'],['shutter_close','laser_emission_off'])
        self.assertEqual(c.records,[])
        with self.assertRaises(ValueError):c.update_critical_temperature(200)
        self.assertEqual(c.process(Reading(1,(25,)*8)),[])
        self.assertEqual(c.state,'tripped')

    def test_new_threshold_applies_to_next_sample(self):
        c=ReplayController(Config(100))
        c.process(Reading(0,(25,)*8))
        c.update_critical_temperature(30)
        events=c.process(Reading(1,(30,)*8))
        self.assertEqual(events[-1].details['reason'],'critical_temperature')

    def test_invalid_values_leave_config_and_state_unchanged(self):
        c=ReplayController(Config(100))
        for value in (True,None,'',float('nan'),float('inf')):
            with self.subTest(value=value),self.assertRaises(ValueError):c.update_critical_temperature(value)
            self.assertEqual(c.config.critical_c,100)
            self.assertFalse(c.terminal)

    def test_update_before_first_sample_is_used_when_measurement_arrives(self):
        c=ReplayController(Config(100))
        c.update_critical_temperature(20)
        self.assertEqual(c.process(Reading(0,(25,)*8))[-1].details['reason'],'critical_temperature')


class LiveThresholdSessionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.session=GuiSession(Path(self.temp.name))
        # No worker: deterministic tests exercise the same lock, writer and controller.
        with patch.object(threading.Thread,'start'):
            self.session.start({'critical_c':100,'speed':1})
        self.session.worker=None
        with self.session.lock:
            r=Reading(0,(25,)*7+(50,))
            self.session._events(self.session.controller.process(r))
            self.session.last_reading=r
            self.session.first_t=0

    def tearDown(self):
        self.session.stop();self.temp.cleanup()

    def change(self,value,**extra):
        s=self.session.snapshot()
        return self.session.update_critical_temperature({'critical_c':value,'run_name':s['run_name'],
                                                       'critical_revision':s['critical_revision'],**extra})

    def test_config_change_is_audited_and_initial_config_is_preserved(self):
        s=self.change(120)
        self.assertTrue(s['running']);self.assertEqual(s['config']['critical_c'],120)
        self.assertEqual(s['critical_revision'],1)
        self.session.stop()
        with zipfile.ZipFile(io.BytesIO(self.session.export()[0])) as z:
            self.assertEqual(json.loads(z.read('run.json'))['config']['critical_c'],100)
            event=next(e for e in map(json.loads,z.read('events.jsonl').decode().splitlines()) if e['kind']=='critical_temperature_changed')
            self.assertEqual(event['details'],{'old_critical_c':100,'new_critical_c':120})

    def test_lower_threshold_stops_before_response_and_updates_lamp(self):
        s=self.change(50)
        self.assertFalse(s['running']);self.assertTrue(self.session.writer.closed)
        self.assertTrue(self.session.cancel.is_set())
        self.assertEqual(s['reason'],'critical_temperature')
        self.assertEqual(s['indicators']['critical']['state'],'alarm')
        self.assertEqual(s['records'],[])

    def test_stale_run_and_revision_requests_are_rejected(self):
        for extra in ({'run_name':'old-run'},{'critical_revision':99}):
            with self.assertRaises(ValueError):self.change(120,**extra)
        self.assertEqual(self.session.controller.config.critical_c,100)

    def test_invalid_and_completed_changes_are_rejected(self):
        for value in ('',None,True,float('nan'),float('inf')):
            with self.assertRaises(ValueError):self.change(value)
        self.session.stop()
        with self.assertRaises(ValueError):self.change(120)

    def test_recording_failure_stops_the_experiment(self):
        with patch.object(self.session.writer,'write',side_effect=OSError('disk full')):
            s=self.change(120)
        self.assertFalse(s['running']);self.assertTrue(self.session.controller.terminal)
        self.assertEqual(s['reason'],'input_or_storage_error')
        self.assertTrue(self.session.writer.closed)


class ThresholdHttpTests(unittest.TestCase):
    def test_update_route_requires_token_and_run_match_and_serves_audio_script(self):
        with tempfile.TemporaryDirectory() as folder:
            server=GuiServer(('127.0.0.1',0),Path(folder))
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            def request(method,path,data=None,token=None):
                c=http.client.HTTPConnection('127.0.0.1',server.server_address[1],timeout=5)
                headers={'Content-Type':'application/json'}
                if token:headers['X-App-Token']=token
                try:
                    c.request(method,path,json.dumps(data) if data is not None else None,headers)
                    r=c.getresponse();return r.status,r.read()
                finally:c.close()
            try:
                self.assertEqual(request('GET','/alarms.js')[0],200)
                self.assertEqual(request('POST','/api/critical-temperature',{})[0],403)
                code,body=request('POST','/api/start',{'critical_c':100,'speed':1},server.token)
                self.assertEqual(code,200)
                state=json.loads(body)
                data={'critical_c':120,'run_name':state['run_name'],'critical_revision':0}
                code,body=request('POST','/api/critical-temperature',data,server.token)
                self.assertEqual(code,200);self.assertEqual(json.loads(body)['config']['critical_c'],120)
                self.assertEqual(request('POST','/api/critical-temperature',data,server.token)[0],400)
            finally:
                server.session.stop()
                if server.session.worker:server.session.worker.join(5)
                server.shutdown();server.server_close();thread.join(5)
