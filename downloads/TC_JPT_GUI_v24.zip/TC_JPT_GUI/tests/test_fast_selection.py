import math
import random
import statistics
import unittest
from dataclasses import replace,asdict

from boiling_automation.core import (Reading,Config,Segment,ChannelStats,select_best_segment,
                                     _interval,_statistics)
from boiling_automation.gui import record_summary


def original_stats(points):
    return tuple(ChannelStats(statistics.fmean(v),min(v),max(v),statistics.stdev(v))
                 for v in zip(*(p.temperatures_c for p in points)))


def original_selection(points,config):
    end=points[-1].t_s;start=end-config.observation_s
    obs=_interval(points,start,end)
    starts={start,end-config.segment_s}|{p.t_s for p in obs if p.t_s<=end-config.segment_s}
    return min((Segment(s,s+config.segment_s,original_stats(_interval(obs,s,s+config.segment_s))) for s in starts),
               key=lambda s:(s.worst_std_c,s.worst_range_c,-s.start_s))


class FastSelectionTests(unittest.TestCase):
    def test_live_summary_preserves_fields_without_copying_selected_raw_history(self):
        class UncopyableHistory:
            def __deepcopy__(self,memo):raise AssertionError('raw history was copied during summary rendering')
        from boiling_automation.core import StageRecord
        record=StageRecord(1,90.,Segment(70.,90.,(ChannelStats(100.,99.,101.,.1),)*8),(),
                           'stable',2.,.1)
        expected=asdict(record);expected.pop('selected_samples')
        self.assertEqual(record_summary(replace(record,selected_samples=UncopyableHistory())),expected)

    def test_matches_previous_algorithm_for_irregular_noisy_and_quiet_windows(self):
        config=Config(300,allowed_std_c=.5)
        for seed in range(5):
            rng=random.Random(seed);times=[0.]
            while times[-1]<90:times.append(times[-1]+rng.uniform(.3,1.5))
            points=[Reading(t,tuple(100+j+.1*rng.random()+.01*math.sin(t) for j in range(8))) for t in times]
            before=original_selection(points,config);after=select_best_segment(points,config)
            self.assertEqual(after.start_s,before.start_s)
            self.assertAlmostEqual(after.worst_std_c,before.worst_std_c,places=13)
            self.assertEqual(after.worst_range_c,before.worst_range_c)
        points=[Reading(i/2,(100. if i<80 else 105.,)*8) for i in range(181)]
        self.assertEqual(select_best_segment(points,config).start_s,70.)

    def test_dense_75_hz_regression_uses_same_interval_as_previous_algorithm(self):
        points=[Reading(i/75,tuple(100+j+math.sin(i*.01)*.1 for j in range(8))) for i in range(4501)]
        best=select_best_segment(points,Config(300,allowed_std_c=.5))
        # Saved from the former full rescanning implementation on this signal.
        self.assertEqual(best.start_s,15.133333333333333)
        expected=original_stats(_interval(points,best.start_s,best.end_s))
        for actual,ref in zip(best.channels,expected):
            self.assertAlmostEqual(actual.std_c,ref.std_c,places=13)

    def test_sample_std_matches_statistics_on_large_baseline_and_small_noise(self):
        values=[1e9+math.sin(i)*.0001 for i in range(500)]
        stats=_statistics([Reading(i,(v,)*8) for i,v in enumerate(values)])
        for channel in stats:
            self.assertTrue(math.isclose(channel.std_c,statistics.stdev(values),rel_tol=1e-12,abs_tol=1e-15))
