"""Stream matching raw / furnace-only / final temperature files for every input sample."""
from __future__ import annotations
import csv
import io
import math

from .calibration_common import ALL_CHANNELS

MEASUREMENT_FILES = {
    'raw':'measurements_raw.csv',
    'tab4':'measurements_tab4.csv',
    'tab3':'measurements_tab3.csv',
}
MEASUREMENT_COLUMNS = (
    'sample_id','t_s','elapsed_s','power_percent','power_index_after_sample_percent',
    'state_after_sample','sample_status','stop_reason','interpolated','temperature_basis',*ALL_CHANNELS,
)
DATA_FORMAT = '''# 실험 데이터 파일 안내

같은 실험에서 입력 샘플마다 다음 세 CSV를 동시에 저장합니다. 온도 단위는 °C입니다.

- measurements_raw.csv: 보정 전 원시 TC1~12.
- measurements_tab4.csv: TC1~8은 4번 전기로 보정만 적용. bulk TC9~12는 원시값.
- measurements_tab3.csv: 4번 보정 후 3번 실험 오프셋까지 적용한 최종 온도.
  bulk TC9~12는 원시값 + 비등 기준 100°C의 오프셋.

세 파일의 sample_id, t_s, elapsed_s와 출력 열은 일치합니다.
TC1~TC12 열 이름은 공통이며 파일 이름과 temperature_basis(raw/tab4/tab3)로 구분합니다.
앱에서 CSV를 다시 재생할 때는 measurements_raw.csv를 사용하세요. 보정된 CSV만
다시 입력하여 같은 보정을 중복 적용하는 경우는 차단하며, 원시 열을 함께 넣으면 사용할 수 있습니다.
보정을 사용하지 않은 단계는 그 이전 단계와 같은 값입니다. bulk 누락값은 빈칸입니다.

전체 입력 이력을 저장하며 단계별 20초로 잘라 저장하는 방식과 구분합니다.
온도 중단 판정을 유발한 입력 샘플도 포함합니다. 파싱할 수 없는 CSV 행은
온도 샘플로 만들지 못하므로 events.jsonl의 오류 메시지를 확인하세요.
NaN/inf 또는 역행·누락 시각 때문에 거부한 샘플은 해당 숫자 표현과
sample_status를 보존합니다. 분석 시 ok 샘플을 사용하거나 거부 원인을 확인하세요.

- sample_id: 이 실험 안에서 0부터 증가하는 입력 행 번호. 재시작하면 새 실험 파일입니다.
- t_s: 입력 샘플의 시각(초). CSV는 원래 값, 가상 장치는 가상 시간입니다.
- elapsed_s: 처음의 유한하고 0 이상인 입력 시각을 0으로 한 경과 시간.
- power_percent: 이 샘플을 측정한 단계의 출력 설정(0~100%).
- power_index_after_sample_percent: 이 샘플의 판정 후 index. OFF는 -1%입니다.
  예: 0% 단계의 끝 샘플은 power_percent=0, 상승 후 index=1일 수 있습니다.
- state_after_sample: 이 샘플을 판정한 후의 상태.
- sample_status: ok, invalid_temperature_data 또는 temperature_data_gap.
  임계온도 초과는 정상 숫자이므로 ok이고 stop_reason에 중단 사유를 표시합니다.
- stop_reason: 이 샘플에서 종료를 결정한 경우의 사유. 사용자 중지·설정 변경에 따른
  종료는 별도 입력 샘플을 만들지 않으므로 events.jsonl을 함께 확인하세요.
- interpolated: 입력 샘플의 보간 여부. 전체 로그에 새 경계 보간 샘플을 추가하지 않습니다.

기존 selected_samples.csv는 단계별 선택된 20초 기록입니다. 기존 최종 TC1~12와
TC1_raw_c~TC12_raw_c를 유지하며 TC1_tab4_c~TC12_tab4_c를 추가합니다.
선택 구간 경계의 보간 샘플은 interpolated로 표시합니다.
stages.csv의 평균·표준편차와 기본 2번 커브는 최종 보정온도를 사용합니다.

run.json에는 실험 시작 시 고정한 전기로 보정식·원시 교정점·실험 오프셋·수식 상수와
원시 비등 기준이 있습니다. 이를 사용해 다른 방식으로 재처리할 수 있습니다.
결과 ZIP의 data_snapshot.json에는 포함된 전체 샘플 수와 파일별 바이트 수를 기록합니다.
측정 중 결과 ZIP은 세 CSV를 같은 종료 행까지 고정해 다운로드합니다. 수집은 계속합니다.
개별 CSV는 각 클릭 시점까지 포함하므로 계속 측정하며 따로 누르면 행 수가 달라질 수 있습니다.
같은 종료 시점의 세 파일이 필요하면 결과 ZIP 또는 측정 종료 후 개별 저장을 사용하세요.
저장 오류가 나면 실험을 중단하고 가능한 경우 마지막 미완료 행을 되돌립니다.
ZIP/CSV 다운로드에는 세 파일 모두 저장 완료된 행만 포함합니다.

실제 레이저·셔터 출력 제어는 미연결이며 현재 실험 입력은 가상/CSV입니다.
'''


def temperature_vectors(point,calibration):
    """Derive both views from preserved raw values, never from final minus an offset."""
    raw_tc=point.raw_temperatures_c or point.temperatures_c
    raw_bulk=point.raw_bulk_temperatures_c or point.bulk_temperatures_c or (None,)*4
    final_bulk=point.bulk_temperatures_c or (None,)*4
    if len(raw_tc)!=8 or len(raw_bulk)!=4 or len(point.temperatures_c)!=8 or len(final_bulk)!=4:
        raise ValueError('저장할 온도 데이터의 TC1~12 열 수를 확인하세요.')
    raw=(*raw_tc,*raw_bulk)
    initial=tuple(calibration.initial_value(v,i) if v is not None else None for i,v in enumerate(raw))
    return {'raw':raw,'tab4':initial,'tab3':(*point.temperatures_c,*final_bulk)}


class MeasurementLog:
    def __init__(self,directory,calibration):
        self.directory=directory;self.calibration=calibration
        self.count=0;self.first_t_s=None;self.last_t_s=None
        self.streams={};self.committed_sizes={}
        try:
            for basis,name in MEASUREMENT_FILES.items():
                stream=(directory/name).open('w',encoding='utf-8',newline='')
                self.streams[basis]=stream
                csv.writer(stream).writerow(MEASUREMENT_COLUMNS);stream.flush()
                self.committed_sizes[basis]=stream.tell()
        except Exception:
            for stream in self.streams.values():stream.close()
            raise

    def write(self,point,power_percent,power_index_after,state,events):
        views=temperature_vectors(point,self.calibration)
        first=self.first_t_s
        if first is None and math.isfinite(point.t_s) and point.t_s>=0:first=point.t_s
        elapsed=point.t_s-first if first is not None and math.isfinite(point.t_s) else None
        reason=next((e.details['reason'] for e in events if e.kind=='shutdown_required'),'')
        status=reason if reason in ('invalid_temperature_data','temperature_data_gap') else 'ok'
        common=[self.count,point.t_s,elapsed,power_percent,power_index_after,state,status,reason,int(point.interpolated)]
        # Only three small rows are kept in memory. Mark committed after all flushes succeed.
        rows={}
        for basis,values in views.items():
            row=io.StringIO(newline='');csv.writer(row).writerow([*common,basis,*values]);rows[basis]=row.getvalue()
        try:
            for basis,stream in self.streams.items():stream.write(rows[basis]);stream.flush()
        except Exception:
            for basis,stream in self.streams.items():
                try:stream.seek(self.committed_sizes[basis]);stream.truncate();stream.flush()
                except (OSError,ValueError):pass
            raise
        self.committed_sizes={basis:stream.tell() for basis,stream in self.streams.items()}
        self.first_t_s=first;self.last_t_s=point.t_s;self.count+=1

    def snapshot(self):
        return {'sample_count':self.count,'last_sample_id':self.count-1 if self.count else None,
                'last_t_s':self.last_t_s if self.last_t_s is not None and math.isfinite(self.last_t_s) else None,
                'files':{MEASUREMENT_FILES[basis]:{'basis':basis,'committed_bytes':size} for basis,size in self.committed_sizes.items()}}
