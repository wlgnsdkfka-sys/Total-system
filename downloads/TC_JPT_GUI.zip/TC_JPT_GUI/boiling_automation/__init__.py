"""Offline analysis for the TC/JPT boiling experiment. No hardware I/O."""
