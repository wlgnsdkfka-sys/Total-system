"""Offline analysis for the TC/JPT boiling experiment. No hardware I/O."""

__version__ = "19.0.0"
