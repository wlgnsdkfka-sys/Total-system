"""Offline analysis for the TC/JPT boiling experiment. No hardware I/O."""

__version__ = "21.0.0"
