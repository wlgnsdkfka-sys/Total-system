"""Explicit, editable thermocouple-to-boiling-curve calibration.

The reference constants are transcribed from the supplied diagram. Channel
pairs and the explicit extrapolation/sign conventions still require comparison
with the actual VI; no opaque VI code is executed here.
"""

from copy import deepcopy
import math
import statistics


REFERENCE_SETTINGS = {
    "saturation_c": 100.0,
    "flux_sign": 1,
    "reference_note": "VI 도면 참고값입니다. TC 대응·외삽 방향·열유속 부호는 실제 VI와 대조하세요.",
    "bands": [
        {"label": "R0", "channel_a": 0, "channel_b": 1, "conductivity_w_mk": 391.0,
         "surface_offset_mm": 0.65, "temperature_spacing_mm": 0.8997, "flux_spacing_mm": 1.1141, "weight": 0.03017},
        {"label": "R1.429", "channel_a": 2, "channel_b": 3, "conductivity_w_mk": 391.0,
         "surface_offset_mm": 0.65, "temperature_spacing_mm": 0.93982, "flux_spacing_mm": 1.21435, "weight": 0.18091},
        {"label": "R2.857", "channel_a": 4, "channel_b": 5, "conductivity_w_mk": 391.0,
         "surface_offset_mm": 0.65, "temperature_spacing_mm": 1.20442, "flux_spacing_mm": 1.21522, "weight": 0.36181},
        {"label": "R4.286", "channel_a": 6, "channel_b": 7, "conductivity_w_mk": 391.0,
         "surface_offset_mm": 0.65, "temperature_spacing_mm": 1.67774, "flux_spacing_mm": 1.19084, "weight": 0.42711},
    ],
}


def default_settings():
    return deepcopy(REFERENCE_SETTINGS)


def _validate_settings(settings):
    if not isinstance(settings, dict):
        raise ValueError("계산 설정 형식이 올바르지 않습니다.")
    result = {"saturation_c": float(settings["saturation_c"]), "flux_sign": settings.get("flux_sign", 1),
              "reference_note": REFERENCE_SETTINGS["reference_note"], "bands": []}
    if not math.isfinite(result["saturation_c"]):
        raise ValueError("포화온도는 유한한 숫자여야 합니다.")
    if type(result["flux_sign"]) is not int or result["flux_sign"] not in (-1, 1):
        raise ValueError("열유속 부호를 선택하세요.")
    bands = settings.get("bands")
    if not isinstance(bands, list) or len(bands) != 4:
        raise ValueError("반경별 계산 설정은 4개여야 합니다.")
    for index, band in enumerate(bands):
        if not isinstance(band, dict):
            raise ValueError("반경별 설정 형식을 확인하세요.")
        row = {"label": REFERENCE_SETTINGS["bands"][index]["label"]}
        for key in ("channel_a", "channel_b"):
            value = band.get(key)
            if type(value) is not int or not 0 <= value < 8:
                raise ValueError("TC1~TC8 중에서 채널을 선택하세요.")
            row[key] = value
        if row["channel_a"] == row["channel_b"]:
            raise ValueError("같은 반경의 A/B 채널은 달라야 합니다.")
        for key in ("conductivity_w_mk", "surface_offset_mm", "temperature_spacing_mm", "flux_spacing_mm", "weight"):
            value = float(band[key])
            if not math.isfinite(value) or value < 0:
                raise ValueError("계산 상수는 유한한 0 이상의 숫자여야 합니다.")
            if key in ("conductivity_w_mk", "temperature_spacing_mm", "flux_spacing_mm") and value == 0:
                raise ValueError("열전도율과 TC 간격은 0보다 커야 합니다.")
            row[key] = value
        result["bands"].append(row)
    if not math.isclose(sum(b["weight"] for b in result["bands"]), 1.0, abs_tol=1e-6):
        raise ValueError("반경별 가중치의 합은 1이어야 합니다.")
    return result


def validate_settings(settings):
    try:
        return _validate_settings(settings)
    except (KeyError, TypeError, OverflowError) as error:
        raise ValueError("포화온도·TC 대응·계산 상수를 모두 숫자로 입력하세요.") from error


def calculate_reading(sample, settings):
    """One sample, shared by curve calculation and the heat-flux monitor.

    Callers validate/freeze settings before starting a run.
    """
    weighted_surface = weighted_flux = 0.0
    for band in settings["bands"]:
        a = sample.temperatures_c[band["channel_a"]]
        b = sample.temperatures_c[band["channel_b"]]
        temperature = a - (b - a) * band["surface_offset_mm"] / band["temperature_spacing_mm"]
        q_w_cm2 = settings["flux_sign"] * band["conductivity_w_mk"] * (b - a) / (band["flux_spacing_mm"] * 0.001) / 10000
        weighted_surface += band["weight"] * temperature
        weighted_flux += band["weight"] * q_w_cm2
    if not math.isfinite(weighted_surface) or not math.isfinite(weighted_flux):
        raise ValueError("계산 결과가 유한하지 않습니다. TC 값과 계산 상수를 확인하세요.")
    return weighted_surface, weighted_flux


def calculate_stage(record, settings):
    settings = validate_settings(settings)
    surface, flux = [], []
    for sample in record.selected_samples:
        temperature, heat_flux = calculate_reading(sample, settings)
        surface.append(temperature)
        flux.append(heat_flux)
    return {"power_percent": record.power_percent, "recorded_at_s": record.recorded_at_s,
            "surface_temp_c": statistics.fmean(surface), "surface_std_c": statistics.stdev(surface),
            "heat_flux": statistics.fmean(flux), "heat_flux_std": statistics.stdev(flux)}
