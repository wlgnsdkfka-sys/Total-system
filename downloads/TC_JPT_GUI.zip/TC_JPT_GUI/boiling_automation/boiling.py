"""Boiling-curve data preparation; never infer heat flux from laser percent."""

from __future__ import annotations

import csv
import io
import math


CURVE_FIELDS = ("power_percent", "surface_temp_c", "surface_std_c", "saturation_c",
                "superheat_c", "heat_flux_w_cm2", "heat_flux_std_w_cm2")
UNITS = {"W/cm2": 1.0, "kW/m2": 0.1, "W/m2": 0.0001}


def _number(value, name, *, optional=False):
    if value in (None, ""):
        if optional:
            return None
        raise ValueError(f"{name}을 입력하세요.")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f"{name}은 숫자여야 합니다.") from error
    if not math.isfinite(result):
        raise ValueError(f"{name}은 유한한 숫자여야 합니다.")
    return result


def prepare_curve(payload):
    if not isinstance(payload, dict):
        raise ValueError("보일링 커브 입력 형식이 올바르지 않습니다.")
    saturation = _number(payload.get("saturation_c"), "포화온도")
    unit = payload.get("heat_flux_unit", "W/cm2")
    if unit not in UNITS:
        raise ValueError("열유속 단위를 선택하세요.")
    rows = payload.get("rows")
    if not isinstance(rows, list) or len(rows) > 10000:
        raise ValueError("10,000개 이하의 온도·열유속 데이터를 입력하세요.")
    points, omitted = [], []
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f"{index + 1}행의 데이터 형식이 올바르지 않습니다.")
        if row.get("surface_temp_c") in (None, "") or row.get("heat_flux") in (None, ""):
            omitted.append({"row": index + 1, "reason": "표면온도 또는 열유속 미입력"})
            continue
        temperature = _number(row["surface_temp_c"], "표면온도")
        flux = _number(row["heat_flux"], "열유속") * UNITS[unit]
        sigma = _number(row.get("surface_std_c"), "표면온도 표준편차", optional=True)
        power = _number(row.get("power_percent"), "출력", optional=True)
        flux_sigma = _number(row.get("heat_flux_std"), "열유속 표준편차", optional=True)
        if flux_sigma is not None:
            flux_sigma *= UNITS[unit]
        if (sigma is not None and sigma < 0) or (flux_sigma is not None and flux_sigma < 0):
            raise ValueError("표준편차는 0 이상이어야 합니다.")
        if power is not None and not 0 <= power <= 100:
            raise ValueError("출력은 0~100% 범위여야 합니다.")
        points.append({"power_percent": power, "surface_temp_c": temperature,
                       "surface_std_c": sigma, "saturation_c": saturation,
                       "superheat_c": temperature - saturation, "heat_flux_w_cm2": flux,
                       "heat_flux_std_w_cm2": flux_sigma})
    if not points:
        raise ValueError("표면온도와 열유속이 입력된 데이터가 한 개 이상 필요합니다.")
    return {"saturation_c": saturation, "heat_flux_unit": "W/cm2",
            "points": points, "omitted_rows": omitted}


def import_curve_csv(text, unit="W/cm2"):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("불러올 CSV를 선택하세요.")
    if unit not in UNITS:
        raise ValueError("열유속 단위를 선택하세요.")
    reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
    fields = reader.fieldnames or []
    if len(set(fields)) != len(fields):
        raise ValueError("CSV의 열 이름이 중복되어 있습니다.")
    temperature_column = next((key for key in ("surface_temp_c", "Average Temp", "AverageTemp", "표면온도") if key in fields), None)
    flux_column = next((key for key in ("heat_flux_w_cm2", "heat_flux_kw_m2", "heat_flux_w_m2", "heat_flux", "Total Flux", "TotalFlux", "열유속") if key in fields), None)
    if not temperature_column or not flux_column:
        raise ValueError("CSV에 surface_temp_c와 heat_flux_w_cm2 열이 필요합니다. Average Temp / Total Flux도 사용할 수 있습니다.")
    source_unit = "W/m2" if flux_column == "heat_flux_w_m2" else "kW/m2" if flux_column == "heat_flux_kw_m2" else "W/cm2" if flux_column == "heat_flux_w_cm2" else unit
    rows = []
    for row in reader:
        if len(rows) >= 10000:
            raise ValueError("CSV는 최대 10,000행까지 불러올 수 있습니다.")
        flux = _number(row.get(flux_column), "열유속")
        rows.append({"surface_temp_c": _number(row.get(temperature_column), "표면온도"),
                     "heat_flux": flux * UNITS[source_unit],
                     "surface_std_c": _number(row.get("surface_std_c"), "표면온도 표준편차", optional=True),
                     "heat_flux_std": (_number(row.get("heat_flux_std_w_cm2"), "열유속 표준편차", optional=True)
                                       if "heat_flux_std_w_cm2" in fields else None),
                     "power_percent": _number(row.get("power_percent"), "출력", optional=True)})
    if not rows:
        raise ValueError("CSV에 데이터가 없습니다.")
    # Reuse the same numeric checks without asserting an experimental saturation temperature.
    prepare_curve({"saturation_c": 0, "rows": rows, "heat_flux_unit": "W/cm2"})
    return {"rows": rows, "heat_flux_unit": "W/cm2", "original_heat_flux_unit": source_unit}


def curve_csv(curve):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=CURVE_FIELDS)
    writer.writeheader()
    writer.writerows(curve["points"])
    return stream.getvalue().encode("utf-8-sig")
