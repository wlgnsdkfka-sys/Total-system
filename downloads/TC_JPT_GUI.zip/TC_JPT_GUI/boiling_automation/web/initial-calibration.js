(() => {
 'use strict';
 const el=id=>document.getElementById(id);
 let workspace=null,busy=false,fetching=false,editing=null,loadedKey=null,lastError=null;
 function key(v){const d=v.dataset;return [d.dataset_id,d.revision,v.temperature_profile.profile_id,v.fit?.profile_id??null].join(':');}
 function expected(){return {expected_dataset_id:workspace.dataset.dataset_id,expected_revision:workspace.dataset.revision};}
 const rawInputs=el('initialRawInputs');
 for(let i=0;i<12;i++){
  const label=document.createElement('label');label.textContent='TC'+(i+1)+(i>=8?' · bulk':'')+' (°C)';
  const input=document.createElement('input');input.type='number';input.step='any';input.id='initialRaw'+i;input.setAttribute('aria-label','초기 보정 TC'+(i+1)+' 원시온도');label.append(input);rawInputs.append(label);
  const option=document.createElement('option');option.value=i;option.textContent='TC'+(i+1)+(i>=8?' · bulk':'');el('initialChartChannel').append(option);
  const th=document.createElement('th');th.textContent='TC'+(i+1);el('initialPointHeader').append(th);
 }
 for(const text of ['측정 근거','메모','동작']){const th=document.createElement('th');th.textContent=text;el('initialPointHeader').append(th);}
 function fields(){
  const v=el('initialReference').value;
  if(v===''||!Number.isFinite(Number(v)))throw new Error('기준온도를 입력하세요.');
  return {reference_c:Number(v),note:el('initialNote').value};
 }
 function controls(s=state){
  const ready=!!workspace&&!busy,c=s?.calibration_captures?.furnace;
  for(const id of ['initialAddCapture','initialFit','initialApply','initialDisable','initialExportJson','initialExportCsv','initialImport','initialReload','initialSaveManual','initialClear'])el(id).disabled=!ready;
  el('initialAddCapture').disabled=!ready||!c?.stable;
  const window=c?.config?.window_s??180;
  el('initialAddCapture').textContent='현재 안정 '+(window/60).toLocaleString()+'분 평균을 측정점으로 추가';
  el('initialFit').disabled=!ready||workspace.dataset.points.length<2;
  el('initialApply').disabled=!ready||!workspace.fit||!!s?.running;
  el('initialDisable').disabled=!ready||!workspace.temperature_profile.initial_calibration||!!s?.running;
  el('initialClear').disabled=!ready||!workspace.dataset.points.length;
  const status=el('initialCaptureStatus');
  status.textContent=c?.latest?(c.stable?'추가 가능 · ':'안정 구간 확보 중 · ')+(c.source==='ni'?'NI 실제 입력':c.source==='demo'?'가상 데이터':'CSV 재생')+' · 최근 '+number(c.coverage_s,0)+' / '+window+'초 · 채널 최대 σ '+number(c.stats?Math.max(...c.stats.std_c):null,4)+' °C'+(c.error?' · '+c.error:''):'아래에서 전기로 교정용 원시온도를 측정하세요.';
 }
 function clearEdit(){editing=null;el('initialSaveManual').textContent='수동 측정점 추가';el('initialCancelEdit').classList.add('hidden');el('initialEditStatus').textContent='';for(let i=0;i<12;i++)el('initialRaw'+i).value='';}
 function editPoint(p){
  editing=p.point_id;el('initialReference').value=p.reference_c;el('initialNote').value=p.note;
  for(let i=0;i<12;i++)el('initialRaw'+i).value=p.raw_c[i];
  el('initialSaveManual').textContent='측정점 수정 저장';el('initialCancelEdit').classList.remove('hidden');el('initialEditStatus').textContent='기준 '+number(p.reference_c,3)+' °C 측정점 수정 중';el('initialManual').open=true;el('initialManual').scrollIntoView({behavior:'smooth',block:'center'});
 }
 function show(value){
  workspace=value;loadedKey=key(value);lastError=null;
  const points=value.dataset.points,fit=value.fit,active=value.temperature_profile.initial_calibration;
  el('initialCount').textContent=points.length+'개 측정점';
  el('initialDataStatus').textContent='자동 저장 · 데이터 버전 '+value.dataset.revision+(value.dataset.modified_at?' · '+value.dataset.modified_at.slice(0,19).replace('T',' '):'');
  const rows=el('initialPointRows');rows.replaceChildren();
  if(!points.length){const cell=rows.insertRow().insertCell();cell.colSpan=16;cell.textContent='기준온도를 입력하고 안정 구간 평균을 추가하거나 기존 측정값을 불러오세요.';}
  for(const p of [...points].reverse()){
   const row=rows.insertRow();row.dataset.pointId=p.point_id;
   row.insertCell().textContent=number(p.reference_c,3);for(const v of p.raw_c)row.insertCell().textContent=number(v,4);
   const proof=row.insertCell();proof.textContent=p.evidence?'안정 '+number(p.evidence.window_s,0)+'초':'수동 / 파일';
   proof.title=p.source+' · '+p.created_at+(p.std_c.length?' · 최대 σ '+number(Math.max(...p.std_c),4)+' °C':'')+(p.evidence?' · 원시 구간 SHA-256 '+p.evidence.samples_sha256:'');
   const note=row.insertCell();note.className='initial-note';note.textContent=p.note;
   const action=row.insertCell();for(const [label,fn] of [['수정',()=>editPoint(p)],['삭제',()=>mutate({action:'delete',point_id:p.point_id},'측정점을 삭제했습니다.')]]){const b=document.createElement('button');b.className='button';b.textContent=label;b.setAttribute('aria-label','기준 '+p.reference_c+'도 측정점 '+label);b.addEventListener('click',fn);action.append(b);}
  }
  const fitRows=el('initialFitRows');fitRows.replaceChildren();
  if(!fit){const cell=fitRows.insertRow().insertCell();cell.colSpan=7;cell.textContent='현재 측정점의 보정식을 계산하면 표시됩니다.';}
  else fit.channels.forEach((c,i)=>{const row=fitRows.insertRow();for(const text of ['TC'+(i+1),number(c.gain,8),number(c.intercept_c,6),number(c.rmse_c,6),number(c.max_error_c,6),number(c.r_squared,8),number(c.raw_min_c,3)+' ~ '+number(c.raw_max_c,3)])row.insertCell().textContent=text;});
  el('initialFitStatus').textContent=fit?'현재 '+points.length+'개 측정점으로 보정식 계산 완료 · 최대 채널 RMSE '+number(Math.max(...fit.channels.map(c=>c.rmse_c)),6)+' °C':'측정점을 추가·수정·불러온 후 보정식을 계산하세요.';
  const matches=active&&points.length===active.point_count&&fit?.dataset_fingerprint===active.dataset_fingerprint;
  el('initialActiveStatus').textContent=active?'적용 중: '+active.point_count+'개 측정점 · '+active.created_at.slice(0,19).replace('T',' ')+(matches?' · 현재 계산 데이터와 일치':' · 현재 편집 데이터와 별도 보관된 적용본')+(value.temperature_profile.enabled?' · 3번 탭 비등 오프셋도 사용':''):'적용 중인 초기 보정식 없음 · '+(value.temperature_profile.enabled?'3번 탭 비등 오프셋만 사용':'원시온도 사용');
  controls();draw();
 }
 async function reload(force=false){
  if(fetching||busy)return;fetching=true;
  try{const value=await api('/api/initial-calibration');if(!busy)show(value);}
  catch(error){if(force||lastError!==error.message)toast(error.message);lastError=error.message;}
  finally{fetching=false;controls();}
 }
 async function request(path,payload,message,profileChanged=false){
  if(busy||!workspace)return false;busy=true;controls();
  try{
   const value=await api(path,{...expected(),...payload});show(value);
   if(profileChanged)window.TemperatureCalibrationUI?.baseChanged(value.temperature_profile);
   toast(message);return true;
  }catch(error){toast(error.message);return false;}finally{busy=false;controls();}
 }
 const mutate=(payload,message)=>request('/api/initial-calibration/data',payload,message);
 el('initialAddCapture').addEventListener('click',async()=>{
  try{await mutate({action:'add_capture',...fields(),capture_id:state?.calibration_captures?.furnace?.capture_id},'현재 안정 구간 평균을 측정점으로 추가했습니다.');}catch(error){toast(error.message);}
 });
 el('initialSaveManual').addEventListener('click',async()=>{
  try{const raw=Array.from({length:12},(_,i)=>{const v=el('initialRaw'+i).value;if(v===''||!Number.isFinite(Number(v)))throw new Error('TC1~12의 원시온도를 모두 입력하세요.');return Number(v);});
   if(await mutate({action:editing?'edit':'add_manual',point_id:editing,...fields(),raw_c:raw},editing?'측정점 수정을 저장했습니다.':'수동 측정점을 추가했습니다.'))clearEdit();
  }catch(error){toast(error.message);}
 });
 el('initialCancelEdit').addEventListener('click',clearEdit);
 document.querySelectorAll('[data-initial-temp]').forEach(b=>b.addEventListener('click',()=>{el('initialReference').value=b.dataset.initialTemp;}));
 el('initialReload').addEventListener('click',()=>reload(true));
 el('initialFit').addEventListener('click',()=>request('/api/initial-calibration/fit',{},'12채널 초기 보정식을 계산했습니다. 계수를 확인한 뒤 적용하세요.'));
 el('initialApply').addEventListener('click',()=>request('/api/initial-calibration/activate',{action:'apply',fit_id:workspace.fit.profile_id,expected_profile_id:workspace.temperature_profile.profile_id},'초기 보정식을 저장했습니다. 다음 실험부터 적용됩니다.',true));
 el('initialDisable').addEventListener('click',()=>request('/api/initial-calibration/activate',{action:'disable',expected_profile_id:workspace.temperature_profile.profile_id},'초기 보정식 사용을 해제했습니다. 측정점과 비등 기준은 유지합니다.',true));
 el('initialClear').addEventListener('click',async()=>{if(confirm('현재 측정점 목록을 모두 비울까요? 별도 저장한 파일과 적용 중인 보정식은 유지합니다.')){if(await mutate({action:'clear'},'측정점 목록을 비웠습니다.'))clearEdit();}});
 el('initialImport').addEventListener('click',()=>el('initialFile').click());
 el('initialFile').addEventListener('change',async()=>{
  const file=el('initialFile').files[0];if(!file)return;
  try{if(file.size>16*1024*1024)throw new Error('16MB 이하의 JSON/CSV를 선택하세요.');const format=file.name.toLowerCase().endsWith('.csv')?'csv':'json';
   if(await mutate({action:'import',format,text:await file.text()},'측정점 목록을 불러왔습니다. 보정식을 계산한 뒤 적용하세요.'))clearEdit();
  }catch(error){toast(error.message);}finally{el('initialFile').value='';}
 });
 for(const [id,format] of [['initialExportJson','json'],['initialExportCsv','csv']])el(id).addEventListener('click',async()=>{
  try{const response=await fetch('/api/initial-calibration/export?format='+format);if(!response.ok)throw new Error((await response.json()).error);const url=URL.createObjectURL(await response.blob()),a=document.createElement('a');a.href=url;a.download='TC_initial_calibration.'+format;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(error){toast(error.message);}
 });
 function draw(){
  if(!window.Analysis)return;
  const i=Number(el('initialChartChannel').value),c=workspace?.fit?.channels[i],points=workspace?.dataset.points||[];
  const measured=[...points].sort((a,b)=>a.raw_c[i]-b.raw_c[i]).map(p=>({x:p.raw_c[i],y:p.reference_c}));
  const series=[{name:'기준온도 측정점',color:'#5367d5',points:measured}];
  if(c)series.push({name:'최소제곱 보정식',color:'#dc8470',points:[c.raw_min_c,c.raw_max_c].map(x=>({x,y:c.gain*x+c.intercept_c}))});
  Analysis.scientificPlot(el('initialFitChart'),series,{xLabel:'TC'+(i+1)+' 원시온도 (°C)',yLabel:'기준온도 / 초기 보정온도 (°C)',empty:'기준온도별 측정점을 추가하세요.'});
  Analysis.scientificPlot(el('initialResidualChart'),[{name:'보정온도 − 기준온도',color:'#49a78d',points:c?[...points].sort((a,b)=>a.reference_c-b.reference_c).map(p=>({x:p.reference_c,y:c.gain*p.raw_c[i]+c.intercept_c-p.reference_c})):[]}],{xLabel:'기준온도 (°C)',yLabel:'보정 후 잔차 (°C)',threshold:0,empty:'현재 측정점으로 보정식을 계산하세요.'});
 }
 el('initialChartChannel').addEventListener('change',draw);
 for(const id of ['initialFitChart','initialResidualChart'])new ResizeObserver(draw).observe(el(id).parentElement);
 window.InitialCalibrationUI=Object.freeze({draw,render(s){controls(s);const summary=s.initial_calibration_summary;if(!summary)return;const next=[summary.dataset_id,summary.revision,summary.temperature_profile_id,summary.fit_id??null].join(':');if(next!==loadedKey&&!busy)reload();}});
})();
