(() => {
 'use strict';
 const byId=id=>document.getElementById(id);let latest=null;
 const labels={laser:'레이저',shutter:'셔터',tc:'TC'};
 function stamp(value){return value?value.slice(0,19).replace('T',' '):'기록 없음';}
 function render(s){
  const data=s.communications;if(!data)return;latest={communications:data,manual_controls:s.manual_controls};
  for(const key of ['laser','shutter','tc']){
   const item=data[key];
   for(const prefix of ['commQuick','commDetail']){
    const element=byId(prefix+key);element.dataset.state=item.state;
    byId(prefix+key+'Text').textContent=item.label;
   }
   byId('comm'+key+'Target').textContent=item.target;
   byId('comm'+key+'Checked').textContent=stamp(item.checked_at);
   byId('comm'+key+'Activity').textContent=stamp(item.last_received_at||item.last_transmitted_at);
   byId('comm'+key+'Count').textContent=key==='tc'?'실측 수신 '+item.received_frames+'회':'명령 전송 '+item.transmitted_commands+'회';
   byId('comm'+key+'Detail').textContent=[item.detail,item.input_mode,item.error,item.error_hint].filter(Boolean).join(' · ');
  }
  byId('commSettingsPath').textContent=data.settings_file+(data.settings_file_exists?' · 저장 파일 있음':' · 저장 파일 없음');
  byId('commCheckStatus').textContent=(data.checking?'장치 확인 중 · ':'')+'마지막 확인 '+stamp(data.checked_at)+(data.check_age_s!==null?' · '+number(data.check_age_s,1)+'초 전':'');
  byId('commProbeError').textContent=data.probe_error||data.restore_error||'';
  byId('commPreviousError').textContent=data.shutter.last_error?stamp(data.shutter.last_error_at)+' · '+data.shutter.last_error:'이전 셔터 오류 기록 없음';
  const table=byId('commDeviceRows');table.replaceChildren();
  for(const device of data.inventory.devices){const row=table.insertRow();for(const value of [device.name,device.model,device.simulated?'시뮬레이션':'실제 장치',device.counter_channels?.join(', ')||'없음',device.analog_input_channels?.join(', ')||'없음'])row.insertCell().textContent=value;}
 }
 byId('openCommunications').addEventListener('click',()=>byId('tab-communications').click());
 byId('commRefresh').addEventListener('click',async()=>{
  try{const s=await api('/api/communications/refresh',{});if(!staleSnapshot(s))window.render(s);toast('NI 장치와 저장된 셔터 연결을 다시 확인합니다. 출력은 자동 시작하지 않습니다.');}
  catch(error){toast(error.message);}
 });
 byId('commRecoverShutter').addEventListener('click',async()=>{try{const s=await api('/api/manual/shutter',{action:'reconnect'});if(!staleSnapshot(s))window.render(s);toast('이 프로그램의 셔터 연결을 복구했습니다. 출력은 대기 상태입니다.');}catch(error){toast(error.message);}});
 byId('commExport').addEventListener('click',()=>{
  if(!latest)return;const url=URL.createObjectURL(new Blob([JSON.stringify(latest,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='NI_connection_diagnostics.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 });
 window.CommunicationsUI=Object.freeze({render});if(state)render(state);
})();
