(() => {
 'use strict';
 const byId=id=>document.getElementById(id);
 let data=null,busyManual=false,hydrated=null,dirtyLaser=false,dirtyNI=false,inventorySaved=null;
 const eventNames={shutter_connected:'셔터 채널 연결',shutter_restore_check:'저장 채널 재확인',shutter_command_requested:'셔터 명령 요청',shutter_command_started:'셔터 펄스 유지 시작',shutter_output_released:'셔터 출력 해제',laser_settings_saved:'레이저 수동 설정 저장 · 미전송'};
 const shutterText=s=>!s?.configured?'연결 대기':s.close_requested?'닫힘 요청 처리 중':s.error?'출력 오류 · 위치 미확인':s.busy?'명령 처리 중':s.last_command==='open'?'열림 명령 유지 중 · 위치 미확인':s.last_command==='close'?'닫힘 명령 유지 중 · 위치 미확인':'출력 대기 · 위치 미확인';
 function render(s){
  data=s.manual_controls;if(!data)return;
  const sh=data.shutter,laser=data.laser;
  const settingsKey=JSON.stringify(sh.settings);
  if(!dirtyNI&&(hydrated!==settingsKey||byId('manualCounter').value!==sh.settings.counter_channel)){
   if(sh.settings.counter_channel&&!Array.from(byId('manualCounter').options).some(o=>o.value===sh.settings.counter_channel)){const option=document.createElement('option');option.value=sh.settings.counter_channel;option.textContent=sh.settings.counter_channel+' · 저장된 채널';byId('manualCounter').append(option);byId('manualCounter').value=option.value;}
   byId('manualCounter').value=sh.settings.counter_channel;byId('manualTerminal').value=sh.settings.output_terminal;hydrated=settingsKey;
  }
  if(!dirtyLaser){byId('manualLaserPower').value=laser.settings.power_percent;byId('manualLaserFrequency').value=laser.settings.frequency_khz??'';byId('manualLaserPulse').value=laser.settings.pulse_width_ns??'';}
  const canOpen=sh.connected&&!sh.busy&&!sh.close_requested&&!sh.inhibit_reason&&!busyManual&&!ended;
  const canClose=sh.configured&&!ended;
  byId('manualShutterQuick').textContent=sh.last_command==='close'?'셔터 열기':sh.configured?'셔터 닫기':'셔터 열기 / 닫기';
  byId('manualShutterQuick').disabled=sh.last_command==='close'? !canOpen:!canClose;
  byId('manualShutterQuickState').textContent=shutterText(sh);
  byId('manualShutterOpen').disabled=!canOpen;byId('manualShutterClose').disabled=!canClose;
  byId('manualShutterStatus').textContent=shutterText(sh);
  byId('manualShutterDetail').textContent=(sh.settings.counter_channel||'NI 출력 채널 미선택')+(sh.output_terminal?' → '+sh.output_terminal:'')+(sh.inhibit_reason?' · 열기 차단: '+sh.inhibit_reason:'');
  byId('manualShutterError').textContent=sh.error||'';
  byId('manualShutterConnect').disabled=busyManual||ended||!token||!byId('manualCounter').value||sh.pwm_active;
  byId('manualShutterDisconnect').disabled=busyManual||ended||!sh.configured;
  byId('manualDiscover').disabled=busyManual||ended;
  byId('manualCounter').disabled=busyManual||sh.pwm_active;byId('manualTerminal').disabled=busyManual||sh.pwm_active;
  byId('manualLaserQuick').disabled=true;byId('manualLaserOn').disabled=true;byId('manualLaserOff').disabled=true;
  byId('manualLaserQuickState').textContent='레이저 연결 준비 중';
  byId('manualLaserStatus').textContent='연결 대기 · 발진 상태 미확인';byId('manualLaserIndex').textContent='—';
  byId('manualLaserSave').disabled=busyManual||ended||!token;
  byId('manualEvents').replaceChildren();for(const event of [...data.events].reverse().slice(0,12)){const line=document.createElement('div');line.className='event';line.textContent=event.at.slice(11,19)+' · '+(eventNames[event.action]||event.action)+(event.details.action?' · '+(event.details.action==='open'?'열림':'닫힘'):'');byId('manualEvents').append(line);}
  if(sh.configured){
   const capture=s.calibration_capture;
   const input=capture?.active?(capture.source==='ni'?'NI 교정용 온도 수집':'교정용 '+capture.source):s.source==='ni'?'NI 온도 실측':'온도 입력 '+(s.source==='csv'?'CSV':'가상');
   byId('noticeText').textContent=input+' · 셔터 NI 수동 출력 연결 · '+shutterText(sh)+' · 실제 레이저 ON/OFF는 연결 대기입니다.';
   byId('shutterShutdownPill').textContent='셔터 닫기 요청 · NI';
   byId('globalRunStrip').classList.remove('hidden');byId('globalEmergency').disabled=false;
   if(!s.running&&!capture?.active)byId('globalRunText').textContent='셔터 NI 출력 연결 · '+shutterText(sh)+' · 레이저 발진 상태 미확인';
   byId('globalEmergency').textContent='긴급중단 · 셔터 닫기 요청';byId('emergencyButton').textContent='긴급중단 · 셔터 닫기 요청';
  }else{
   byId('shutterShutdownPill').textContent='셔터 닫기 요청 · 미연결';
   byId('globalEmergency').textContent='긴급중단 · 가상 실험';byId('emergencyButton').textContent='긴급중단 · 가상 실험';
  }
 }
 async function action(path,payload){
  if(ended)return;busyManual=true;if(state)render(state);
  try{const s=await api(path,payload);if(!staleSnapshot(s))window.render(s);return s;}
  catch(error){toast(error.message);}finally{busyManual=false;if(state)render(state);controls();}
 }
 byId('manualDiscover').addEventListener('click',async()=>{
  busyManual=true;if(state)render(state);
  try{
   const inventory=await api('/api/manual/ni-outputs');inventorySaved=inventory;byId('manualDeviceExport').disabled=false;const select=byId('manualCounter'),prior=select.value;
   select.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent='실제 셔터 출력 채널 선택';select.append(empty);
   const table=byId('manualDeviceRows');table.replaceChildren();
   for(const dev of inventory.devices){
    const row=table.insertRow();for(const value of [dev.name,dev.model,dev.simulated?'시뮬레이션':dev.counter_channels.join(', ')||'카운터 출력 없음'])row.insertCell().textContent=value;
    if(!dev.simulated)for(const channel of dev.counter_channels){const option=document.createElement('option');option.value=channel;option.textContent=channel+' · '+dev.model;select.append(option);}
   }
   if([...select.options].some(o=>o.value===prior))select.value=prior;
   byId('manualDeviceStatus').textContent=inventory.devices.length+'개 NI 장치 조회 완료 · 실제 배선에 해당하는 카운터와 출력 단자를 선택하세요.';
   toast('NI 장치 목록을 조회했습니다. 아직 출력은 시작하지 않았습니다.');
  }catch(error){byId('manualDeviceStatus').textContent=error.message;toast(error.message);}
  finally{busyManual=false;if(state)render(state);}
 });
 byId('manualDeviceExport').addEventListener('click',()=>{if(!inventorySaved)return;const url=URL.createObjectURL(new Blob([JSON.stringify(inventorySaved,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='NI_shutter_devices.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
 byId('manualCounter').addEventListener('change',()=>{dirtyNI=true;if(state)render(state);});
 byId('manualTerminal').addEventListener('input',()=>{dirtyNI=true;});
 byId('manualShutterConnect').addEventListener('click',async()=>{const s=await action('/api/manual/shutter',{action:'connect',settings:{counter_channel:byId('manualCounter').value,output_terminal:byId('manualTerminal').value.trim()}});if(s){dirtyNI=false;render(s);toast('셔터 채널 연결 완료 · 출력은 열기/닫기 버튼을 누를 때 시작합니다.');}});
 byId('manualShutterDisconnect').addEventListener('click',()=>action('/api/manual/shutter',{action:'disconnect'}));
 byId('manualShutterQuick').addEventListener('click',()=>action('/api/manual/shutter',{action:data?.shutter.last_command==='close'?'open':'close'}));
 byId('manualShutterOpen').addEventListener('click',()=>action('/api/manual/shutter',{action:'open'}));
 byId('manualShutterClose').addEventListener('click',()=>action('/api/manual/shutter',{action:'close'}));
 for(const id of ['manualLaserPower','manualLaserFrequency','manualLaserPulse'])byId(id).addEventListener('input',()=>{dirtyLaser=true;});
 byId('manualLaserSave').addEventListener('click',async()=>{
  const power=byId('manualLaserPower').value;if(power===''){toast('출력 %를 입력하세요.');return;}
  const s=await action('/api/manual/laser-settings',{power_percent:Number(power),frequency_khz:byId('manualLaserFrequency').value===''?null:Number(byId('manualLaserFrequency').value),pulse_width_ns:byId('manualLaserPulse').value===''?null:Number(byId('manualLaserPulse').value)});
  if(s){dirtyLaser=false;render(s);toast('수동 설정을 이 PC에 저장했습니다. 실제 레이저에는 아직 전송하지 않습니다.');}
 });
 window.ManualControlsUI=Object.freeze({render});if(state)render(state);
})();
