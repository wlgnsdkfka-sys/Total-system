(() => {
 'use strict';
 function createCapture(prefix,purpose){
 const byId=id=>document.getElementById(id.startsWith('capture')?prefix+id.slice(7):id);
 const furnace=purpose==='furnace',channelCount=furnace?8:12,channelLabel=furnace?'TC1~8':'TC1~12',referenceId=furnace?'initialReference':'calibrationReference';
 const traceColors=[...colors,'#486b75','#ad9849','#597c4b','#ad608a'];
 let data=null,busyCapture=false,csvText='',niReady=false,sourceSettings=[],hydratedCapture=null;
 function syncSource(){
  const ni=byId('captureSource').value==='ni';
  byId('captureNISettings').classList.toggle('hidden',!ni);
  byId('captureCsvSection').classList.toggle('hidden',byId('captureSource').value!=='csv');
  if(ni)byId('captureSpeed').value='1';controls();
 }
 function controls(){
  const active=!!data?.active,other=!!state?.calibration_capture?.active&&state.calibration_capture.purpose!==purpose,experiment=!!state?.running,ni=byId('captureSource').value==='ni';
  byId('captureStart').disabled=active||other||experiment||busyCapture||!token||(ni&&!niReady)||(byId('captureSource').value==='csv'&&!csvText);
  byId('captureStop').disabled=!active||busyCapture;
  byId('captureSelect').disabled=busyCapture||!data?.stable||!!data?.error||['emergency_stop','application_closed'].includes(data?.reason);
  byId('captureExport').disabled=busyCapture||!data?.capture_id;
  for(const id of ['captureSource','captureWindow','captureStd','captureRange','captureAllType','captureNIMin','captureNIMax','captureCsvFile'])byId(id).disabled=active||busyCapture;
  byId('captureSpeed').disabled=active||busyCapture||ni;
  for(const row of sourceSettings){row.channel.disabled=active||busyCapture;row.type.disabled=active||busyCapture;}
  byId('captureSelect').textContent='안정 '+(data?.config?.window_s??180)+'초 평균을 기준값으로 선택';
 }
 function draw(){
  if(!window.Analysis?.scientificPlot)return;
  const history=data?.history||[],origin=data?.first_t_s??0;
  const end=history.length?history[history.length-1].t_s:origin+180;
  const start=history.length?history[0].t_s:origin;
  const series=Array.from({length:channelCount},(_,i)=>({name:'TC'+(i+1)+(i>=8?' bulk':''),color:traceColors[i],points:history.map(p=>({x:p.t_s,y:p.values_c[i]}))}));
  Analysis.scientificPlot(byId('captureChart'),series,{xLabel:'보정용 측정 경과 시간',yLabel:'원시온도 (°C)',markers:false,
   threshold:Number(byId(referenceId).value),xDomain:[start,Math.max(start+1,end)],
   formatX:v=>TimeRange.format(v-origin),empty:'보정용 온도 측정을 시작하면 '+channelLabel+'이 표시됩니다.'});
 }
 function hydrate(c){
  if(!c)return;
  byId('captureSource').value=c.source;byId('captureSpeed').value=String(c.speed);
  byId('captureWindow').value=c.config.window_s;byId('captureStd').value=c.config.allowed_std_c;byId('captureRange').value=c.config.allowed_range_c;
  if(c.source==='ni'&&sourceSettings.length){
   const ni=c.source_settings;
   for(let i=0;i<channelCount;i++){sourceSettings[i].channel.value=ni.physical_channels[i];sourceSettings[i].type.value=ni.thermocouple_types[i];}
   byId('captureNIMin').value=ni.minimum_c;byId('captureNIMax').value=ni.maximum_c;
  }
  syncSource();
 }
 function render(s){
  data=s.calibration_captures?.[purpose];
  if(data&&data.capture_id!==hydratedCapture){hydratedCapture=data.capture_id;hydrate(data);}
  const c=data,config=c?.config,stats=c?.stats,warming=!!c?.active&&c.source==='ni'&&!c.latest;
  const status=c?.error?'error':warming?'warming':c?.stable?'stable':c?.active?(c.coverage_s<(config?.window_s??180)?'collecting':'unstable'):'idle';
  byId('captureState').dataset.status=status;
  byId('captureState').textContent=c?.error?'측정 오류':c?.reason==='emergency_stop'?'보정 측정 긴급중단':warming?'NI 연결 · 초기 2초 제외 중':c?.stable?(c.active?'온도 안정 확인':'온도 안정 확인 · 측정 종료'):c?.active?(status==='collecting'?'안정 구간 수집 중':'온도 변동 · 계속 측정'):c?'측정 종료':'측정 대기';
  byId('captureElapsed').textContent=time(c?.elapsed_s??0);
  byId('captureCoverage').textContent=number(c?.coverage_s??0,1)+' / '+(config?.window_s??180)+'초';
  byId('captureMaxStd').textContent=number(stats?Math.max(...stats.std_c):null,4);
  byId('captureMaxRange').textContent=number(stats?Math.max(...stats.ranges_c):null,4);
  byId('captureProgress').style.width=Math.min(100,(c?.coverage_s??0)/(config?.window_s??180)*100)+'%';
  const source=c?.source==='ni'?'NI 실제 온도':c?.source==='csv'?'CSV 재생':furnace?'가상 전기로 온도':'가상 비등 온도';
  const duration=config?.window_s??180;
  byId('captureMessage').textContent=c?.error?c.error:c?.reason==='emergency_stop'?'긴급중단했습니다. 원시데이터는 보존하며 현재 구간을 새 기준으로 선택할 수 없습니다.':c?.stable?channelLabel+' 모두 최근 '+duration+'초 안정 조건 이내입니다. 기준 상태를 확인하고 구간 평균을 선택하세요.':c?.active?(status==='collecting'?source+' · 연속 '+duration+'초를 확보하고 있습니다.':source+' · 일부 채널이 안정 조건을 초과했습니다. 시간 제한 없이 계속 측정합니다.'):c?'측정이 종료됐습니다. 종료 시 안정 구간이면 평균을 선택할 수 있습니다.':'측정 시작 → 3분 이상 안정 확인 → 평균 선택 → 아래에서 보정 저장';
  byId('captureResultFolder').textContent=c?.result_folder?'전체 원시온도 자동 저장: '+c.result_folder:'';
  if(furnace){
   const rows=byId('captureLiveRows');if(rows){rows.replaceChildren();for(let i=0;i<channelCount;i++){const row=rows.insertRow();for(const v of ['TC'+(i+1),number(c?.latest?.values_c[i],3),number(stats?.means_c[i],3),number(stats?.std_c[i],4)])row.insertCell().textContent=v;}}
   if(c?.stable)byId('captureMessage').textContent='전기로의 '+channelLabel+' 모두 최근 '+duration+'초 안정 조건 이내입니다. 기준온도를 확인하고 「현재 안정 3분 평균을 측정점으로 추가」를 누르세요. 여러 온도의 점을 모은 뒤 「보정식 계산」 → 「계산한 초기 보정식 적용」 순서입니다.';
  }
  if(warming)byId('captureMessage').textContent='NI 고해상도 입력 시작 후 첫 2초와 최초 샘플을 제외합니다. 이후 값부터 그래프·원시 기록·연속 '+duration+'초 안정 판정에 포함합니다.';
  if(!furnace&&c?.stable)byId('captureMessage').textContent=channelLabel+' 모두 최근 '+duration+'초 안정 조건 이내입니다. 실제 비등을 확인하고 「안정 '+duration+'초 평균을 기준값으로 선택」 → 기준온도 확인 → 「기준온도에 맞춰 보정 저장」을 누르세요. 다음 실험부터 자동 적용합니다.';
  if(s.calibration_capture?.active&&s.calibration_capture.purpose!==purpose)byId('captureMessage').textContent=(furnace?'3번 실험 오프셋':'4번 전기로 교정')+' 측정 중입니다. 현재 측정을 중지한 뒤 이 탭에서 시작하세요.';
  controls();draw();
 }
 function niPayload(){return {physical_channels:sourceSettings.map(r=>r.channel.value.trim()),thermocouple_types:sourceSettings.map(r=>r.type.value),minimum_c:Number(byId('captureNIMin').value),maximum_c:Number(byId('captureNIMax').value)};}
 byId('captureSource').addEventListener('change',syncSource);
 byId('captureAllType').addEventListener('change',()=>{if(byId('captureAllType').value)for(const r of sourceSettings)r.type.value=byId('captureAllType').value;});
 byId('captureCsvFile').addEventListener('change',async()=>{
  const file=byId('captureCsvFile').files[0];if(!file)return;
  try{if(file.size>16*1024*1024)throw new Error('16MB 이하의 CSV를 선택하세요.');csvText=await file.text();byId('captureCsvInfo').textContent=file.name+' · 재생 준비';}
  catch(error){csvText='';toast(error.message);}finally{controls();}
 });
 byId('captureStart').addEventListener('click',async()=>{
  if(busyCapture)return;
  for(const id of ['captureWindow','captureStd','captureRange'])if(byId(id).value===''||!Number.isFinite(Number(byId(id).value))){toast('안정 시간·표준편차·변동폭에 숫자를 입력하세요.');return;}
  const source=byId('captureSource').value;
  if(source==='ni'&&sourceSettings.some(r=>!r.type.value)){byId('captureNISettings').open=true;toast('실제 배선에 맞게 '+channelLabel+' 열전대 종류를 선택하세요.');return;}
  busyCapture=true;controls();
  try{
   const s=await api('/api/calibration-capture/start',{purpose,demo_reference_c:Number(byId(referenceId).value),source,window_s:Number(byId('captureWindow').value),allowed_std_c:Number(byId('captureStd').value),allowed_range_c:Number(byId('captureRange').value),speed:Number(byId('captureSpeed').value),csv_text:csvText,ni_settings:source==='ni'?niPayload():undefined});
   if(!furnace)TemperatureCalibrationUI.beginCapture();if(!staleSnapshot(s))window.render(s);
   toast(source==='ni'?'NI 고해상도 입력 시작 · 초기 2초를 제외한 뒤 기록합니다.':'보정용 원시온도 수집을 시작했습니다. 실제 레이저는 제어하지 않습니다.');
  }catch(error){toast(error.message);}finally{busyCapture=false;controls();}
 });
 byId('captureStop').addEventListener('click',async()=>{
  if(!data?.active||busyCapture)return;busyCapture=true;controls();
  try{const s=await api('/api/calibration-capture/stop',{capture_id:data.capture_id});if(!staleSnapshot(s))window.render(s);toast('보정용 온도 측정을 중지했습니다. 데이터는 보존됩니다.');}
  catch(error){toast(error.message);}finally{busyCapture=false;controls();}
 });
 byId('captureSelect').addEventListener('click',async()=>{
  if(furnace||busyCapture||!data?.stable)return;busyCapture=true;controls();
  try{const value=await api('/api/calibration-capture/select',{capture_id:data.capture_id});TemperatureCalibrationUI.selectContinuous(value);toast('안정 평균 선택 완료 · 기준온도를 확인한 뒤 「기준온도에 맞춰 보정 저장」을 누르세요.');document.getElementById('calibrationApply').scrollIntoView({block:'center',behavior:'smooth'});}
  catch(error){toast(error.message);}finally{busyCapture=false;controls();}
 });
 byId('captureExport').addEventListener('click',async()=>{
  try{const r=await fetch('/api/calibration-capture/export?purpose='+purpose);if(!r.ok)throw new Error((await r.json()).error);const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=(data?.capture_id||'calibration')+'.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  catch(error){toast(error.message);}
 });
 byId(referenceId).addEventListener('input',draw);
 new ResizeObserver(draw).observe(byId('captureChart').parentElement);
 const ui=Object.freeze({render,draw});
 (async()=>{
  try{
   const defaults=await api('/api/calibration-capture/ni-defaults');
   const types=defaults.thermocouple_types;
   for(const t of types){const o=document.createElement('option');o.value=t;o.textContent=t+'형';byId('captureAllType').append(o);}
   for(let i=0;i<channelCount;i++){
    const row=byId('captureNIRows').insertRow();row.insertCell().textContent='TC'+(i+1)+(i>=8?' bulk':'');
    const channel=document.createElement('input');channel.value=defaults.physical_channels[i];channel.setAttribute('aria-label','TC'+(i+1)+' NI 물리 채널');row.insertCell().append(channel);
    const type=document.createElement('select'),empty=document.createElement('option');empty.value='';empty.textContent='종류 선택';type.append(empty);type.setAttribute('aria-label','TC'+(i+1)+' 열전대 종류');
    for(const t of types){const o=document.createElement('option');o.value=t;o.textContent=t+'형';type.append(o);}row.insertCell().append(type);sourceSettings.push({channel,type});
   }
   niReady=true;if(data?.source==='ni')hydrate(data);syncSource();
  }catch(error){toast(error.message);}
 })();
 return ui;
 }
 const offset=createCapture('capture','offset'),furnace=createCapture('furnaceCapture','furnace');
 window.CalibrationCaptureUI=Object.freeze({draw(){offset.draw();furnace.draw();},render(s){
  offset.render(s);furnace.render(s);
  const c=s.calibration_capture;
  if(c?.source==='ni'&&c.active)document.getElementById('noticeText').textContent=(c.purpose==='furnace'?'전기로 교정':'실험 오프셋')+' · '+(c.hardware_connected?'NI 원시온도 수집 중':'NI 연결 중')+' · 실제 레이저·셔터 제어는 미연결입니다.';
  else if(!ended&&s.source==='ni'&&s.run_name)document.getElementById('noticeText').textContent='NI 고속 온도 실측 · '+(s.running?'수집 중':'수집 종료')+' · '+(s.ni_acquisition?.sample_rate_hz_per_channel?number(s.ni_acquisition.sample_rate_hz_per_channel,3)+'회/초/채널':'연결 중')+' · 출력 index와 차단 요청은 가상이며 실제 레이저·셔터 제어는 미연결입니다.';
  else if(!ended)document.getElementById('noticeText').textContent='실험 출력 제어는 가상 장치·CSV 재생입니다. 3·4번 탭의 NI 온도 입력은 읽기 전용이며 실제 셔터·레이저는 제어하지 않습니다.';
 }});
})();
