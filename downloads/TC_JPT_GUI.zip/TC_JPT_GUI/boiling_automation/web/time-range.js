/* Shared display bounds. Changing these never changes measurement decisions. */
(() => {
  'use strict';
  const el = id => document.getElementById(id);
  const storageKey = 'tc-jpt-display-time-range';
  const initial = {mode:'recent', seconds:120, from:0, to:120};
  function validate(input) {
    if (!input || !['recent','all','manual'].includes(input.mode)) throw new Error('시간 범위 표시 방식을 선택하세요.');
    const next = {...initial, ...input};
    if (next.mode==='recent' && (!Number.isFinite(next.seconds) || next.seconds<1)) throw new Error('최근 표시 시간은 1초 이상의 숫자로 입력하세요.');
    if (next.mode==='manual' && (!Number.isFinite(next.from) || !Number.isFinite(next.to) || next.from<0 || next.to<=next.from)) throw new Error('시작은 0초 이상, 끝은 시작보다 큰 숫자로 입력하세요.');
    return next;
  }
  let settings = {...initial};
  try {const saved=sessionStorage.getItem(storageKey);if(saved)settings=validate(JSON.parse(saved));} catch(_) {}
  function format(value) {
    const ms=Math.round(Math.max(0,value||0)*1000), seconds=Math.floor(ms/1000), fraction=ms%1000;
    return (seconds>=3600?String(Math.floor(seconds/3600)).padStart(2,'0')+':':'')+String(Math.floor(seconds/60)%60).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0')+(fraction?'.'+String(fraction).padStart(3,'0').replace(/0+$/,''):'');
  }
  function bounds(s, record=null) {
    const origin=Number.isFinite(s?.first_t_s)?s.first_t_s:(s?.std_history?.[0]?.t_s??s?.history?.[0]?.t_s??0);
    const latest=Math.max(origin,s?.latest?.t_s??s?.std_history?.at(-1)?.t_s??origin);
    let start,end;
    if (record) {start=record.segment.start_s;end=record.segment.end_s;}
    else if(settings.mode==='manual') {start=origin+settings.from;end=origin+settings.to;}
    else {end=s?.latest?latest:origin+(settings.mode==='recent'?settings.seconds:120);start=settings.mode==='all'?origin:Math.max(origin,end-settings.seconds);}
    if(end<=start)end=start+1;
    return {start,end,origin};
  }
  function slice(points,start,end) {
    // Interpolate display edges only; retain the original measurements unchanged.
    let lo=0,hi=points.length;
    while(lo<hi){const mid=(lo+hi)>>>1;if(points[mid].t_s<start)lo=mid+1;else hi=mid;}
    const begin=lo;lo=0;hi=points.length;
    while(lo<hi){const mid=(lo+hi)>>>1;if(points[mid].t_s<=end)lo=mid+1;else hi=mid;}
    const finish=lo,out=points.slice(begin,finish);
    function edge(index,t) {
      if(index<=0||index>=points.length)return null;
      const left=points[index-1],right=points[index];
      if(t<=left.t_s||t>=right.t_s)return null;
      const fraction=(t-left.t_s)/(right.t_s-left.t_s),p={...left,t_s:t,interpolated:true};
      for(const key of ['temperatures_c','values_c'])p[key]=Array.isArray(left[key])&&Array.isArray(right[key])?left[key].map((a,i)=>Number.isFinite(a)&&Number.isFinite(right[key][i])?a+fraction*(right[key][i]-a):null):null;
      return p;
    }
    const first=edge(begin,start),last=edge(finish,end);
    if(first)out.unshift(first);if(last)out.push(last);
    return out;
  }
  function syncFields() {
    const mode=el('timeRangeMode').value;
    el('recentTimeFields').classList.toggle('hidden',mode!=='recent');
    el('manualTimeFields').classList.toggle('hidden',mode!=='manual');
    el('timeWindowSeconds').required=mode==='recent';
    el('timeFrom').required=el('timeTo').required=mode==='manual';
    el('timeWindowSeconds').disabled=mode!=='recent';
    el('timeFrom').disabled=el('timeTo').disabled=mode!=='manual';
  }
  function apply() {
    try {
      const next=validate({mode:el('timeRangeMode').value,seconds:Number(el('timeWindowSeconds').value),from:Number(el('timeFrom').value),to:Number(el('timeTo').value)});
      settings=next;
      try {sessionStorage.setItem(storageKey,JSON.stringify(settings));} catch(_) {}
      if(typeof selectedRecord!=='undefined'){selectedRecord=null;selectedIndex=null;}
      el('stdMode').value='live';
      if(typeof state!=='undefined'&&state)render(state);
    } catch(error) {if(typeof toast==='function')toast(error.message);}
  }
  el('timeRangeMode').value=settings.mode;
  el('timeWindowSeconds').value=settings.seconds;
  el('timeFrom').value=settings.from;el('timeTo').value=settings.to;
  syncFields();
  el('timeRangeMode').addEventListener('change',syncFields);
  el('timeRangeForm').addEventListener('submit',event=>{event.preventDefault();apply();});
  document.querySelectorAll('[data-time-preset]').forEach(button=>button.addEventListener('click',()=>{
    el('timeRangeMode').value=button.dataset.timePreset==='all'?'all':'recent';
    if(button.dataset.timePreset!=='all')el('timeWindowSeconds').value=button.dataset.timePreset;
    syncFields();apply();
  }));
  window.TimeRange={bounds,slice,format,render(s,record) {
    const b=bounds(s,record);
    const scope=record?'선택한 기록 구간':settings.mode==='all'?'전체 시간':settings.mode==='manual'?'직접 지정':'최근 '+settings.seconds+'초';
    const stage=el('stdMode').value!=='live';
    el('timeRangeStatus').textContent=scope+' · '+format(b.start-b.origin)+' – '+format(b.end-b.origin)+(stage?' · 표준편차는 단계별 출력 축 보기입니다. 적용하면 실시간 보기로 돌아갑니다.':' · 두 실시간 그래프에 공통 적용');
    for(const button of document.querySelectorAll('[data-time-preset]'))button.setAttribute('aria-pressed',String(button.dataset.timePreset==='all'?settings.mode==='all':settings.mode==='recent'&&Number(button.dataset.timePreset)===settings.seconds));
  }};
})();
