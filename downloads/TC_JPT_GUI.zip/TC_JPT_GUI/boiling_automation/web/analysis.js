(() => {
  'use strict';
  let settings = null, rows = [], curve = null, curveSource = '직접 입력', tab = 'experiment';
  const byId = id => document.getElementById(id);

  function switchTab(name) {
    tab = name;
    for (const key of ['experiment', 'boiling', 'constants']) {
      byId(key + 'Tab').classList.toggle('hidden', name !== key);
      byId('tab-' + key).setAttribute('aria-selected', String(name === key));
    }
    requestAnimationFrame(() => { draw(); drawStd(); drawCurve(); });
  }
  document.querySelectorAll('.tabbar button').forEach(button => {
    button.addEventListener('click', () => switchTab(button.dataset.tab));
  });
  byId('globalEmergency').addEventListener('click', () => stop(true));

  function scientificPlot(canvas, series, options) {
    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const dpr = devicePixelRatio || 1, width = rect.width, height = rect.height;
    canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr);
    const ctx = canvas.getContext('2d'); ctx.scale(dpr, dpr);
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, width, height);
    const legendWidth = series.reduce((sum,s) => sum + Math.min(150, s.name.length * 7 + 35), 0);
    const legendRows = Math.max(1, Math.ceil(legendWidth / Math.max(1, width - 94)));
    const margin = {left: 75, right: 20, top: 25 + legendRows * 18, bottom: 49};
    const pw = width - margin.left - margin.right, ph = height - margin.top - margin.bottom;
    const log = !!options.log;
    const eligible = point => Number.isFinite(point.x) && Number.isFinite(point.y) && (!log || point.x > 0 && point.y > 0);
    const points = series.flatMap(s => s.points.filter(eligible));
    const transform = value => log ? Math.log10(value) : value;
    const allX = points.map(p => transform(p.x)), allY = points.map(p => transform(p.y));
    if (options.errorBars) for (const point of points) {
      if (Number.isFinite(point.sx)) for (const value of [point.x - point.sx, point.x + point.sx]) if (!log || value > 0) allX.push(transform(value));
      if (Number.isFinite(point.sy)) for (const value of [point.y - point.sy, point.y + point.sy]) if (!log || value > 0) allY.push(transform(value));
    }
    if (Number.isFinite(options.threshold) && (!log || options.threshold > 0)) allY.push(transform(options.threshold));
    let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
    for(const value of allX){minX=Math.min(minX,value);maxX=Math.max(maxX,value);}
    for(const value of allY){minY=Math.min(minY,value);maxY=Math.max(maxY,value);}
    if(!allX.length){minX=0;maxX=1;}if(!allY.length){minY=0;maxY=1;}
    const dataMinX=minX,dataMaxX=maxX;
    const dx = Math.max(maxX - minX, log ? .2 : 1), dy = Math.max(maxY - minY, log ? .2 : .01);
    minX -= dx * .07; maxX += dx * .07; minY -= dy * .12; maxY += dy * .12;
    if (options.zero && !log) minY = 0;
    if (options.zeroX && !log) minX = 0;
    if(options.xDomain){minX=options.xDomain[0];maxX=options.xDomain[1];canvas.dataset.timeStart=String(minX);canvas.dataset.timeEnd=String(maxX);}
    else {delete canvas.dataset.timeStart;delete canvas.dataset.timeEnd;}
    const visibleData=points.length&&(!options.xDomain||dataMaxX>=minX&&dataMinX<=maxX);
    const x = value => margin.left + (transform(value) - minX) / (maxX - minX) * pw;
    const y = value => margin.top + (maxY - transform(value)) / (maxY - minY) * ph;
    const tick = value => {const n = log ? 10 ** value : value; return Math.abs(n) >= 1000 || Math.abs(n) > 0 && Math.abs(n) < .001 ? n.toExponential(1) : Number(n.toPrecision(4)).toString();};
    ctx.font = '10px "Segoe UI","Malgun Gothic",sans-serif'; ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const xx = margin.left + pw * i / 4, yy = margin.top + ph * i / 4;
      ctx.strokeStyle = '#edf0f5'; ctx.beginPath(); ctx.moveTo(margin.left, yy); ctx.lineTo(width - margin.right, yy); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(xx, margin.top); ctx.lineTo(xx, height - margin.bottom); ctx.stroke();
      ctx.fillStyle = '#8e99aa'; ctx.textAlign = 'right'; ctx.fillText(tick(maxY - (maxY - minY) * i / 4), margin.left - 10, yy + 3);
      ctx.textAlign = 'center'; ctx.fillText(options.formatX?options.formatX(minX+(maxX-minX)*i/4):tick(minX+(maxX-minX)*i/4),xx,height-margin.bottom+18);
    }
    ctx.fillStyle = '#64748b'; ctx.font = '11px "Segoe UI","Malgun Gothic",sans-serif';
    ctx.textAlign = 'center'; ctx.fillText(options.xLabel, margin.left + pw / 2, height - 6);
    ctx.save(); ctx.translate(16, margin.top + ph / 2); ctx.rotate(-Math.PI / 2); ctx.fillText(options.yLabel, 0, 0); ctx.restore();
    let legendX = margin.left, legendY = 16;
    series.forEach(series => {const itemWidth = Math.min(150, series.name.length * 7 + 35); if(legendX > margin.left && legendX + itemWidth > width - margin.right) {legendX = margin.left; legendY += 18;} ctx.fillStyle = series.color; ctx.fillRect(legendX, legendY, 12, 3); ctx.textAlign = 'left'; ctx.fillText(series.name, legendX + 17, legendY + 5); legendX += itemWidth;});
    if (!visibleData) {ctx.textAlign = 'center'; ctx.fillStyle = '#a0aabb'; ctx.fillText(options.empty || '기록이 저장되면 그래프가 표시됩니다.', width / 2, height / 2); return;}
    ctx.save(); ctx.beginPath(); ctx.rect(margin.left, margin.top, pw, ph); ctx.clip();
    if (Number.isFinite(options.threshold) && (!log || options.threshold > 0)) {
      ctx.strokeStyle = '#d69b88'; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(margin.left, y(options.threshold)); ctx.lineTo(width - margin.right, y(options.threshold)); ctx.stroke(); ctx.setLineDash([]);
    }
    for (const item of series) {
      const selected = item.points.filter(eligible);
      ctx.strokeStyle = item.color; ctx.fillStyle = item.color; ctx.lineWidth = 1.5;
      ctx.beginPath(); let pen = false; (options.breakGaps ? item.points : selected).forEach(p => {if (!eligible(p)) {pen = false; return;} if (!pen) ctx.moveTo(x(p.x), y(p.y)); else ctx.lineTo(x(p.x), y(p.y)); pen = true;}); ctx.stroke();
      if(options.markers===false)continue;
      for (const point of selected) {
        if (options.errorBars) {
          ctx.globalAlpha = .5;
          if (Number.isFinite(point.sx) && point.sx > 0 && (!log || point.x - point.sx > 0)) {
            ctx.beginPath(); ctx.moveTo(x(point.x - point.sx), y(point.y)); ctx.lineTo(x(point.x + point.sx), y(point.y));
            for (const xx of [x(point.x - point.sx), x(point.x + point.sx)]) {ctx.moveTo(xx, y(point.y) - 3); ctx.lineTo(xx, y(point.y) + 3);} ctx.stroke();
          }
          if (Number.isFinite(point.sy) && point.sy > 0 && (!log || point.y - point.sy > 0)) {
            ctx.beginPath(); ctx.moveTo(x(point.x), y(point.y - point.sy)); ctx.lineTo(x(point.x), y(point.y + point.sy));
            for (const yy of [y(point.y - point.sy), y(point.y + point.sy)]) {ctx.moveTo(x(point.x) - 3, yy); ctx.lineTo(x(point.x) + 3, yy);} ctx.stroke();
          }
          ctx.globalAlpha = 1;
        }
        ctx.beginPath(); ctx.arc(x(point.x), y(point.y), 3, 0, 2 * Math.PI); ctx.fill();
      }
    }
    ctx.restore();
  }

  function drawStd() {
    const live = byId('stdMode').value === 'live';
    const domain=TimeRange.bounds(state,selectedRecord);
    const history=TimeRange.slice(state?.std_history||[],domain.start,domain.end);
    const traces = [...enabled].map(i => ({name:'TC'+(i+1), color:colors[i], points:live
      ? history.map(p => ({x:p.t_s, y:p.values_c?.[i]}))
      : (state?.records || []).map(r => ({x:r.power_percent, y:r.segment.channels[i].std_c}))}));
    byId('stdTitle').textContent = live ? '실시간 온도 표준편차' : '단계별 온도 표준편차';
    byId('stdCaption').textContent = live ? '직전 30초 σ · 온도 그래프와 같은 시간 범위 · 초기 30초 미만은 확보된 데이터로 계산' : '저장한 20초의 TC별 σ · X축 출력(%) · TC1~8';
    byId('stdChart').setAttribute('aria-label',byId('stdTitle').textContent);
    scientificPlot(byId('stdChart'),traces,{xLabel:live ? '경과 시간' : '가상 레이저 출력 (%)',
      yLabel:'표본 표준편차 σ (°C)',threshold:state?.config?.allowed_std_c,zero:true,breakGaps:live,markers:!live,
      xDomain:live?[domain.start,domain.end]:undefined,
      formatX:live?(value=>TimeRange.format(value-domain.origin)):undefined,
      empty:live ? '온도 샘플이 2개 모이면 표시됩니다.' : '단계 기록이 저장되면 표시됩니다.'});
  }
  byId('stdMode').addEventListener('change',()=>{drawStd();TimeRange.render(state,selectedRecord);});

  function drawCurve() {
    const points = curve?.points || [];
    scientificPlot(byId('boilingChart'), [{name: 'Average Temp / Total Flux', color: '#5367d5', points: points.map(p => ({x: p.superheat_c, y: p.heat_flux_w_cm2, sx: p.surface_std_c, sy: p.heat_flux_std_w_cm2}))}], {
      xLabel: '표면 과열도 ΔT = Average Temp − T_sat (°C)', yLabel: 'Total Flux (W/cm²)', log: byId('curveLog').checked,
      errorBars: byId('curveErrorBars').checked, empty: '온도·열유속 데이터를 입력하고 곡선을 그려주세요.',
    });
    if (curve) {
      const skipped = byId('curveLog').checked ? points.filter(p => p.superheat_c <= 0 || p.heat_flux_w_cm2 <= 0).length : 0;
      byId('curveStatus').textContent = points.length + '개 점 · 포화온도 ' + curve.saturation_c + ' °C · 열유속 W/cm²' + (curve.omitted_rows.length ? ' · 미입력 ' + curve.omitted_rows.length + '행 제외' : '') + (skipped ? ' · 로그 축에서 0 이하인 ' + skipped + '개 점 제외 (CSV에는 유지)' : '');
    }
  }

  function png(canvas, filename, title) {
    const output = document.createElement('canvas'); output.width = canvas.width; output.height = canvas.height + 50;
    const ctx = output.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, output.width, output.height);
    ctx.fillStyle = '#34435b'; ctx.font = '16px "Segoe UI","Malgun Gothic",sans-serif'; ctx.fillText(title, 25, 28); ctx.drawImage(canvas, 0, 50);
    output.toBlob(blob => download(blob, filename));
  }
  function download(blob, filename) {const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = filename; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);}
  function invalidateCurve() {curve = null; for (const key of ['curveCsv', 'curveZip', 'curvePng']) byId(key).disabled = true; byId('curveStatus').textContent = '데이터 또는 상수가 바뀌었습니다. 곡선을 다시 그려주세요.'; drawCurve();}

  function renderRows() {
    const tbody = byId('curveRows'); tbody.replaceChildren();
    if (!rows.length) {const row = tbody.insertRow(); row.className = 'table-empty'; const cell = row.insertCell(); cell.colSpan = 6; cell.textContent = '보일링 커브 데이터가 없습니다.'; return;}
    rows.map((data, index) => ({data, index})).reverse().slice(0, 300).forEach(({data, index}) => {
      const row = tbody.insertRow(); row.dataset.index = index;
      for (const key of ['power_percent', 'surface_temp_c', 'surface_std_c', 'heat_flux', 'heat_flux_std']) {
        const input = document.createElement('input'); input.type = 'number'; input.step = 'any'; input.value = data[key] ?? ''; input.dataset.key = key;
        input.setAttribute('aria-label', (index + 1) + '행 ' + key); input.addEventListener('input', () => {rows[index][key] = input.value === '' ? null : Number(input.value); invalidateCurve();}); row.insertCell().append(input);
      }
      const remove = document.createElement('button'); remove.className = 'delete-row'; remove.textContent = '삭제'; remove.addEventListener('click', () => {rows.splice(index, 1); renderRows(); invalidateCurve();}); row.insertCell().append(remove);
    });
  }

  async function plotCurve() {
    try {
      if (!settings) throw new Error('상수 설정을 먼저 불러와주세요.');
      curve = await api('/api/boiling', {saturation_c: settings.saturation_c, heat_flux_unit: byId('curveUnit').value, rows});
      byId('curveSource').textContent = curveSource;
      for (const key of ['curveCsv', 'curveZip', 'curvePng']) byId(key).disabled = false;
      drawCurve();
    } catch (error) {toast(error.message);}
  }

  function renderSettings(value, apply = true) {
    if (apply) {settings = value; byId('saturationBadge').textContent = '포화온도 ' + value.saturation_c + ' °C';}
    byId('saturationInput').value = value.saturation_c; byId('fluxSign').value = value.flux_sign;
    byId('referenceNote').textContent = value.reference_note;
    const tbody = byId('constantRows'); tbody.replaceChildren();
    value.bands.forEach((band, index) => {
      const row = tbody.insertRow(); row.dataset.band = index; row.insertCell().textContent = band.label;
      for (const key of ['channel_a', 'channel_b', 'conductivity_w_mk', 'surface_offset_mm', 'temperature_spacing_mm', 'flux_spacing_mm', 'weight']) {
        let input;
        if (key.startsWith('channel')) {input = document.createElement('select'); for (let i = 0; i < 8; i++) {const option = document.createElement('option'); option.value = i; option.textContent = 'TC' + (i + 1); input.append(option);}}
        else {input = document.createElement('input'); input.type = 'number'; input.step = 'any'; input.min = '0';}
        input.dataset.key = key; input.value = band[key]; input.setAttribute('aria-label', band.label + ' ' + key); row.insertCell().append(input);
      }
    });
  }
  async function loadSettings() {try {renderSettings(await api('/api/calculation'));} catch (error) {toast(error.message);}}
  byId('saveConstants').addEventListener('click', async () => {
    try {
      const bands = [...byId('constantRows').rows].map(row => {const data = {}; for (const input of row.querySelectorAll('[data-key]')) data[input.dataset.key] = input.value === '' ? null : Number(input.value); return data;});
      const saturation = byId('saturationInput').value;
      if (saturation === '') throw new Error('포화온도를 입력하세요.');
      renderSettings(await api('/api/calculation', {saturation_c: Number(saturation), flux_sign: Number(byId('fluxSign').value), bands}));
      invalidateCurve(); toast('상수와 포화온도를 저장했습니다. 현재 기록에서 계산을 다시 실행하세요.');
    } catch (error) {toast(error.message);}
  });
  byId('resetConstants').addEventListener('click', async () => {
    try {renderSettings(await api('/api/calculation/reference'), false); toast('도면 참고값을 불러왔습니다. 저장을 눌러 적용하세요.');} catch (error) {toast(error.message);}
  });
  byId('curveFromRecords').addEventListener('click', async () => {
    try {
      const result = await api('/api/boiling/from-records', {}); rows = result.rows; curve = result.curve; curveSource = '현재 기록 · 참고식 계산'; byId('curveUnit').value = 'W/cm2'; previousUnit = 'W/cm2'; renderRows();
      byId('curveSource').textContent = curveSource; for (const key of ['curveCsv', 'curveZip', 'curvePng']) byId(key).disabled = false; drawCurve();
      toast('선택된 20초 샘플로 Average Temp / Total Flux를 계산했습니다. 채널·수식 설정을 확인하세요.');
    } catch (error) {toast(error.message);}
  });
  byId('curveAddRow').addEventListener('click', () => {rows.push({power_percent: null, surface_temp_c: null, surface_std_c: null, heat_flux: null, heat_flux_std: null}); renderRows(); invalidateCurve();});
  byId('curveDraw').addEventListener('click', plotCurve);
  byId('curveImportButton').addEventListener('click', () => byId('curveFile').click());
  byId('curveFile').addEventListener('change', async () => {
    const file = byId('curveFile').files[0]; if (!file) return;
    try {if (file.size > 16 * 1024 * 1024) throw new Error('16MB 이하의 CSV를 선택하세요.'); const value = await api('/api/boiling/import', {csv_text: await file.text(), heat_flux_unit: byId('curveUnit').value}); rows = value.rows; byId('curveUnit').value = value.heat_flux_unit; previousUnit = value.heat_flux_unit; curveSource = file.name; renderRows(); await plotCurve();} catch (error) {toast(error.message);}
    byId('curveFile').value = '';
  });
  let previousUnit = 'W/cm2';
  byId('curveUnit').addEventListener('change', () => {const scale = {'W/cm2': 1, 'kW/m2': .1, 'W/m2': .0001}; const target = byId('curveUnit').value; for (const row of rows) for (const key of ['heat_flux', 'heat_flux_std']) if (row[key] !== null && row[key] !== undefined) row[key] *= scale[previousUnit] / scale[target]; previousUnit = target; renderRows(); invalidateCurve();});
  byId('curveExample').addEventListener('click', async () => {
    const saturation = settings?.saturation_c ?? 100;
    rows = [3, 5, 8, 12, 18, 25].map((delta, i) => ({power_percent: i, surface_temp_c: saturation + delta, surface_std_c: .08 + i * .01, heat_flux: .08 * delta ** 1.5, heat_flux_std: .02}));
    byId('curveUnit').value = 'W/cm2'; previousUnit = 'W/cm2'; curveSource = '가상 예시 · 실험 데이터 아님'; renderRows(); await plotCurve();
  });
  byId('curveLog').addEventListener('change', drawCurve); byId('curveErrorBars').addEventListener('change', drawCurve);
  for (const [id, path, filename] of [['curveCsv', '/api/boiling/export', 'boiling_curve.csv'], ['curveZip', '/api/boiling/export-zip', 'boiling_curve.zip']]) {
    byId(id).addEventListener('click', async () => {try {const response = await fetch(path); if (!response.ok) throw new Error((await response.json()).error); download(await response.blob(), filename);} catch (error) {toast(error.message);}});
  }
  byId('saveStdPng').addEventListener('click', () => png(byId('stdChart'), 'temperature_standard_deviation.png', 'TC1–8 · '+(byId('stdMode').value === 'live' ? '실시간 30초' : '출력별')+' 표본 표준편차 (N−1)'));
  byId('curvePng').addEventListener('click', () => png(byId('boilingChart'), 'boiling_curve.png', 'Boiling curve · T_sat = ' + curve.saturation_c + ' °C · ' + curveSource));
  for (const id of ['stdChart', 'boilingChart']) new ResizeObserver(() => {if (id === 'stdChart') drawStd(); else drawCurve();}).observe(byId(id).parentElement);
  document.querySelectorAll('#legend button').forEach(button => button.addEventListener('click', drawStd));
  function renderLamp(id, value) {
    const element=byId(id), text=byId(id+'Text');
    const lamp=value || {state:'off',label:'측정 대기',channels:[]};
    element.dataset.state=lamp.state;
    if(text.textContent!==lamp.label)text.textContent=lamp.label;
    const detail=lamp.label+' · 값 '+number(lamp.value_c,3)+' °C · 설정 '+number(lamp.threshold_c,3)+' °C'+(lamp.channels?.length ? ' · '+lamp.channels.join(', ') : '')+(lamp.window_s ? ' · 데이터 '+number(lamp.coverage_s,1)+' / '+lamp.window_s+'초' : '');
    element.title=detail; element.setAttribute('aria-label',detail);
  }
  window.Analysis = {render(s) {
    renderLamp('criticalLamp',s.indicators?.critical);renderLamp('stdLamp',s.indicators?.std);
    const trip = s.state === 'tripped'; byId('globalRunStrip').classList.toggle('hidden', !s.running && !trip); byId('globalRunStrip').classList.toggle('trip', trip);
    byId('globalRunText').textContent = statusLabel(s) + ' · 가상 출력 ' + s.power_percent + '% · 전체 경과 ' + time(s.elapsed_s);
    byId('globalEmergency').disabled = !s.running; byId('curveFromRecords').disabled = !s.records.length;
    if (tab === 'experiment') drawStd();
  }, switchTab};
  loadSettings();
})();
