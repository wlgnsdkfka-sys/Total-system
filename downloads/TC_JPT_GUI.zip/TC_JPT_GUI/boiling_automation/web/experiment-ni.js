(() => {
 'use strict';
 const byId=id=>document.getElementById(id),rows=[];
 let ready=false,hydrated=null;
 function controls(disabled=false){
  for(const e of byId('experimentNISettings').querySelectorAll('input,select'))e.disabled=disabled;
 }
 function payload(){
  if(!ready)throw new Error('NI 채널 설정을 불러오는 중입니다. 잠시 후 다시 시작하세요.');
  if(rows.some(r=>!r.type.value))throw new Error('실제 열전대 종류를 확인하세요.');
  if(['experimentNIMin','experimentNIMax'].some(id=>byId(id).value===''))throw new Error('NI 최소·최대 온도를 입력하세요.');
  return {physical_channels:rows.map(r=>r.channel.value.trim()),thermocouple_types:rows.map(r=>r.type.value),minimum_c:Number(byId('experimentNIMin').value),maximum_c:Number(byId('experimentNIMax').value)};
 }
 function render(s){
  const ni=s.ni_acquisition;
  if(ready&&s.source==='ni'&&ni&&hydrated!==s.run_name){
   hydrated=s.run_name;
   rows.forEach((r,i)=>{r.channel.value=ni.physical_channels[i];r.type.value=ni.thermocouple_types[i];});
   byId('experimentNIMin').value=ni.minimum_c;byId('experimentNIMax').value=ni.maximum_c;
  }
  byId('experimentNIRate').textContent=s.source==='ni'&&ni?.sample_rate_hz_per_channel?
   '설정된 실제 수집 속도: '+number(ni.sample_rate_hz_per_channel,3)+'회/초/채널 · 고속 모드 · 모든 샘플 저장':
   '고속 모드 · 시작 시 현재 채널 구성의 지원 최대 속도를 조회합니다. 화면 갱신과 별도로 모든 샘플을 수집·저장합니다.';
 }
 byId('experimentNIAllType').addEventListener('change',()=>rows.forEach(r=>{r.type.value=byId('experimentNIAllType').value;}));
 window.ExperimentNIUI=Object.freeze({payload,controls,render});
 (async()=>{
  try{
   const defaults=await api('/api/calibration-capture/ni-defaults');
   for(const t of defaults.thermocouple_types){const o=document.createElement('option');o.value=t;o.textContent=t+'형';byId('experimentNIAllType').append(o);}
   byId('experimentNIAllType').value='K';
   for(let i=0;i<12;i++){
    const row=byId('experimentNIRows').insertRow();row.insertCell().textContent='TC'+(i+1)+(i>=8?' bulk':'');
    const channel=document.createElement('input');channel.value=defaults.physical_channels[i];channel.setAttribute('aria-label','실험 TC'+(i+1)+' NI 물리 채널');row.insertCell().append(channel);
    const type=document.createElement('select');for(const t of defaults.thermocouple_types){const o=document.createElement('option');o.value=t;o.textContent=t+'형';type.append(o);}type.value='K';type.setAttribute('aria-label','실험 TC'+(i+1)+' 열전대 종류');row.insertCell().append(type);rows.push({channel,type});
   }
   ready=true;controls(!!state?.running||!!state?.calibration_capture?.active||busy);if(state)render(state);
  }catch(error){toast(error.message);}
 })();
})();
