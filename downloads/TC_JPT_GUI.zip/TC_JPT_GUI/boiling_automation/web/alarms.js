/* Web Audio is armed by a click, never by a polling response. */
(() => {
 'use strict';
 const el=id=>document.getElementById(id);
 let context=null, enabled=false, preference=true, ticket=0, latest=null;
 let activeKey='', acknowledged='', nextAt=0, fault='', notes=new Set();
 let powerNotes=new Set(),powerNextAt=0,observedRun=undefined,seenPower=new Set();
 try { preference=sessionStorage.getItem('tc-alarm-sound')!=='off'; } catch (_) {}
 function persist(){try{sessionStorage.setItem('tc-alarm-sound',preference?'on':'off');}catch(_){}}
 function stopPower(){for(const n of powerNotes){try{n.stop();n.disconnect();}catch(_){}}powerNotes.clear();powerNextAt=0;}
 function stopNotes(includePower=true){for(const n of notes){try{n.stop();n.disconnect();}catch(_){}}notes.clear();if(includePower)stopPower();}
 function kind(){
  if(!latest)return '';
  if(latest.reason==='application_closed')return '';
  if(latest.indicators?.critical?.state==='alarm')return 'critical';
  if(latest.running&&latest.indicators?.std?.state==='alarm')return 'std';
  return '';
 }
 function status(){
  const k=kind(), ack=activeKey&&activeKey===acknowledged;
  el('soundToggle').textContent=enabled?'소리 끄기':'소리 켜기';
  el('soundToggle').setAttribute('aria-pressed',String(enabled));
  el('muteBeep').disabled=!preference&&!enabled;
  el('soundAck').disabled=!k||!!ack;
  el('soundStatus').textContent=fault||(ack?'현재 알림 음소거':enabled?(k?(k==='critical'?'임계온도 경보 · 3회 비프':'표준편차 경보 · 2회 비프'):'소리 준비됨 · 출력 상승 낮은음 1회 / 임계 3회 / σ 2회'):(preference?'시작 또는 소리 켜기를 눌러 활성화':'소리 꺼짐'));
  el('soundStatus').dataset.audioState=context?.state||'unarmed';
 }
 function play(k){
  if(!enabled||!context||context.state!=='running')return false;
  try{
   const count=k==='power'?1:k==='critical'?3:2, frequency=k==='power'?330:k==='critical'?1100:660;
   const group=k==='power'?powerNotes:notes;
   for(let i=0;i<count;i++){
    const oscillator=context.createOscillator(), gain=context.createGain();
    const at=k==='power'?Math.max(context.currentTime+.02,powerNextAt):context.currentTime+.02+i*.28;
    if(k==='power')powerNextAt=at+.3;
    oscillator.type='sine';oscillator.frequency.setValueAtTime(frequency,at);
    gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.18,at+.012);
    gain.gain.setValueAtTime(.18,at+.12);gain.gain.exponentialRampToValueAtTime(.0001,at+.16);
    oscillator.connect(gain);gain.connect(context.destination);group.add(oscillator);
    oscillator.onended=()=>{group.delete(oscillator);oscillator.disconnect();gain.disconnect();};
    oscillator.start(at);oscillator.stop(at+.18);
   }
   el('soundStatus').dataset.lastPattern=k;
   el('soundStatus').dataset.patternCount=String(Number(el('soundStatus').dataset.patternCount||0)+1);
   return true;
  }catch(_){fault='소리 재생 실패 · 소리 켜기/시험을 다시 누르세요';status();return false;}
 }
 function tick(){
  const k=kind(), key=k?latest.run_name+':'+k:'';
  if(key!==activeKey){activeKey=key;acknowledged='';nextAt=0;stopNotes(k==='critical');}
  if(enabled&&k&&acknowledged!==key&&performance.now()>=nextAt){
   if(play(k))nextAt=performance.now()+(k==='critical'?2000:5000);
  }
  status();
 }
 async function arm(force=false){
  if(force){preference=true;persist();}
  if(!preference){status();return false;}
  const request=++ticket;
  try{
   const Audio=window.AudioContext||window.webkitAudioContext;
   if(!Audio)throw new Error('unsupported');
   if(!context||context.state==='closed'){
    context=new Audio();
    context.onstatechange=()=>{if(context.state!=='running'&&enabled)fault='소리 일시 중지 · 소리 켜기/시험을 누르세요';status();};
   }
   // Creation and resume run before the first await, within the user's click.
   await context.resume();
   if(request!==ticket)return false;
   if(context.state!=='running')throw new Error('suspended');
   enabled=true;fault='';nextAt=0;tick();return true;
  }catch(_){if(request===ticket){enabled=false;fault='소리 활성화 실패 · 소리 켜기/시험을 누르세요';status();}return false;}
 }
 function muteAll(){ticket++;preference=false;persist();enabled=false;fault='';stopNotes();status();}
 function powerCues(s){
  const increases=(s.events||[]).filter(e=>e.kind==='simulated_power_increased');
  if(s.run_name!==observedRun){
   const first=observedRun===undefined;observedRun=s.run_name;seenPower=new Set();stopPower();
   // Opening/reloading a page must not replay earlier output transitions.
   if(first){for(const e of increases)seenPower.add(e.t_s+':'+e.details.power_percent);return;}
  }
  for(const e of increases){
   const id=e.t_s+':'+e.details.power_percent;if(seenPower.has(id))continue;seenPower.add(id);
   // Mark muted events as seen as well; turning audio on never replays them.
   if(s.reason!=='application_closed'&&kind()!=='critical')play('power');
  }
 }
 el('muteBeep').addEventListener('click',muteAll);
 el('soundToggle').addEventListener('click',()=>{
  if(enabled)muteAll();
  else arm(true);
 });
 el('soundTest').addEventListener('click',async()=>{
  if(await arm(true)){play('test');toast('시험음 2회 재생. 들리지 않으면 PC 음량·출력 장치·브라우저 탭 음소거를 확인하세요.');}
 });
 el('soundPowerTest').addEventListener('click',async()=>{
  if(await arm(true)){play('power');toast('출력 상승음 · 낮은음 330 Hz를 한 번 재생했습니다.');}
 });
 el('soundAck').addEventListener('click',()=>{acknowledged=activeKey;stopNotes(false);status();});
 window.AlarmSound=Object.freeze({arm,render:s=>{latest=s;tick();powerCues(s);},stop:()=>{ticket++;enabled=false;stopNotes();status();}});
 setInterval(tick,250);status();
})();
