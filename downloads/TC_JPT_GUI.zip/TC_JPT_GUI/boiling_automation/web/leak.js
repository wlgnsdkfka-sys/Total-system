(() => {
  let saved;
  const ids = {window_s:'leakWindow', settling_s:'leakSettling', hold_s:'leakHold', drop_percent:'leakDrop'};
  function fill(config) {
    config = {...config, threshold_mode:'auto', fluctuation_std_w_cm2:null, min_reference_flux_w_cm2:0};
    saved = config;
    $('leakSensitivity').value = String(config.noise_multiplier ?? 5);
    for (const [key, id] of Object.entries(ids)) $(id).value = config[key] ?? '';
    $('leakEnabled').checked = config.enabled;
    $('leakConfirmed').checked = config.calibration_confirmed;
    $('leakAction').value = config.action;
    $('leakSettingsState').textContent = config.enabled ? '설정 저장됨' : '감지 꺼짐 · 임계온도 감시는 계속 적용됩니다.';
    if (config.enabled) $('leakSettingsState').textContent = '저장됨 · '+(config.action === 'stop' ? '누수 의심 시 실험 중단 판정' : '누수 의심 시 경고와 이력 기록')+' · 다음 실험부터 적용';
  }
  async function load() {try {fill(await api('/api/leak-settings'));} catch(error) {toast(error.message);}}
  for(let i=0;i<4;i++) {
    const row = document.createElement('div'); row.className = 'bulk-row';
    const label = document.createElement('span'); label.textContent = 'TC'+(i+9);
    const value = document.createElement('strong'); value.id = 'bulk'+i; value.textContent = '— °C';
    row.append(label,value); $('bulkValues').append(row);
  }
  $('saveLeak').addEventListener('click', async () => {
    const config = {threshold_mode:'auto', noise_multiplier:Number($('leakSensitivity').value), enabled:$('leakEnabled').checked, calibration_confirmed:$('leakConfirmed').checked, action:$('leakAction').value};
    for (const [key, id] of Object.entries(ids)) config[key] = $(id).value === '' ? null : Number($(id).value);
    try {fill(await api('/api/leak-settings', config)); toast('누수 의심 감지 설정을 저장했습니다.');} catch(error) {toast(error.message);}
  });
  window.LeakUI = {config:() => saved, render(s) {
    $('leakFields').disabled = s.running;
    const bulk = s.latest?.bulk_temperatures_c || [];
    for(let i=0;i<4;i++) $('bulk'+i).textContent = number(bulk[i],2)+' °C';
    const valid = bulk.length === 4 && bulk.every(v => typeof v === 'number' && Number.isFinite(v));
    $('bulkAverage').textContent = (valid ? number(bulk.reduce((a,b)=>a+b,0)/4,2) : '—')+' °C';
    $('bulkSaturation').textContent = number(s.saturation_c,1)+' °C';
    $('bulkState').textContent = !s.latest ? '측정 대기' : s.running ? (valid ? '실시간 · '+(s.source === 'demo' ? '가상 데이터' : 'CSV 재생') : '누락 채널은 — 표시 · 4채널 평균 계산 대기') : '측정 종료 · 마지막 수신값';
    const monitor = s.leak_detection;
    const status = monitor?.status || 'disabled';
    $('leakStatus').textContent = {disabled:'감지 꺼짐',warming_up:'대기 / 구간 수집',watching:'열유속 감시 중',suspected:'누수 의심 이력 있음'}[status];
    $('liveFlux').textContent = number(monitor?.heat_flux_w_cm2);
    $('fluxStd').textContent = number(monitor?.window_std_w_cm2);
    $('fluxDrop').textContent = number(monitor?.drop_percent,1);
    const config = monitor?.config;
    $('leakMessage').textContent = !config?.enabled ? '감지 꺼짐 · 표시 열유속은 4번째 탭의 참고식 계산값입니다. 계산식과 감지 기준을 확인 후 켜세요.' : '대기 '+config.settling_s+'초 → 감시 '+config.window_s+'초 · 이상 지속 '+config.hold_s+'초 · '+(config.action==='stop'?'감지 시 실험 중단 판정':'감지 시 경고 기록')+(monitor.reference?.heat_flux > monitor.minimum_reference_flux_w_cm2 ? ' · 비교 기준 '+monitor.reference.power_percent+'% 단계' : ' · 이전 단계의 신호가 잡음과 구분될 때 감소율 비교')+' · 변동 기준 '+(monitor.threshold_std_w_cm2 == null ? '자동 수집 중' : number(monitor.threshold_std_w_cm2,4)+' W/cm² (자동)')+(s.running?'':' · 현재 측정 종료');
    const alerts = monitor?.alerts || [];
    $('leakWarning').classList.toggle('hidden', !alerts.length);
    $('globalLeakAlert').classList.toggle('hidden', !alerts.length);
    if(alerts.length) {
      const a=alerts.at(-1);
      $('leakWarning').textContent = '누수 의심 / 열전달 이상 · '+time(a.t_s)+' · '+a.power_percent+'% · '+(a.rule==='flux_fluctuation'?'열유속 σ '+number(a.window_std_w_cm2)+' W/cm²':'이전 출력 단계 대비 '+number(a.drop_percent,1)+'% 감소')+' · '+(a.action==='stop'?'가상 차단 요청 기록, 중단 상태 유지':'경고 기록, 실험 계속')+' · 실제 누수 여부를 확인하세요.';
      $('globalLeakAlert').textContent = $('leakWarning').textContent;
    }
  }};
  load();
})();
