(() => {
 'use strict';
 const byId=id=>document.getElementById(id);
 let profile=null, expected=null, loading=false, source='직접 입력', dirty=false;
 const body=byId('calibrationRows');
 for(let i=0;i<12;i++){
  const row=body.insertRow();if(i>=8)row.className='bulk-calibration';
  row.insertCell().textContent='TC'+(i+1)+(i>=8?' · bulk':'');
  const input=document.createElement('input');input.type='number';input.step='any';input.id='calibrationRaw'+i;
  input.placeholder='원시온도';input.setAttribute('aria-label','TC'+(i+1)+' 비등 시 원시온도');
  input.addEventListener('input',()=>{dirty=true;source='직접 입력';preview();});row.insertCell().append(input);
  for(const kind of ['offset','reference','raw','corrected']){const c=row.insertCell();c.id='calibration'+kind+i;c.textContent='—';}
 }
 function referenceValues(){return Array.from({length:12},(_,i)=>{const v=byId('calibrationRaw'+i).value;return v===''?null:Number(v);});}
 function preview(){
  const raw=referenceValues(), target=Number(byId('calibrationReference').value), validTarget=byId('calibrationReference').value!==''&&Number.isFinite(target);
  for(let i=0;i<12;i++){
   const offset=validTarget&&raw[i]!==null&&Number.isFinite(raw[i])?target-raw[i]:null;
   byId('calibrationoffset'+i).textContent=Number.isFinite(offset)?(offset>=0?'+':'')+number(offset,4):'—';
   byId('calibrationreference'+i).textContent=Number.isFinite(offset)?number(raw[i]+offset,3):'—';
  }
  controls();
 }
 function hydrate(p){
  expected=p.profile_id;source=p.source==='none'?'직접 입력':p.source;dirty=false;
  byId('calibrationReference').value=p.reference_c;
  for(let i=0;i<12;i++)byId('calibrationRaw'+i).value=p.reference_raw_c[i]??'';
  byId('calibrationReferenceStatus').textContent=p.reference_raw_c.length?'저장된 기준 · '+p.source:'비등 시 원시온도를 입력하거나 CSV의 마지막 최대 30초 평균을 불러오세요.';
  preview();
 }
 function controls(){
  const running=!!state?.running;
  for(const id of ['calibrationApply','calibrationDisable','calibrationReset'])byId(id).disabled=running||loading;
  for(const id of ['calibrationLatest','calibrationImport','calibrationReload','calibrationExport'])byId(id).disabled=loading;
  byId('calibrationSaveStatus').textContent=running?'측정 중에는 보정 저장·해제·초기화를 할 수 없습니다. 중지한 뒤 저장하면 다음 실험부터 적용됩니다.':'보정 저장·해제·초기화는 다음 실험부터 적용됩니다. 이전 실험 데이터는 당시 보정을 유지합니다.';
 }
 function render(s){
  if(!s.temperature_calibration)return;
  profile=s.temperature_calibration;
  if(expected===null)hydrate(profile);
  const p=profile, run=s.run_temperature_calibration;
  const active=p.enabled?'사용 · 기준 '+number(p.reference_c,2)+' °C':'사용 안 함';
  byId('calibrationSummary').textContent='저장된 보정: '+active+(p.created_at?' · 저장 '+p.created_at.slice(0,19).replace('T',' '):'')+(p.source!=='none'?' · '+p.source:'')+(dirty?' · 입력값 수정 중':'')+(expected!==p.profile_id?' · 저장값이 변경됐습니다. 저장된 보정 불러오기를 누르세요.':'');
  const index=s.power_index_percent??-1;
  byId('calibrationPower').textContent='가상 레이저 '+(index===-1?'OFF':'ON')+' · index '+index+'%';
  const latest=s.latest, corrected=[...(latest?.temperatures_c||[]),...(latest?.bulk_temperatures_c||[])];
  const raw=[...(latest?.raw_temperatures_c?.length?latest.raw_temperatures_c:latest?.temperatures_c||[]),...(latest?.raw_bulk_temperatures_c?.length?latest.raw_bulk_temperatures_c:latest?.bulk_temperatures_c||[])];
  for(let i=0;i<12;i++){
   byId('calibrationraw'+i).textContent=number(raw[i],3);
   byId('calibrationcorrected'+i).textContent=number(corrected[i],3);
  }
  byId('calibrationRunNote').textContent='현재/마지막 실험: '+(run?.enabled?'온도 보정 사용 · 기준 '+run.reference_c+' °C':'온도 보정 사용 안 함')+'. 저장된 보정 변경은 다음 실험부터 적용하며 이전 기록은 다시 계산하지 않습니다.';
  controls();
 }
 async function capture(payload){
  if(loading)return;loading=true;controls();
  try{
   const value=await api('/api/temperature-calibration/preview',payload);
   for(let i=0;i<12;i++)byId('calibrationRaw'+i).value=value.reference_raw_c[i];
   source=value.source+(value.coverage_s?' · '+number(value.coverage_s,2)+'초 평균':'');dirty=true;
   byId('calibrationReferenceStatus').textContent=source+' · '+value.sample_count+'개 샘플'+(value.std_c?' · 채널 최대 σ '+number(Math.max(...value.std_c),4)+' °C':'')+' · 저장 전 미리보기';
   preview();toast('원시 기준값을 불러왔습니다. 비등 상태와 보정값을 확인한 뒤 저장하세요.');
  }catch(error){toast(error.message);}finally{loading=false;controls();}
 }
 byId('calibrationReference').addEventListener('input',()=>{dirty=true;preview();});
 byId('calibrationLatest').addEventListener('click',()=>capture({source:'latest'}));
 byId('calibrationImport').addEventListener('click',()=>byId('calibrationFile').click());
 byId('calibrationFile').addEventListener('change',async()=>{
  const file=byId('calibrationFile').files[0];if(!file)return;
  try{if(file.size>16*1024*1024)throw new Error('16MB 이하의 CSV를 선택하세요.');await capture({source:'csv',csv_text:await file.text()});}
  catch(error){toast(error.message);}finally{byId('calibrationFile').value='';}
 });
 byId('calibrationReload').addEventListener('click',async()=>{
  try{profile=await api('/api/temperature-calibration');hydrate(profile);if(state){state.temperature_calibration=profile;render(state);}toast('저장된 보정값을 불러왔습니다.');}
  catch(error){toast(error.message);}
 });
 async function save(action){
  if(loading||state?.running)return;
  const raw=referenceValues(), targetValue=byId('calibrationReference').value;
  if(action==='apply'&&(raw.some(v=>v===null||!Number.isFinite(v))||targetValue===''||!Number.isFinite(Number(targetValue)))){toast('기준온도와 TC1~12 원시온도를 모두 입력하세요.');return;}
  loading=true;controls();
  try{
   profile=await api('/api/temperature-calibration',{action,expected_profile_id:expected,reference_c:Number(targetValue),reference_raw_c:raw,source});
   hydrate(profile);if(state){state.temperature_calibration=profile;render(state);}
   toast(action==='apply'?'채널별 온도 보정을 저장했습니다. 다음 실험부터 적용됩니다.':action==='disable'?'보정 사용을 해제했습니다. 다음 실험부터 원시온도를 사용합니다.':'보정값을 초기화했습니다.');
  }catch(error){toast(error.message);}finally{loading=false;controls();}
 }
 byId('calibrationApply').addEventListener('click',()=>save('apply'));
 byId('calibrationDisable').addEventListener('click',()=>save('disable'));
 byId('calibrationReset').addEventListener('click',()=>save('reset'));
 byId('calibrationExport').addEventListener('click',async()=>{
  try{
   const saved=await api('/api/temperature-calibration');
   const blob=new Blob([JSON.stringify({channels:Array.from({length:12},(_,i)=>'TC'+(i+1)),formula:'T_corrected = T_raw + offset_c',settings:saved},null,2)],{type:'application/json'});
   const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='TC_temperature_calibration.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(error){toast(error.message);}
 });
 window.TemperatureCalibrationUI=Object.freeze({render});
})();
