"""Background NI checks and truthful, non-blocking communication indicators."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import threading
import time


def now():
    return datetime.now(timezone(timedelta(hours=9))).isoformat()


class ConnectionMonitor:
    def __init__(self,manual,probe,interval_s=2.):
        self.manual=manual;self.probe=probe;self.interval_s=interval_s
        self.lock=threading.Lock();self.stop_event=threading.Event();self.refresh_event=threading.Event()
        self.worker=None
        self.cache={'inventory':{'devices':[]},'checked_at':None,'checked_mono':None,
                    'probe_error':None,'restore_error':None,'checking':False,'sequence':0}

    def start(self):
        if self.worker and self.worker.is_alive():return
        self.worker=threading.Thread(target=self._run,daemon=True);self.worker.start()

    def request_refresh(self):
        self.refresh_event.set()

    def stop(self):
        self.stop_event.set();self.refresh_event.set()
        if self.worker:self.worker.join(1)

    def refresh(self):
        with self.lock:self.cache['checking']=True
        try:
            inventory=self.probe()
            if self.stop_event.is_set():return
            with self.lock:
                self.cache.update(inventory=inventory,checked_at=now(),checked_mono=time.monotonic(),probe_error=None,restore_error=None)
            try:self.manual.reconcile_devices(inventory)
            except Exception as error:
                with self.lock:self.cache['restore_error']=str(error)
        except Exception as error:
            with self.lock:self.cache.update(checked_at=now(),checked_mono=time.monotonic(),probe_error=str(error))
        finally:
            with self.lock:self.cache['checking']=False;self.cache['sequence']+=1

    def _run(self):
        while not self.stop_event.is_set():
            self.refresh()
            self.refresh_event.wait(self.interval_s);self.refresh_event.clear()

    def status(self,tc,*,active_ni=False,input_mode='측정 대기'):
        with self.lock:cache=dict(self.cache)
        manual=self.manual.snapshot();sh=manual['shutter'];devices=cache['inventory'].get('devices',[])
        target=sh['settings']['counter_channel'] or 'myDAQ1/ctr0'
        found=next((d for d in devices if not d.get('simulated',False) and target in d.get('counter_channels',[])),None)
        capability_error=next((d.get('error') for d in devices if d['name']==target.split('/')[0] and d.get('error') and target not in d.get('counter_channels',[])),None)
        age=None if cache['checked_mono'] is None else max(0.,time.monotonic()-cache['checked_mono'])
        shutter={'state':'checking','label':'NI 연결 확인 중','target':target,'model':found['model'] if found else None,
                 'checked_at':cache['checked_at'],'transmitted_commands':sh['tx_count'],
                 'last_transmitted_at':sh['last_command_at'],'detail':sh['connection_note'] or '',
                 'error':sh['error'],'error_code':sh['error_code'],'error_hint':sh['error_hint'],
                 'last_error':sh['last_error'],'last_error_at':sh['last_error_at'],
                 'position_feedback_available':False}
        if sh['error'] or cache['probe_error'] or cache['restore_error']:
            shutter.update(state='error',label='셔터 연결/제어 오류',error=sh['error'] or cache['restore_error'] or cache['probe_error'])
        elif capability_error:
            shutter.update(state='warning',label='NI 채널 확인 필요',error=capability_error)
        elif age is not None and age>6:
            shutter.update(state='warning',label='NI 확인 지연')
        elif cache['checked_at'] is not None and not found:
            shutter.update(state='disconnected',label='셔터 NI 장치 미검출')
        elif sh['configured'] and sh['connected']:
            shutter.update(state='active' if sh['pwm_active'] else 'ready',label='NI 출력 유지 중' if sh['pwm_active'] else '연결 복원 · 명령 대기')
        elif found and sh['auto_reconnect_suppressed']:
            shutter.update(state='ready',label='장치 검출 · 수동 연결 해제')
        elif found:
            shutter.update(state='checking',label='셔터 연결 복원 중')
        endpoints=tc['physical_channels'];physical={c for d in devices if not d.get('simulated',False) for c in d.get('analog_input_channels',[])}
        tc_age=None if tc['last_received_mono'] is None else max(0.,time.monotonic()-tc['last_received_mono'])
        temp={'state':'checking','label':'TC 장치 확인 중','target':', '.join(sorted({c.split('/')[0] for c in endpoints})),
              'physical_channels':list(endpoints),'input_mode':input_mode,'checked_at':cache['checked_at'],
              'received_frames':tc['received_frames'],'last_received_at':tc['last_received_at'],
              'age_s':tc_age,'error':tc['error'],'detail':'가상·CSV는 실제 TC 수신 횟수에 포함하지 않습니다.'}
        if tc['error']:
            temp.update(state='error',label='TC 수신 오류')
        elif active_ni and tc_age is not None:
            temp.update(state='active' if tc_age<=2 else 'error',label='실측 데이터 수신 중' if tc_age<=2 else 'TC 수신 지연')
        elif active_ni:
            temp.update(state='checking',label='NI 연결 · 초기 수신 대기')
        elif cache['probe_error']:
            temp.update(state='error',label='NI 장치 조회 실패',error=cache['probe_error'])
        elif age is not None and age>6:
            temp.update(state='warning',label='TC 장치 확인 지연')
        elif cache['checked_at'] is not None:
            temp.update(state='ready' if set(endpoints)<=physical else 'disconnected',
                        label='TC 장치 검출 · 측정 대기' if set(endpoints)<=physical else 'TC 입력 채널 미검출')
        laser={'state':'unimplemented','label':'레이저 연결 준비','target':'JPT YDFLP-E-300-M7-L-R',
               'checked_at':None,'transmitted_commands':0,'last_transmitted_at':None,
               'detail':'레이저 통신 드라이버는 아직 연결하지 않았습니다. 가상 ON/OFF를 실제 통신으로 표시하지 않습니다.'}
        return {'laser':laser,'shutter':shutter,'tc':temp,'inventory':cache['inventory'],
                'checked_at':cache['checked_at'],'check_age_s':age,'checking':cache['checking'],
                'probe_error':cache['probe_error'],'restore_error':cache['restore_error'],'sequence':cache['sequence'],
                'settings_file':str(self.manual.root/'manual_control_settings.json'),
                'settings_file_exists':self.manual.settings_file_exists}
