"""Local browser GUI for the offline experiment core. Standard library only."""

from __future__ import annotations

import argparse
from collections import deque
import csv
from dataclasses import asdict, replace
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import math
import statistics
from pathlib import Path
import secrets
import threading
from urllib.parse import parse_qs, urlparse
import uuid
import webbrowser
import zipfile

from .core import CHANNELS, BULK_CHANNELS, Config, Event, Reading, ReplayController, _interval, _statistics
from .boiling import curve_csv, import_curve_csv, prepare_curve
from .calculation import calculate_stage, default_settings, validate_settings
from .leak import FluxMonitor, LeakConfig
from .temperature_calibration import ALL_CHANNELS, TemperatureCalibration, finite
from .initial_calibration_session import InitialCalibrationSession
from .calibration_capture import CalibrationCapture, CaptureConfig, values as capture_values
from .ni_temperature import NISettings, DEFAULT_CHANNELS, TC_TYPES, load_driver, readings as ni_readings


ROOT = Path(__file__).resolve().parent.parent
SEOUL = timezone(timedelta(hours=9))
MAX_REQUEST_BYTES = 20 * 1024 * 1024
RESULT_FILES = ("run.json", "events.jsonl", "stages.csv", "selected_samples.csv")


def record_summary(record):
    result = asdict(record)
    result.pop("selected_samples")
    return result


class ResultWriter:
    def __init__(self, directory: Path, config: Config, source: str, monitor=None, temperature_calibration=None):
        self.directory = directory
        directory.mkdir(parents=True, exist_ok=False)
        self.streams = []
        self.closed = False
        try:
            (directory / "run.json").write_text(json.dumps({
                "mode": "offline_gui", "hardware_connected": False,
                "version": "10.0.0", "standard_deviation": "sample_N_minus_1",
                "power_index_percent": {"off": -1, "emission_on_setpoints": "0..100"},
                "temperature_calibration": (temperature_calibration or TemperatureCalibration()).to_dict(),
                "temperature_columns": "TC1..12 corrected; TC1_raw_c..TC12_raw_c uncorrected",
                "config_semantics": "initial_config; changes recorded in events.jsonl",
                "live_std_window_s": 30.0,
                "created_at": datetime.now(SEOUL).isoformat(),
                "source": source, "config": asdict(config),
                "leak_detection": asdict(monitor.config) if monitor else asdict(LeakConfig()),
                "calculation_settings": monitor.settings if monitor else None,
            }, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
            self.events = self._open("events.jsonl")
            self.stages = self._open("stages.csv", newline="")
            self.samples = self._open("selected_samples.csv", newline="")
            self.stage_csv = csv.writer(self.stages)
            self.sample_csv = csv.writer(self.samples)
            self.stage_csv.writerow([
                "power_percent", "recorded_at_s", "start_s", "end_s", "completion_reason",
                "selected_worst_range_c", "current_worst_range_c", *[f"{c}_mean_c" for c in CHANNELS],
                "selected_max_std_c", "current_max_std_c", *[f"{c}_std_c" for c in CHANNELS],
            ])
            self.sample_csv.writerow(["power_percent", "recorded_at_s", "t_s", "interpolated", *CHANNELS, *BULK_CHANNELS,
                                      *[f"{c}_raw_c" for c in ALL_CHANNELS]])
            self.flush()
        except Exception:
            self.close()
            raise

    def _open(self, name, **kwargs):
        stream = (self.directory / name).open("w", encoding="utf-8", **kwargs)
        self.streams.append(stream)
        return stream

    def write(self, events):
        for event in events:
            if event.kind == "observation_recorded":
                record = event.details["record"]
                self.stage_csv.writerow([
                    record.power_percent, record.recorded_at_s,
                    record.segment.start_s, record.segment.end_s, record.completion_reason,
                    record.segment.worst_range_c, record.current_range_c,
                    *[c.mean_c for c in record.segment.channels],
                    record.segment.worst_std_c, record.current_std_c,
                    *[c.std_c for c in record.segment.channels],
                ])
                for point in record.selected_samples:
                    self.sample_csv.writerow([
                        record.power_percent, record.recorded_at_s,
                        point.t_s, point.interpolated, *point.temperatures_c,
                        *(point.bulk_temperatures_c or (None,) * 4),
                        *(point.raw_temperatures_c or point.temperatures_c),
                        *(point.raw_bulk_temperatures_c or point.bulk_temperatures_c or (None,) * 4),
                    ])
                # A stage's sample files are flushed before its subsequent event.
                self.stages.flush()
                self.samples.flush()
            payload = asdict(event)
            if event.kind == "observation_recorded":
                payload["details"]["record"].pop("selected_samples")
            self.events.write(json.dumps(payload, ensure_ascii=False, allow_nan=False) + "\n")
            self.events.flush()

    def flush(self):
        for stream in self.streams:
            if not stream.closed:
                stream.flush()

    def close(self):
        if not self.closed:
            for stream in self.streams:
                stream.close()
            self.closed = True


def csv_readings(text: str):
    reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
    fields = reader.fieldnames
    if not fields or not {"t_s", *CHANNELS}.issubset(fields):
        raise ValueError("CSV에는 t_s, TC1~TC8 열이 필요합니다.")
    if len(set(fields)) != len(fields):
        raise ValueError("CSV 열 이름이 중복되어 있습니다.")
    raw_fields = {f"{c}_raw_c" for c in CHANNELS}
    use_raw = raw_fields.issubset(fields)
    if raw_fields.intersection(fields) and not use_raw:
        raise ValueError("원시온도 열은 TC1_raw_c~TC8_raw_c가 모두 필요합니다.")
    for row in reader:
        try:
            bulk_keys = [f"{c}_raw_c" if use_raw else c for c in BULK_CHANNELS]
            bulk = tuple(None if row.get(c) in (None, "") else float(row[c]) for c in bulk_keys)
            if any(v is not None and not math.isfinite(v) for v in bulk):
                raise ValueError("TC9~12 값은 유한한 숫자 또는 빈칸이어야 합니다.")
            yield Reading(float(row["t_s"]), tuple(float(row[f"{c}_raw_c" if use_raw else c]) for c in CHANNELS), bulk_temperatures_c=bulk)
        except (ValueError, TypeError) as error:
            raise ValueError(f"CSV {reader.line_num}행의 온도 또는 시각을 확인하세요.") from error


class GuiSession(InitialCalibrationSession):
    def __init__(self, results_root: Path):
        self.results_root = results_root
        self.lock = threading.RLock()
        self.controller = None
        self.writer = None
        self.worker = None
        self.cancel = threading.Event()
        self.generation = 0
        self.critical_revision = 0
        self.operation_revision = 0
        self.calibration_capture = None
        self.capture_worker = None
        self.capture_cancel = threading.Event()
        self.running = False
        self.history = deque(maxlen=361)
        self.std_history = []
        self.std_window = deque()
        self.std_coverage_s = 0.0
        self.current_channel_std = None
        self.events = deque(maxlen=100)
        self.last_reading = None
        self.first_t = None
        self.step_start = None
        self.current_range = None
        self.current_std = None
        self.reason = None
        self.error = None
        self.source = "demo"
        self.speed = 1
        self.injected_channel = None
        self.curve = None
        self.calculation_settings = default_settings()
        self.temperature_calibration = TemperatureCalibration()
        self.run_temperature_calibration = TemperatureCalibration()
        calibration_file = results_root / "temperature_calibration.json"
        if calibration_file.is_file():
            self.temperature_calibration = TemperatureCalibration.from_dict(json.loads(calibration_file.read_text(encoding="utf-8")))
        self.load_initial_workspace()
        self.leak_config = LeakConfig()
        settings_file = results_root / "calculation_settings.json"
        if settings_file.is_file():
            self.calculation_settings = validate_settings(json.loads(settings_file.read_text(encoding="utf-8")))
        leak_file = results_root / "leak_settings.json"
        if leak_file.is_file():
            self.leak_config = LeakConfig.from_payload(json.loads(leak_file.read_text(encoding="utf-8")))

    def start(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("실험 설정 형식이 올바르지 않습니다.")
        leak_config = LeakConfig.from_payload(payload["leak_detection"]) if "leak_detection" in payload else self.leak_config
        try:
            critical = float(payload["critical_c"])
            allowed = payload.get("allowed_std_c")
            allowed = None if allowed in (None, "") else float(allowed)
            maximum = payload.get("max_power_percent", 100)
            if isinstance(maximum, bool) or float(maximum) != int(maximum):
                raise ValueError("최대 출력은 정수여야 합니다.")
            maximum = int(maximum)
            speed = float(payload.get("speed", 1))
            if speed not in (1, 10, 60, 300):
                raise ValueError("지원하는 재생 속도를 선택하세요.")
            config = Config(critical, allowed_std_c=allowed, max_power_percent=maximum)
        except (KeyError, TypeError, ValueError, OverflowError) as error:
            raise ValueError(f"온도·허용 변동폭·최대 출력을 확인하세요. {error}") from error
        source = payload.get("source", "demo")
        if source not in ("demo", "csv"):
            raise ValueError("현재 가상 장치와 CSV 재생만 지원합니다.")
        text = payload.get("csv_text", "")
        if source == "csv":
            if not isinstance(text, str) or not text.strip():
                raise ValueError("재생할 CSV 파일을 선택하세요.")
            # Validate the header/first row before creating a run or launching a worker.
            probe = csv_readings(text)
            try:
                next(probe)
            except StopIteration as error:
                raise ValueError("CSV에 온도 데이터가 없습니다.") from error
            finally:
                probe.close()
        with self.lock:
            if self.running:
                raise ValueError("실행 중인 실험을 먼저 중지하세요.")
            if self.calibration_capture and self.calibration_capture.active:
                raise ValueError("3번 탭의 보정용 측정을 먼저 중지하세요.")
            self.cancel.set()
            if self.writer:
                self.writer.close()
            name = datetime.now(SEOUL).strftime("run_%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:8]
            monitor = FluxMonitor(leak_config, self.calculation_settings)
            calibration = self.temperature_calibration
            writer = ResultWriter(self.results_root / name, config, source, monitor, calibration)
            self.writer = writer
            self.run_temperature_calibration = calibration
            self.controller = ReplayController(config, flux_monitor=monitor)
            self.cancel = threading.Event()
            self.generation += 1
            self.operation_revision += 1
            self.critical_revision = 0
            generation, cancel, controller = self.generation, self.cancel, self.controller
            self.history.clear()
            self.std_history.clear()
            self.std_window.clear()
            self.std_coverage_s = 0.0
            self.current_channel_std = None
            self.events.clear()
            self.last_reading = self.first_t = self.step_start = self.current_range = None
            self.current_std = None
            self.reason = self.error = self.injected_channel = None
            self.source, self.speed, self.running = source, speed, True
            self.worker = threading.Thread(
                target=self._run, args=(generation, cancel, controller, writer, source, speed, text), daemon=True
            )
            self.worker.start()
        return self.snapshot()

    def _demo_reading(self, second, previous, controller):
        values = []
        for i in range(8):
            target = 25 + i * 0.2 + controller.power_percent * (1.4 + i * 0.045)
            prior = previous[i] if previous else 25 + i * 0.2
            value = prior + (target - prior) * (1 - math.exp(-1 / (8 + i * 1.2)))
            values.append(value + 0.008 * math.sin(second * 0.37 + i))
        bulk = tuple(25 + controller.power_percent * .08 + i * .05 + .01 * math.sin(second * .1 + i) for i in range(4))
        return Reading(float(second), tuple(values), bulk_temperatures_c=bulk)

    def _run(self, generation, cancel, controller, writer, source, speed, text):
        rows = csv_readings(text) if source == "csv" else None
        second, previous, previous_t = 0, None, None
        try:
            while not cancel.is_set():
                if rows is not None:
                    try:
                        reading = next(rows)
                    except StopIteration:
                        with self.lock:
                            if generation == self.generation:
                                self._events(controller.finish())
                                self.running = False
                        break
                else:
                    reading = self._demo_reading(second, previous, controller)
                    previous = reading.temperatures_c
                    second += 1
                delay = 0 if previous_t is None else max(0, reading.t_s - previous_t) / speed
                # Invalid timestamps are handled by the core, without an infinite wait.
                if not math.isfinite(delay):
                    delay = 0
                if cancel.wait(min(delay, 2.0)):
                    break
                with self.lock:
                    if generation != self.generation or cancel.is_set() or controller.terminal:
                        break
                    if self.injected_channel is not None:
                        temperatures = list(reading.temperatures_c)
                        temperatures[self.injected_channel] = self.run_temperature_calibration.raw_for_corrected(controller.config.critical_c + 1,self.injected_channel)
                        reading = Reading(reading.t_s, tuple(temperatures), bulk_temperatures_c=reading.bulk_temperatures_c)
                        self.injected_channel = None
                    reading = self.run_temperature_calibration.apply(reading)
                    events = controller.process(reading)
                    valid = (math.isfinite(reading.t_s) and reading.t_s >= 0 and len(reading.temperatures_c) == 8
                             and (self.last_reading is None or reading.t_s > self.last_reading.t_s)
                             and all(math.isfinite(v) for v in reading.temperatures_c))
                    if valid:
                        self.first_t = reading.t_s if self.first_t is None else self.first_t
                        self.last_reading = reading
                        self.history.append(reading)
                        self.std_window.append(reading)
                        cutoff = reading.t_s - 30.0
                        while len(self.std_window) > 1 and self.std_window[1].t_s <= cutoff:
                            self.std_window.popleft()
                    self._events(events)
                    self._update_range()
                    if valid:
                        self.std_history.append({"t_s": reading.t_s, "power_percent": controller.power_index_percent,
                                                 "temperatures_c": reading.temperatures_c,
                                                 "values_c": self.current_channel_std,
                                                 "coverage_s": self.std_coverage_s})
                    if controller.terminal:
                        self.running = False
                        break
                previous_t = reading.t_s
        except Exception as error:
            with self.lock:
                if generation == self.generation:
                    self.error = str(error)
                    self.running = False
                    try:
                        self._events(controller.abort("input_or_storage_error"))
                    except OSError:
                        self.reason = "input_or_storage_error"
        finally:
            if rows is not None:
                rows.close()
            with self.lock:
                writer.close()

    def _events(self, events):
        # Write first: a file error prevents processing further planned increases.
        self.writer.write(events)
        for event in events:
            compact = {"kind": event.kind, "t_s": event.t_s, "details": dict(event.details)}
            if event.kind == "observation_recorded":
                compact["details"]["record"] = record_summary(event.details["record"])
            if event.kind in ("simulated_step_started", "simulated_power_increased"):
                self.step_start = event.t_s
            if event.kind == "shutdown_required":
                self.reason = event.details["reason"]
                self.cancel.set()
            self.events.append(compact)

    def _update_range(self):
        self.current_range = None
        self.current_std = None
        self.current_channel_std = None
        self.std_coverage_s = 0.0
        if not self.last_reading or len(self.std_window) < 2:
            return
        end = self.last_reading.t_s
        points = list(self.std_window)
        start = max(points[0].t_s, end - 30.0)
        self.std_coverage_s = end - start
        statistics = _statistics(_interval(points, start, end))
        self.current_range = max(c.range_c for c in statistics)
        self.current_std = max(c.std_c for c in statistics)
        self.current_channel_std = [c.std_c for c in statistics]

    def stop(self, reason="user_stop"):
        with self.lock:
            self._finish_capture(reason)
            if self.controller and self.running:
                self.cancel.set()
                try:
                    self._events(self.controller.abort(reason))
                except OSError as error:
                    self.error = str(error)
                    self.reason = "input_or_storage_error"
                finally:
                    self.running = False
                    self.writer.close()
        return self.snapshot()

    def update_critical_temperature(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("임계온도 변경 요청 형식이 올바르지 않습니다.")
        value = payload.get("critical_c")
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError("임계온도에 유한한 숫자를 입력하세요.")
        with self.lock:
            if not self.running or not self.controller or self.controller.terminal:
                raise ValueError("측정 중에만 적용할 수 있습니다. 새 실험의 값은 시작 전에 입력하세요.")
            if (payload.get("run_name") != self.writer.directory.name
                    or payload.get("critical_revision") != self.critical_revision):
                raise ValueError("실험 또는 임계온도가 변경됐습니다. 현재 적용값을 확인한 후 다시 적용하세요.")
            events = self.controller.update_critical_temperature(value)
            self.critical_revision += 1
            try:
                self._events(events)
            except OSError as error:
                self.error = str(error)
                self.reason = "input_or_storage_error"
                self.cancel.set()
                self.controller.abort("input_or_storage_error")
            if self.controller.terminal or self.error:
                self.running = False
                self.cancel.set()
                self.writer.close()
            return self.snapshot()

    def inject(self, channel=7):
        with self.lock:
            if not self.running or self.source != "demo":
                raise ValueError("가상 장치 실행 중에만 임계온도 시험을 할 수 있습니다.")
            if type(channel) is not int or not 0 <= channel < 8:
                raise ValueError("TC1~TC8 중 하나를 선택하세요.")
            self.injected_channel = channel
        return {"ok": True}

    def indicator_states(self):
        config = self.controller.config if self.controller else None
        invalid = self.error or self.reason in ("invalid_temperature_data", "temperature_data_gap", "temperature_data_stale", "input_or_storage_error")
        values = self.last_reading.temperatures_c if self.last_reading else ()
        hot = [CHANNELS[i] for i, v in enumerate(values) if config and v >= config.critical_c]
        critical = {"state": "off", "label": "측정 대기", "channels": hot,
                    "value_c": max(values) if values else None, "threshold_c": config.critical_c if config else None}
        if self.reason == "critical_temperature" or hot:
            critical.update(state="alarm", label="임계온도 이상")
        elif invalid:
            critical.update(state="unknown", label="데이터 오류")
        elif values:
            critical.update(state="normal", label="임계온도 미만" if self.running else "종료 · 미도달")
        over = [CHANNELS[i] for i, v in enumerate(self.current_channel_std or [])
                if config and config.allowed_std_c is not None and v > config.allowed_std_c]
        std = {"state": "off", "label": "설정 대기", "channels": over,
               "value_c": self.current_std, "threshold_c": config.allowed_std_c if config else None,
               "window_s": 30.0, "coverage_s": self.std_coverage_s}
        if invalid:
            std.update(state="unknown", label="데이터 오류")
        elif config and config.allowed_std_c is None:
            std.update(label="허용값 미설정")
        elif config and self.current_std is None:
            std.update(state="unknown", label="데이터 수집 중" if self.running else "종료 · 데이터 부족")
        elif over:
            std.update(state="alarm", label="설정값 초과" if self.running else "종료 · 초과")
        elif config and self.std_coverage_s < 30:
            std.update(state="unknown", label="30초 수집 중" if self.running else "종료 · 30초 미만")
        elif config:
            std.update(state="normal", label="허용 이내" if self.running else "종료 · 허용 이내")
        return {"critical": critical, "std": std}

    def std_history_since(self, index, run_name, until=None):
        with self.lock:
            if index < 0:
                raise ValueError("표준편차 이력 위치가 올바르지 않습니다.")
            if until is not None and until < 0:
                raise ValueError("표준편차 이력 끝 위치가 올바르지 않습니다.")
            end = len(self.std_history) if until is None else min(until, len(self.std_history))
            name = self.writer.directory.name if self.writer else None
            reset = run_name != name or index > end
            start = 0 if reset else index
            return {"run_name": name, "reset": reset, "start": start,
                    "total": end, "points": self.std_history[start:end]}

    def snapshot(self, include_std_history=True):
        with self.lock:
            controller = self.controller
            end = self.last_reading.t_s if self.last_reading else None
            result = {
                "hardware_connected": False, "source": self.source,
                "temperature_input_hardware_connected": bool(self.calibration_capture and self.calibration_capture.active and self.calibration_capture.hardware_connected),
                "generation": self.generation,
                "critical_revision": self.critical_revision,
                "operation_revision": self.operation_revision,
                "calibration_capture": self.calibration_capture.snapshot() if self.calibration_capture else None,
                "running": self.running, "state": controller.state if controller else "idle",
                "reason": self.reason, "error": self.error, "speed": self.speed,
                "config": asdict(controller.config) if controller else None,
                "power_percent": controller.power_index_percent if controller else -1,
                "power_index_percent": controller.power_index_percent if controller else -1,
                "last_power_percent": controller.power_percent if controller else None,
                "laser_emission_assumed": "on" if controller and controller.power_index_percent >= 0 else "off",
                "temperature_calibration": self.temperature_calibration.to_dict(include_std_history),
                "initial_calibration_summary": self.initial_summary(),
                "run_temperature_calibration": self.run_temperature_calibration.to_dict(include_std_history),
                "elapsed_s": max(0, end - self.first_t) if end is not None else 0,
                "first_t_s": self.first_t,
                "step_elapsed_s": max(0, end - self.step_start) if end is not None and self.step_start is not None else 0,
                "latest": asdict(self.last_reading) if self.last_reading else None,
                "current_range_c": self.current_range,
                "current_std_c": self.current_std,
                "current_channel_std_c": self.current_channel_std,
                "std_window_s": 30.0, "std_coverage_s": self.std_coverage_s,
                "std_history_count": len(self.std_history),
                "indicators": self.indicator_states(),
                "leak_detection": controller.flux_monitor.snapshot() if controller and controller.flux_monitor else None,
                "saturation_c": self.calculation_settings["saturation_c"],
                "history": [asdict(p) for p in self.history],
                "records": [record_summary(r) for r in controller.records] if controller else [],
                "events": list(self.events),
                "result_folder": str(self.writer.directory) if self.writer else None,
                "run_name": self.writer.directory.name if self.writer else None,
            }
            if include_std_history:
                result["std_history"] = list(self.std_history)
            return result

    def record(self, index):
        with self.lock:
            if not self.controller or index < 0 or index >= len(self.controller.records):
                raise ValueError("선택한 기록이 없습니다.")
            return asdict(self.controller.records[index])

    def export(self):
        with self.lock:
            if not self.writer:
                raise ValueError("먼저 가상 실험 또는 CSV 재생을 실행하세요.")
            self.writer.flush()
            result = io.BytesIO()
            with zipfile.ZipFile(result, "w", zipfile.ZIP_DEFLATED) as archive:
                for name in RESULT_FILES:
                    archive.write(self.writer.directory / name, arcname=name)
            return result.getvalue(), self.writer.directory.name + ".zip"

    def prepare_curve(self, payload):
        result = prepare_curve(payload)
        with self.lock:
            self.curve = result
        return result

    def export_curve(self):
        with self.lock:
            if self.curve is None:
                raise ValueError("보일링 커브를 먼저 그려주세요.")
            return curve_csv(self.curve)

    def save_settings(self, payload):
        settings = validate_settings(payload)
        with self.lock:
            if self.running:
                raise ValueError("실행 중에는 계산 상수를 변경할 수 없습니다. 실험을 중지한 뒤 저장하세요.")
            if self.leak_config.enabled and any(settings[k] != self.calculation_settings[k] for k in ("bands", "flux_sign")):
                raise ValueError("누수 감지를 끄고 저장한 뒤 열유속 계산식을 변경하세요. 변경 후 계산식을 다시 확인하고 감지를 켜세요.")
            self.results_root.mkdir(parents=True, exist_ok=True)
            path = self.results_root / "calculation_settings.json"
            temporary = path.with_name("calculation_settings_" + uuid.uuid4().hex + ".tmp")
            try:
                temporary.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")
                temporary.replace(path)
            finally:
                temporary.unlink(missing_ok=True)
            self.calculation_settings = settings
        return settings

    def save_leak_settings(self, payload):
        config = LeakConfig.from_payload(payload)
        with self.lock:
            if self.running:
                raise ValueError("실행 중에는 누수 감지 설정을 변경할 수 없습니다. 먼저 실험을 중지하세요.")
            self.results_root.mkdir(parents=True, exist_ok=True)
            path = self.results_root / "leak_settings.json"
            temporary = path.with_name("leak_settings_" + uuid.uuid4().hex + ".tmp")
            try:
                temporary.write_text(json.dumps(asdict(config), ensure_ascii=False, indent=2), encoding="utf-8")
                temporary.replace(path)
            finally:
                temporary.unlink(missing_ok=True)
            self.leak_config = config
        return asdict(config)

    def _finish_capture(self, reason="user_stop", error=None):
        capture = self.calibration_capture
        if capture and capture.active:
            self.capture_cancel.set()
            try:
                capture.finish(reason, error)
            except OSError as failure:
                capture.active = False
                capture.stable = False
                capture.error = str(failure)
                capture.reason = "capture_error"
                capture.close()
            self.operation_revision += 1

    def start_calibration_capture(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("보정 측정 설정 형식이 올바르지 않습니다.")
        source = payload.get("source", "demo")
        if source not in ("demo", "csv", "ni"):
            raise ValueError("가상 비등 온도·CSV·NI 온도 입력 중 선택하세요.")
        config = CaptureConfig(payload.get("window_s", 180), payload.get("allowed_std_c", .1),
                               payload.get("allowed_range_c", .5))
        speed = finite(payload.get("speed", 1))
        if speed not in (1, 10, 60, 300) or source == "ni" and speed != 1:
            raise ValueError("지원하는 재생 속도를 선택하세요. 실제 NI 측정은 1배속입니다.")
        text = payload.get("csv_text", "")
        ni = None
        if source == "csv":
            if not isinstance(text, str) or not text.strip():
                raise ValueError("보정 측정용 CSV를 선택하세요.")
        elif source == "ni":
            ni = NISettings.from_payload(payload.get("ni_settings"))
            load_driver()
        previous_worker = self.capture_worker
        if previous_worker and previous_worker.is_alive() and self.calibration_capture and not self.calibration_capture.active:
            previous_worker.join(3)
            if previous_worker.is_alive():
                raise ValueError("이전 온도 입력을 종료 중입니다. 잠시 후 다시 시작하세요.")
        with self.lock:
            if self.running:
                raise ValueError("출력 제어 실험을 먼저 중지하세요. 보정 측정은 OFF index -1%에서 수행합니다.")
            if self.calibration_capture and self.calibration_capture.active:
                raise ValueError("이미 보정용 온도를 측정 중입니다.")
            name = datetime.now(SEOUL).strftime("calibration_%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:8]
            capture = CalibrationCapture(self.results_root / name, config, source, speed,
                                         asdict(ni) if ni else None)
            self.capture_cancel.set()
            self.capture_cancel = threading.Event()
            self.calibration_capture = capture
            self.operation_revision += 1
            self.capture_worker = threading.Thread(target=self._run_calibration_capture,
                args=(capture, self.capture_cancel, text, ni), daemon=True)
            self.capture_worker.start()
            return self.snapshot()

    def _run_calibration_capture(self, capture, cancel, text, ni):
        def demo():
            t = 0
            while True:
                # Explicit simulation: a warming bath with fixed channel offsets.
                raw = [100 - 4 * math.exp(-t / 18) + (i-5.5)*.08 + .008*math.sin(t*.27+i)
                       for i in range(12)]
                yield Reading(float(t), tuple(raw[:8]), bulk_temperatures_c=tuple(raw[8:]))
                t += 1
        rows = ni_readings(ni, cancel) if capture.source == "ni" else csv_readings(text) if capture.source == "csv" else demo()
        previous = None
        try:
            for point in rows:
                # Reject corrupt/missing input before waiting on its timestamp.
                capture_values(point)
                t = finite(point.t_s)
                if t < 0 or previous is not None and (t <= previous or t-previous > 2):
                    raise ValueError("보정 입력의 시각이 역행하거나 2초 이상 누락됐습니다.")
                if capture.source != "ni" and cancel.wait(0 if previous is None else (t-previous)/capture.speed):
                    break
                with self.lock:
                    if self.calibration_capture is not capture or cancel.is_set() or not capture.active:
                        break
                    capture.observe(point)
                    if capture.source == "ni":
                        capture.hardware_connected = True
                previous = t
            with self.lock:
                if self.calibration_capture is capture and capture.active:
                    self._finish_capture("input_ended" if capture.source == "csv" else "user_stop")
        except Exception as error:
            with self.lock:
                if self.calibration_capture is capture and capture.active:
                    self._finish_capture("capture_error", error)
        finally:
            rows.close()
            with self.lock:
                capture.close()

    def stop_calibration_capture(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("보정 중지 요청을 확인하세요.")
        with self.lock:
            capture = self.calibration_capture
            if not capture or payload.get("capture_id") != capture.capture_id:
                raise ValueError("보정 측정이 변경됐습니다. 현재 측정 상태를 확인하세요.")
            self._finish_capture()
            return self.snapshot()

    def select_calibration_reference(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("보정 구간 선택 요청을 확인하세요.")
        with self.lock:
            capture = self.calibration_capture
            if not capture or payload.get("capture_id") != capture.capture_id:
                raise ValueError("보정 측정이 변경됐습니다. 현재 구간을 확인하세요.")
            return capture.select_reference()

    def export_calibration_capture(self):
        with self.lock:
            if not self.calibration_capture:
                raise ValueError("먼저 3번 탭에서 보정용 온도 측정을 시작하세요.")
            capture = self.calibration_capture
            entries = capture.prepare_export()
            filename = capture.capture_id + '.zip'
        return capture.export_snapshot(entries), filename

    def preview_temperature_calibration(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("보정 기준 요청 형식이 올바르지 않습니다.")
        if payload.get("source") == "latest":
            with self.lock:
                point = self.last_reading
                if point is None:
                    raise ValueError("최근 측정값이 없습니다. 비등 기준 CSV 또는 원시온도를 입력하세요.")
                values = (*(point.raw_temperatures_c or point.temperatures_c),
                          *(point.raw_bulk_temperatures_c or point.bulk_temperatures_c))
                if len(values) != 12 or any(v is None for v in values):
                    raise ValueError("TC1~12의 원시온도가 모두 필요합니다. 누락된 벌크 온도를 확인하세요.")
                values = [finite(v) for v in values]
                return {"reference_raw_c": values, "source": "최근 원시 샘플",
                        "coverage_s": 0, "sample_count": 1, "t_s": point.t_s}
        text = payload.get("csv_text")
        if payload.get("source") != "csv" or not isinstance(text, str) or not text.strip():
            raise ValueError("비등 기준 CSV를 선택하세요.")
        points = deque()
        previous = None
        for point in csv_readings(text):
            values = (*point.temperatures_c, *point.bulk_temperatures_c)
            if len(values) != 12 or any(v is None for v in values):
                raise ValueError("보정 CSV에는 t_s와 TC1~TC12 원시온도가 모두 필요합니다.")
            for value in values:
                finite(value)
            t = finite(point.t_s)
            if t < 0 or previous is not None and (t <= previous or t - previous > 2):
                raise ValueError("보정 CSV의 시각은 증가해야 하며 샘플 간격은 2초 이하여야 합니다.")
            previous = t
            points.append(point)
            while len(points) > 1 and points[1].t_s <= t - 30:
                points.popleft()
        if len(points) < 2:
            raise ValueError("보정 CSV에 적어도 두 시각의 샘플이 필요합니다.")
        end = points[-1].t_s
        start = max(points[0].t_s, end - 30)
        selected = _interval(list(points), start, end)
        vectors = [(*p.temperatures_c, *p.bulk_temperatures_c) for p in selected]
        try:
            means = [finite(statistics.mean(v[i] for v in vectors)) for i in range(12)]
            deviations = [finite(statistics.stdev(v[i] for v in vectors)) for i in range(12)]
        except ArithmeticError as error:
            raise ValueError("보정 CSV의 온도 범위를 확인하세요.") from error
        return {"reference_raw_c": means, "std_c": deviations,
                "source": "CSV 최근 구간 평균", "coverage_s": end-start,
                "sample_count": len(selected), "start_s": start, "end_s": end}

    def save_temperature_calibration(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("보정 설정 형식이 올바르지 않습니다.")
        with self.lock:
            if self.running:
                raise ValueError("측정을 중지한 뒤 보정을 저장하세요. 다음 실험부터 적용됩니다.")
            old = self.temperature_calibration
            if payload.get("expected_profile_id") != old.profile_id:
                raise ValueError("보정 설정이 변경됐습니다. 저장된 보정 불러오기 후 다시 적용하세요.")
            action = payload.get("action")
            stamp = datetime.now(SEOUL).isoformat()
            identifier = uuid.uuid4().hex
            if action == "apply":
                raw = payload.get("reference_raw_c")
                if not isinstance(raw, list) or len(raw) != 12:
                    raise ValueError("TC1~12의 비등 시 원시온도를 모두 입력하세요.")
                reference = finite(payload.get("reference_c", 100))
                raw = tuple(finite(v) for v in raw)
                evidence = old.reference_evidence if raw == old.reference_raw_c else None
                selected_id = payload.get("selected_reference_id")
                if selected_id:
                    capture = self.calibration_capture
                    if not capture or payload.get("capture_id") != capture.capture_id or selected_id not in capture.references:
                        raise ValueError("선택한 안정 구간을 찾을 수 없습니다. 3번 탭에서 다시 선택하세요.")
                    evidence = capture.references[selected_id]
                capture_active = self.calibration_capture and self.calibration_capture.active
                if (payload.get("require_stable_reference") and evidence is None) or (capture_active and not selected_id):
                    raise ValueError("연속 측정에서 TC1~12 모두 안정된 3분 평균을 먼저 선택하세요.")
                updated = TemperatureCalibration(True, reference, raw, tuple(reference-old.initial_value(v,i) for i,v in enumerate(raw)),
                                                  identifier, stamp, payload.get("source", "직접 입력"), evidence,old.initial_calibration)
            elif action == "disable":
                updated = replace(old, enabled=False, profile_id=identifier, created_at=stamp)
            elif action == "reset":
                updated = TemperatureCalibration(profile_id=identifier, created_at=stamp,initial_calibration=old.initial_calibration)
            else:
                raise ValueError("보정 저장·해제·초기화 동작을 선택하세요.")
            self._persist_temperature_profile(updated)
            return updated.to_dict()

    def _persist_temperature_profile(self,updated):
        self.results_root.mkdir(parents=True, exist_ok=True)
        path = self.results_root / "temperature_calibration.json"
        temporary = path.with_name(".temperature_calibration_" + uuid.uuid4().hex + ".tmp")
        try:
            temporary.write_text(json.dumps(updated.to_dict(), ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)
        self.temperature_calibration = updated

    def curve_from_records(self):
        with self.lock:
            if not self.controller or not self.controller.records:
                raise ValueError("온도 기록이 먼저 필요합니다. 가상 실험 또는 CSV 재생을 실행하세요.")
            settings = self.calculation_settings
            rows = [calculate_stage(record, settings) for record in self.controller.records]
            result = prepare_curve({"saturation_c": settings["saturation_c"],
                                    "heat_flux_unit": "W/cm2", "rows": rows})
            result["calculation_settings"] = settings
            result["source"] = "Average Temp / Total Flux · 선택 구간 샘플별 계산"
            self.curve = result
            return {"curve": result, "rows": rows}


class GuiServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, results_root):
        self.session = GuiSession(Path(results_root))
        self.token = secrets.token_urlsafe(32)
        super().__init__(address, GuiHandler)

    @property
    def origin(self):
        return f"http://127.0.0.1:{self.server_address[1]}"


class GuiHandler(BaseHTTPRequestHandler):
    server_version = "BoilingGUI/1.0"

    def log_message(self, format, *args):
        pass

    def _send(self, status, body, content_type="application/json; charset=utf-8", **headers):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for name, value in headers.items():
            self.send_header(name.replace("_", "-"), value)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, value, status=200):
        self._send(status, json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8"))

    def _local_request(self):
        expected_host = f"127.0.0.1:{self.server.server_address[1]}"
        if self.headers.get("Host") != expected_host:
            self._json({"error": "허용되지 않은 호스트입니다."}, 403)
            return False
        origin = self.headers.get("Origin")
        if origin and origin != self.server.origin:
            self._json({"error": "이 프로그램 창에서 실행하세요."}, 403)
            return False
        return True

    def do_GET(self):
        if not self._local_request():
            return
        url = urlparse(self.path)
        try:
            if url.path == "/":
                self._send(200, (Path(__file__).parent / "web" / "index.html").read_bytes(), "text/html; charset=utf-8")
            elif url.path in ("/analysis.js", "/leak.js", "/time-range.js", "/alarms.js", "/temperature-calibration.js", "/calibration-capture.js", "/initial-calibration.js"):
                self._send(200, (Path(__file__).parent / "web" / url.path[1:]).read_bytes(), "application/javascript; charset=utf-8")
            elif url.path == "/api/bootstrap":
                self._json({"token": self.server.token, "hardware_connected": False})
            elif url.path == "/api/state":
                self._json(self.server.session.snapshot(include_std_history=parse_qs(url.query).get("compact") != ["1"]))
            elif url.path == "/api/std-history":
                query = parse_qs(url.query)
                self._json(self.server.session.std_history_since(int(query.get("from", ["0"])[0]), query.get("run_name", [None])[0],
                           int(query["until"][0]) if "until" in query else None))
            elif url.path == "/api/record":
                index = int(parse_qs(url.query).get("index", ["-1"])[0])
                self._json(self.server.session.record(index))
            elif url.path == "/api/export":
                body, filename = self.server.session.export()
                self._send(200, body, "application/zip", Content_Disposition=f'attachment; filename="{filename}"')
            elif url.path == "/api/boiling/export":
                self._send(200, self.server.session.export_curve(), "text/csv; charset=utf-8",
                           Content_Disposition='attachment; filename="boiling_curve.csv"')
            elif url.path == "/api/calculation":
                self._json(self.server.session.calculation_settings)
            elif url.path == "/api/calibration-capture/export":
                body, filename = self.server.session.export_calibration_capture()
                self._send(200, body, "application/zip", Content_Disposition=f'attachment; filename="{filename}"')
            elif url.path == "/api/calibration-capture/ni-defaults":
                self._json({"physical_channels": DEFAULT_CHANNELS, "thermocouple_types": TC_TYPES})
            elif url.path == "/api/initial-calibration":
                self._json(self.server.session.initial_workspace())
            elif url.path == "/api/initial-calibration/export":
                kind=parse_qs(url.query).get('format',['json'])[0]
                self._send(200,self.server.session.export_initial_data(kind),
                           'text/csv; charset=utf-8' if kind=='csv' else 'application/json; charset=utf-8',
                           Content_Disposition=f'attachment; filename="TC_initial_calibration.{kind}"')
            elif url.path == "/api/temperature-calibration":
                with self.server.session.lock:
                    self._json(self.server.session.temperature_calibration.to_dict())
            elif url.path == "/api/leak-settings":
                self._json(asdict(self.server.session.leak_config))
            elif url.path == "/api/calculation/reference":
                self._json(default_settings())
            elif url.path == "/api/boiling/export-zip":
                with self.server.session.lock:
                    body = self.server.session.export_curve()
                    output = io.BytesIO()
                    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
                        archive.writestr("boiling_curve.csv", body)
                        archive.writestr("settings.json", json.dumps(self.server.session.curve, ensure_ascii=False, indent=2, allow_nan=False))
                    self._send(200, output.getvalue(), "application/zip", Content_Disposition='attachment; filename="boiling_curve.zip"')
            elif url.path == "/favicon.ico":
                self._send(204, b"", "image/x-icon")
            else:
                self._json({"error": "찾을 수 없는 요청입니다."}, 404)
        except (ValueError, OSError) as error:
            self._json({"error": str(error)}, 400)

    def do_POST(self):
        if not self._local_request():
            return
        if not secrets.compare_digest(self.headers.get("X-App-Token", ""), self.server.token):
            self._json({"error": "프로그램 창을 새로 열고 다시 시도하세요."}, 403)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 0 <= size <= MAX_REQUEST_BYTES:
                raise ValueError("파일 크기가 너무 큽니다. 20MB 이하의 CSV를 사용하세요.")
            data = json.loads(self.rfile.read(size) or b"{}")
            path = urlparse(self.path).path
            if path == "/api/start":
                self._json(self.server.session.start(data))
            elif path == "/api/critical-temperature":
                self._json(self.server.session.update_critical_temperature(data))
            elif path == "/api/initial-calibration/data":
                self._json(self.server.session.update_initial_data(data))
            elif path == "/api/initial-calibration/fit":
                self._json(self.server.session.fit_initial_data(data))
            elif path == "/api/initial-calibration/activate":
                self._json(self.server.session.activate_initial_calibration(data))
            elif path == "/api/temperature-calibration":
                self._json(self.server.session.save_temperature_calibration(data))
            elif path == "/api/calibration-capture/start":
                self._json(self.server.session.start_calibration_capture(data))
            elif path == "/api/calibration-capture/stop":
                self._json(self.server.session.stop_calibration_capture(data))
            elif path == "/api/calibration-capture/select":
                self._json(self.server.session.select_calibration_reference(data))
            elif path == "/api/temperature-calibration/preview":
                self._json(self.server.session.preview_temperature_calibration(data))
            elif path == "/api/stop":
                self._json(self.server.session.stop())
            elif path == "/api/emergency":
                self._json(self.server.session.stop("emergency_stop"))
            elif path == "/api/inject":
                if not isinstance(data, dict):
                    raise ValueError("시험 요청 형식이 올바르지 않습니다.")
                self._json(self.server.session.inject(data.get("channel", 7)))
            elif path == "/api/boiling":
                self._json(self.server.session.prepare_curve(data))
            elif path == "/api/boiling/import":
                if not isinstance(data, dict):
                    raise ValueError("CSV 입력 형식이 올바르지 않습니다.")
                self._json(import_curve_csv(data.get("csv_text"), data.get("heat_flux_unit", "W/cm2")))
            elif path == "/api/calculation":
                self._json(self.server.session.save_settings(data))
            elif path == "/api/leak-settings":
                self._json(self.server.session.save_leak_settings(data))
            elif path == "/api/boiling/from-records":
                self._json(self.server.session.curve_from_records())
            elif path == "/api/shutdown":
                self.server.session.stop("application_closed")
                self._json({"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
            else:
                self._json({"error": "찾을 수 없는 요청입니다."}, 404)
        except (ValueError, TypeError, UnicodeDecodeError, OSError) as error:
            self._json({"error": str(error)}, 400)


def main(argv=None):
    parser = argparse.ArgumentParser(description="TC/JPT local GUI; offline experiment control and optional read-only NI calibration input")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--results", type=Path, default=ROOT / "results")
    args = parser.parse_args(argv)
    server = GuiServer(("127.0.0.1", args.port), args.results)
    if not args.no_browser:
        webbrowser.open(server.origin)
    print("TC / JPT GUI를 시작했습니다. 브라우저의 프로그램 종료 버튼 또는 Ctrl+C로 종료하세요.", flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.session.stop("application_closed")
        for worker in (server.session.worker, server.session.capture_worker):
            if worker and worker.is_alive():
                worker.join(3)
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
