"""Shared numeric validation and stable-window evidence for TC calibration."""
from dataclasses import dataclass
import math

ALL_CHANNELS = tuple(f'TC{i}' for i in range(1,13))


def finite(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
        raise ValueError('보정 온도는 유한한 숫자여야 합니다.')
    return float(value)


@dataclass(frozen=True)
class ReferenceEvidence:
    capture_id: str
    reference_id: str
    source: str
    start_s: float
    end_s: float
    window_s: float
    sample_count: int
    means_c: tuple[float,...]
    std_c: tuple[float,...]
    ranges_c: tuple[float,...]
    allowed_std_c: float
    allowed_range_c: float
    selected_at: str
    samples_sha256: str

    def __post_init__(self):
        for key in ('start_s','end_s','window_s','allowed_std_c','allowed_range_c'):
            finite(getattr(self,key))
        if not 180 <= self.window_s <= 3600 or not math.isclose(self.end_s-self.start_s,self.window_s,abs_tol=1e-7):
            raise ValueError('보정 안정 구간은 연속 180초 이상이어야 합니다.')
        if self.allowed_std_c < 0 or self.allowed_range_c < 0 or type(self.sample_count) is not int or self.sample_count < 2:
            raise ValueError('보정 기준의 샘플 수 또는 안정화 설정을 확인하세요.')
        for key in ('means_c','std_c','ranges_c'):
            values=getattr(self,key)
            if len(values)!=12:raise ValueError('12채널의 보정 근거가 필요합니다.')
            for value in values:finite(value)
        if any(v<0 or v>self.allowed_std_c for v in self.std_c) or any(v<0 or v>self.allowed_range_c for v in self.ranges_c):
            raise ValueError('선택한 구간이 안정화 설정을 초과합니다.')
        for key in ('capture_id','reference_id','source','selected_at','samples_sha256'):
            value=getattr(self,key)
            if not isinstance(value,str) or not value or len(value)>200:
                raise ValueError('보정 측정 근거 형식이 올바르지 않습니다.')

    @classmethod
    def from_dict(cls,value):
        if not isinstance(value,dict):raise ValueError('보정 측정 근거 형식이 올바르지 않습니다.')
        try:
            data=dict(value)
            for key in ('means_c','std_c','ranges_c'):data[key]=tuple(data[key])
            return cls(**data)
        except (TypeError,KeyError) as error:
            raise ValueError('보정 측정 근거를 읽을 수 없습니다.') from error

