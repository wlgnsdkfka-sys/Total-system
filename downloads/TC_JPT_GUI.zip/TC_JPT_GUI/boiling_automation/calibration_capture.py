"""Continuous raw TC acquisition, stable reference selection and durable records."""
from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
import csv
import hashlib
import io
import json
from pathlib import Path
import statistics
import uuid
import zipfile

from .core import Reading, _interval
from .temperature_calibration import ALL_CHANNELS, ReferenceEvidence, finite

SEOUL=timezone(timedelta(hours=9))


@dataclass(frozen=True)
class CaptureConfig:
    window_s: float = 180.0
    allowed_std_c: float = .1
    allowed_range_c: float = .5
    max_gap_s: float = 2.0

    def __post_init__(self):
        for name in ('window_s','allowed_std_c','allowed_range_c','max_gap_s'):finite(getattr(self,name))
        if not 180<=self.window_s<=3600:raise ValueError('안정 확인 시간은 180~3600초입니다.')
        if self.allowed_std_c<0 or self.allowed_range_c<0 or self.max_gap_s!=2:
            raise ValueError('허용 표준편차·변동폭은 0 이상이어야 합니다. 샘플 간격 한도는 2초입니다.')


def values(point,channel_count=12):
    result=tuple(point.temperatures_c) if channel_count==8 else (*point.temperatures_c,*point.bulk_temperatures_c)
    if len(point.temperatures_c)!=8 or len(result)!=channel_count:
        raise ValueError(f'보정 측정에는 TC1~{channel_count} 모두 필요합니다.')
    return tuple(finite(v) for v in result)


class CalibrationCapture:
    def __init__(self,directory: Path,config: CaptureConfig,source: str,speed: float,source_settings=None,purpose="offset",demo_reference_c=100.):
        if purpose not in ('offset','furnace'):raise ValueError('보정 측정 목적을 확인하세요.')
        self.purpose=purpose;self.channel_count=8 if purpose=="furnace" else 12;self.channels=ALL_CHANNELS[:self.channel_count];self.demo_reference_c=finite(demo_reference_c)
        self.directory=directory
        self.config=config;self.source=source;self.speed=speed
        self.capture_id=directory.name;self.active=True;self.reason=None;self.error=None
        self.latest=None;self.first_t=None;self.count=0;self.hardware_connected=False
        self.window=deque();self.history=deque(maxlen=2000)
        self.stats=None;self.coverage_s=0.;self.stable=False;self.previous_status=None
        self.references={};self.selected_reference_id=None;self.reference_files=[]
        self.streams=[];self.closed=False
        directory.mkdir(parents=True,exist_ok=False)
        self.metadata={'version':'12.0.0','capture_id':self.capture_id,'mode':'temperature_calibration_capture',
                       'purpose':purpose,'channel_names':self.channels,'demo_reference_c':self.demo_reference_c,'source':source,'speed':speed,'power_index_percent':-1,'laser_control_connected':False,
                       'source_settings':source_settings or {},'stability':asdict(config),
                       'started_at':datetime.now(SEOUL).isoformat(),'temperature_basis':'uncorrected_raw',
                       'automatic_boiling_detection':False}
        try:
            self._metadata()
            self.raw_stream=self._open('raw_samples.csv',newline='');self.raw_writer=csv.writer(self.raw_stream)
            self.raw_writer.writerow(['t_s','elapsed_s','power_index_percent',*self.channels])
            self.event_stream=self._open('events.jsonl')
            self._event('capture_started',0,{'source':source,'power_index_percent':-1})
            self.raw_stream.flush()
        except Exception:
            self.close();raise

    def _open(self,name,**kwargs):
        f=(self.directory/name).open('w',encoding='utf-8',**kwargs);self.streams.append(f);return f

    def _metadata(self):
        temporary=self.directory/'.capture.tmp'
        try:
            temporary.write_text(json.dumps(self.metadata,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
            temporary.replace(self.directory/'capture.json')
        finally:temporary.unlink(missing_ok=True)

    def _event(self,kind,t,details):
        self.event_stream.write(json.dumps({'kind':kind,'t_s':t,'details':details},ensure_ascii=False,allow_nan=False)+'\n')
        self.event_stream.flush()

    def observe(self,point: Reading):
        if not self.active:raise ValueError('종료된 보정 측정입니다.')
        t=finite(point.t_s);raw=values(point,self.channel_count)
        if t<0 or self.latest and (t<=self.latest.t_s or t-self.latest.t_s>self.config.max_gap_s):
            raise ValueError('온도 데이터가 역행하거나 2초 이상 누락됐습니다. 연속 3분을 다시 측정하세요.')
        first=t if self.first_t is None else self.first_t
        self.raw_writer.writerow([t,t-first,-1,*raw]);self.raw_stream.flush()
        self.first_t=first;self.latest=point;self.count+=1
        self.window.append(point);self.history.append({'t_s':t,'values_c':raw})
        while len(self.window)>1 and self.window[1].t_s<=t-self.config.window_s:self.window.popleft()
        while len(self.history)>1 and self.history[1]['t_s']<t-900:self.history.popleft()
        start=max(self.window[0].t_s,t-self.config.window_s);self.coverage_s=t-start
        self.stats=None;self.stable=False
        if len(self.window)>=2:
            selected=_interval(list(self.window),start,t)
            vectors=[values(p,self.channel_count) for p in selected]
            means=[finite(statistics.mean(v[i] for v in vectors)) for i in range(self.channel_count)]
            std=[finite(statistics.stdev(v[i] for v in vectors)) for i in range(self.channel_count)]
            ranges=[finite(max(v[i] for v in vectors)-min(v[i] for v in vectors)) for i in range(self.channel_count)]
            self.stats={'start_s':start,'end_s':t,'sample_count':len(selected),'means_c':means,'std_c':std,'ranges_c':ranges}
            self.stable=(self.coverage_s>=self.config.window_s and max(std)<=self.config.allowed_std_c
                         and max(ranges)<=self.config.allowed_range_c)
        status='stable' if self.stable else 'collecting' if self.coverage_s<self.config.window_s else 'unstable'
        if status!=self.previous_status:
            self._event('stability_changed',t,{'status':status,'coverage_s':self.coverage_s,
                        'max_std_c':max(self.stats['std_c']) if self.stats else None,
                        'max_range_c':max(self.stats['ranges_c']) if self.stats else None})
            self.previous_status=status

    def select_reference(self):
        if self.error or self.reason in ('emergency_stop','application_closed','capture_error') or not self.stable or not self.stats:
            raise ValueError(f'TC1~{self.channel_count} 모두 연속 3분 이상 안정된 구간이 필요합니다.')
        stats=self.stats
        selected=_interval(list(self.window),stats['start_s'],stats['end_s'])
        out=io.StringIO(newline='');writer=csv.writer(out)
        writer.writerow(['t_s','interpolated',*self.channels])
        for p in selected:writer.writerow([p.t_s,int(p.interpolated),*values(p,self.channel_count)])
        samples=out.getvalue().encode('utf-8');reference_id=uuid.uuid4().hex
        evidence=ReferenceEvidence(self.capture_id,reference_id,self.source,stats['start_s'],stats['end_s'],
                                  self.config.window_s,stats['sample_count'],tuple(stats['means_c']),
                                  tuple(stats['std_c']),tuple(stats['ranges_c']),self.config.allowed_std_c,
                                  self.config.allowed_range_c,datetime.now(SEOUL).isoformat(),hashlib.sha256(samples).hexdigest())
        # Each selection has its own immutable files, even after a later selection.
        sample_name='reference_'+reference_id+'.csv';json_name='reference_'+reference_id+'.json'
        (self.directory/sample_name).write_bytes(samples)
        (self.directory/json_name).write_text(json.dumps(asdict(evidence),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        if not self.closed:self._event('reference_selected',stats['end_s'],{'reference_id':reference_id})
        self.reference_files.extend([sample_name,json_name]);self.references[reference_id]=evidence
        self.selected_reference_id=reference_id
        return {'reference_raw_c':list(evidence.means_c),'reference_id':reference_id,'capture_id':self.capture_id,
                'source':f'연속 측정 안정 {self.config.window_s:g}초 평균','evidence':asdict(evidence)}

    def finish(self,reason='user_stop',error=None):
        if not self.active:return
        self.active=False;self.reason=reason;self.error=(str(error) or '온도 입력 오류') if error is not None else None
        if self.error or reason in ('emergency_stop','application_closed','capture_error'):self.stable=False
        self.metadata.update(finished_at=datetime.now(SEOUL).isoformat(),reason=reason,error=self.error,
                             sample_count=self.count,hardware_connected=False,
                             hardware_samples_received=self.hardware_connected)
        try:
            self._event('capture_finished',self.latest.t_s if self.latest else 0,{'reason':reason,'error':self.error,'power_index_percent':-1})
            self._metadata()
        finally:self.close()

    def close(self):
        for stream in self.streams:
            if not stream.closed:stream.close()
        self.closed=True

    def snapshot(self):
        return {'capture_id':self.capture_id,'purpose':self.purpose,'channel_names':self.channels,'demo_reference_c':self.demo_reference_c,'active':self.active,'source':self.source,'speed':self.speed,
                'reason':self.reason,'error':self.error,'hardware_connected':self.active and self.hardware_connected,
                'hardware_samples_received':self.hardware_connected,
                'source_settings':self.metadata['source_settings'],
                'power_index_percent':-1,'config':asdict(self.config),'first_t_s':self.first_t,
                'elapsed_s':self.latest.t_s-self.first_t if self.latest else 0,'sample_count':self.count,
                'latest':{'t_s':self.latest.t_s,'values_c':values(self.latest,self.channel_count)} if self.latest else None,
                'coverage_s':self.coverage_s,'stable':self.stable,'stats':self.stats,
                'history':list(self.history),'selected_reference_id':self.selected_reference_id,
                'result_folder':str(self.directory)}

    def export(self):
        return self.export_snapshot(self.prepare_export()),self.capture_id+'.zip'

    def prepare_export(self):
        """Freeze byte lengths after complete rows; compression runs without the input lock."""
        for stream in self.streams:
            if not stream.closed:stream.flush()
        metadata={**self.metadata,'exported_at':datetime.now(SEOUL).isoformat(),
                  'capture_active':self.active,'sample_count':self.count,
                  'hardware_connected':self.active and self.hardware_connected,
                  'hardware_samples_received':self.hardware_connected,
                  'selected_reference_id':self.selected_reference_id}
        entries=[('capture.json',json.dumps(metadata,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8'))]
        for name in ['raw_samples.csv','events.jsonl',*self.reference_files]:
            path=self.directory/name
            entries.append((name,(path,path.stat().st_size)))
        return entries

    @staticmethod
    def export_snapshot(entries):
        out=io.BytesIO()
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
            for name,source in entries:
                if isinstance(source,bytes):
                    z.writestr(name,source)
                    continue
                path,remaining=source
                with path.open('rb') as reader,z.open(name,'w') as target:
                    while remaining:
                        chunk=reader.read(min(65536,remaining))
                        if not chunk:raise OSError('보정 측정 파일을 끝까지 읽지 못했습니다.')
                        target.write(chunk);remaining-=len(chunk)
        return out.getvalue()
