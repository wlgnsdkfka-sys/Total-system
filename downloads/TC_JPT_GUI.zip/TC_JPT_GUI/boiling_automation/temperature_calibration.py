"""One-point TC1..12 offsets and immutable acquisition evidence."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math

from .core import Reading

from .calibration_common import ALL_CHANNELS, ReferenceEvidence, finite
from .initial_calibration import InitialProfile


@dataclass(frozen=True)
class TemperatureCalibration:
    enabled: bool = False
    reference_c: float = 100.0
    reference_raw_c: tuple[float,...] = ()
    offsets_c: tuple[float,...] = (0.0,)*12
    profile_id: str = 'uncalibrated'
    created_at: str = ''
    source: str = 'none'
    reference_evidence: ReferenceEvidence | None = None
    initial_calibration: InitialProfile | None = None

    def __post_init__(self):
        if type(self.enabled) is not bool:
            raise ValueError('보정 사용 여부가 올바르지 않습니다.')
        finite(self.reference_c)
        if len(self.offsets_c)!=12 or len(self.reference_raw_c) not in (0,12):
            raise ValueError('TC1~12 모두의 보정값이 필요합니다.')
        for value in (*self.offsets_c,*self.reference_raw_c):finite(value)
        if self.enabled and not self.reference_raw_c:
            raise ValueError('보정 기준 원시온도 12개를 입력하세요.')
        if self.initial_calibration is not None and not isinstance(self.initial_calibration,InitialProfile):
            raise ValueError('초기 다점 보정식 형식을 확인하세요.')
        if self.reference_raw_c:
            for i,(raw,offset) in enumerate(zip(self.reference_raw_c,self.offsets_c)):
                expected=self.reference_for(i)-self.initial_value(raw,i)
                if not math.isfinite(expected) or not math.isclose(offset,expected,rel_tol=0,abs_tol=1e-9):
                    raise ValueError('비등 보정값은 기준온도 − 초기 보정 후 온도여야 합니다.')
        elif any(self.offsets_c):
            raise ValueError('원시온도 없이 보정값을 설정할 수 없습니다.')
        for name in ('profile_id','created_at','source'):
            value=getattr(self,name)
            if not isinstance(value,str) or len(value)>200:
                raise ValueError('보정 이력 형식이 올바르지 않습니다.')
        if self.reference_evidence is not None:
            if not isinstance(self.reference_evidence,ReferenceEvidence) or len(self.reference_raw_c)!=12 or len(self.reference_evidence.means_c)!=12:
                raise ValueError('보정 원시온도와 측정 근거를 확인하세요.')
            if any(not math.isclose(a,b,rel_tol=0,abs_tol=1e-9)
                   for a,b in zip(self.reference_raw_c,self.reference_evidence.means_c)):
                raise ValueError('선택한 안정 구간의 평균과 보정 기준이 다릅니다.')

    @classmethod
    def from_dict(cls,value):
        if not isinstance(value,dict):raise ValueError('보정 설정 형식이 올바르지 않습니다.')
        try:
            data=dict(value)
            policy=data.pop('bulk_calibration',None)
            if policy not in (None,'boiling_offset_only_100c'):raise ValueError('bulk 보정 방식을 확인하세요.')
            legacy=policy is None
            for key in ('reference_raw_c','offsets_c'):
                if key in data:data[key]=tuple(data[key])
            if data.get('reference_evidence') is not None:
                data['reference_evidence']=ReferenceEvidence.from_dict(data['reference_evidence'])
            if data.get('initial_calibration') is not None:
                data['initial_calibration']=InitialProfile.from_dict(data['initial_calibration'])
            if legacy and data.get('reference_raw_c') and len(data.get('offsets_c',()))==12:
                data['offsets_c']=tuple(data['offsets_c'][:8])+tuple(100-finite(v) for v in data['reference_raw_c'][8:])
            return cls(**data)
        except (TypeError,KeyError) as error:
            raise ValueError('보정 설정을 읽을 수 없습니다.') from error

    def to_dict(self,include_initial_points=True):
        return {'bulk_calibration':'boiling_offset_only_100c','enabled':self.enabled,'reference_c':self.reference_c,'reference_raw_c':self.reference_raw_c,
                'offsets_c':self.offsets_c,'profile_id':self.profile_id,'created_at':self.created_at,'source':self.source,
                'reference_evidence':asdict(self.reference_evidence) if self.reference_evidence else None,
                'initial_calibration':self.initial_calibration.to_dict(include_initial_points) if self.initial_calibration else None}

    @staticmethod
    def reference_for_bulk():return 100.0

    def reference_for(self,channel):return self.reference_c if channel<8 else self.reference_for_bulk()

    def initial_value(self,value,channel):
        return self.initial_calibration.correct(value,channel) if self.initial_calibration and channel<8 else value

    def correct_value(self,value,channel):
        return self.initial_value(value,channel)+(self.offsets_c[channel] if self.enabled else 0)

    def raw_for_corrected(self,value,channel):
        adjusted=value-(self.offsets_c[channel] if self.enabled else 0)
        if self.initial_calibration and channel<8:
            c=self.initial_calibration.channels[channel]
            return (adjusted-c.intercept_c)/c.gain
        return adjusted

    def apply(self,raw: Reading) -> Reading:
        temperatures=tuple(self.correct_value(v,i) for i,v in enumerate(raw.temperatures_c))
        bulk=tuple(None if v is None else self.correct_value(v,i+8) for i,v in enumerate(raw.bulk_temperatures_c))
        return Reading(raw.t_s,temperatures,interpolated=raw.interpolated,
                       bulk_temperatures_c=bulk,raw_temperatures_c=raw.temperatures_c,
                       raw_bulk_temperatures_c=raw.bulk_temperatures_c)
