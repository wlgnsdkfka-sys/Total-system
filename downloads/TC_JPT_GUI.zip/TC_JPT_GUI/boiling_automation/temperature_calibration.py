"""One-point TC1..12 offsets. Reference capture never operates hardware."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math

from .core import Reading

ALL_CHANNELS = tuple(f'TC{i}' for i in range(1,13))


def finite(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
        raise ValueError('보정 온도는 유한한 숫자여야 합니다.')
    return float(value)


@dataclass(frozen=True)
class TemperatureCalibration:
    enabled: bool = False
    reference_c: float = 100.0
    reference_raw_c: tuple[float,...] = ()
    offsets_c: tuple[float,...] = (0.0,)*12
    profile_id: str = 'uncalibrated'
    created_at: str = ''
    source: str = 'none'

    def __post_init__(self):
        if type(self.enabled) is not bool:
            raise ValueError('보정 사용 여부가 올바르지 않습니다.')
        finite(self.reference_c)
        if len(self.offsets_c)!=12 or len(self.reference_raw_c) not in (0,12):
            raise ValueError('TC1~12 모두의 보정값이 필요합니다.')
        for value in (*self.offsets_c,*self.reference_raw_c):finite(value)
        if self.enabled and not self.reference_raw_c:
            raise ValueError('보정 기준 원시온도 12개를 입력하세요.')
        if self.reference_raw_c:
            for raw,offset in zip(self.reference_raw_c,self.offsets_c):
                expected=self.reference_c-raw
                if not math.isfinite(expected) or not math.isclose(offset,expected,rel_tol=0,abs_tol=1e-9):
                    raise ValueError('보정값은 기준온도 − 원시온도여야 합니다.')
        elif any(self.offsets_c):
            raise ValueError('원시온도 없이 보정값을 설정할 수 없습니다.')
        for name in ('profile_id','created_at','source'):
            value=getattr(self,name)
            if not isinstance(value,str) or len(value)>200:
                raise ValueError('보정 이력 형식이 올바르지 않습니다.')

    @classmethod
    def from_dict(cls,value):
        if not isinstance(value,dict):raise ValueError('보정 설정 형식이 올바르지 않습니다.')
        try:
            data=dict(value)
            for key in ('reference_raw_c','offsets_c'):
                if key in data:data[key]=tuple(data[key])
            return cls(**data)
        except (TypeError,KeyError) as error:
            raise ValueError('보정 설정을 읽을 수 없습니다.') from error

    def to_dict(self):return asdict(self)

    def apply(self,raw: Reading) -> Reading:
        offsets=self.offsets_c if self.enabled else (0.0,)*12
        temperatures=tuple(v+offsets[i] for i,v in enumerate(raw.temperatures_c))
        bulk=tuple(None if v is None else v+offsets[i+8] for i,v in enumerate(raw.bulk_temperatures_c))
        return Reading(raw.t_s,temperatures,interpolated=raw.interpolated,
                       bulk_temperatures_c=bulk,raw_temperatures_c=raw.temperatures_c,
                       raw_bulk_temperatures_c=raw.bulk_temperatures_c)
