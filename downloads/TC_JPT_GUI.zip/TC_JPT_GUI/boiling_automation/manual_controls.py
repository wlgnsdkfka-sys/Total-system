"""Explicit NI shutter commands, independently queued closure, and staged laser settings."""
from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
import importlib
import json
import math
from pathlib import Path
import re
import threading
import time


OPEN_HIGH_S = .0010
CLOSE_HIGH_S = .0015
LOW_S = .0185


def now():
    return datetime.now(timezone(timedelta(hours=9))).isoformat()


def discover_outputs():
    """Enumerate devices/counter outputs without creating or starting a task."""
    try:
        system=importlib.import_module('nidaqmx.system').System.local()
        devices=[]
        for dev in system.devices:
            item={'name':dev.name,'model':dev.product_type,'simulated':dev.dev_is_simulated,
                  'counter_channels':[],'analog_input_channels':[],'error':None}
            try:item['counter_channels']=[c.name for c in dev.co_physical_chans]
            except Exception as error:item['error']=str(error)
            try:item['analog_input_channels']=[c.name for c in dev.ai_physical_chans]
            except Exception:pass
            devices.append(item)
        return {'devices':devices,'checked_at':now()}
    except Exception as error:
        raise ValueError('NI 출력 장치 조회 실패: '+str(error)) from error


@dataclass(frozen=True)
class ShutterSettings:
    counter_channel: str = ''
    output_terminal: str = ''

    @classmethod
    def from_payload(cls,payload):
        if not isinstance(payload,dict):raise ValueError('셔터 NI 설정을 확인하세요.')
        channel=payload.get('counter_channel','');terminal=payload.get('output_terminal','')
        if not isinstance(channel,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}/ctr\d{1,3}',channel):
            raise ValueError('실제 셔터 출력 채널을 장치명/ctr번호 형식으로 선택하세요.')
        if not isinstance(terminal,str) or terminal and not re.fullmatch(r'/?[A-Za-z0-9_-]{1,80}/PFI\d{1,3}',terminal):
            raise ValueError('출력 단자는 /장치명/PFI번호 형식입니다. 비우면 장치 기본 단자를 사용합니다.')
        # A cDAQ chassis counter may route to a module PFI terminal with a
        # different device prefix. DAQmx validates the actual terminal route.
        return cls(channel,terminal)


class NIShutter:
    """Hold a continuous counter pulse train; never create laser/AI/AO/DO tasks."""
    def __init__(self,settings):
        self.settings=settings;self.task=None

    def apply(self,action):
        if action not in ('open','close'):raise ValueError('셔터 열기 또는 닫기를 선택하세요.')
        nidaqmx=importlib.import_module('nidaqmx')
        constants=importlib.import_module('nidaqmx.constants')
        self.release()
        task=nidaqmx.Task()
        try:
            high=OPEN_HIGH_S if action=='open' else CLOSE_HIGH_S
            channel=task.co_channels.add_co_pulse_chan_time(
                self.settings.counter_channel,units=constants.TimeUnits.SECONDS,
                idle_state=constants.Level.LOW,initial_delay=0,high_time=high,low_time=LOW_S)
            if self.settings.output_terminal:channel.co_pulse_term=self.settings.output_terminal
            try:terminal=channel.co_pulse_term
            except Exception:terminal=self.settings.output_terminal or None
            task.timing.cfg_implicit_timing(sample_mode=constants.AcquisitionType.CONTINUOUS)
            task.start()
            self.task=task
            return {'action':action,'high_s':high,'low_s':LOW_S,'period_s':high+LOW_S,'output_terminal':terminal,'output_started_at':now()}
        except BaseException as error:
            try:task.close()
            except Exception as cleanup_error:
                self.task=task
                raise RuntimeError(str(error)+'; NI 출력 태스크 해제 실패: '+str(cleanup_error)) from error
            raise

    def release(self):
        if self.task is not None:
            try:self.task.close()
            except Exception as error:
                if getattr(error,'error_code',None)!=-200088:raise
                # An invalid/nonexistent task cannot be reused after recovery.
            self.task=None


class ManualControls:
    def __init__(self,root):
        self.root=Path(root);self.state_lock=threading.Lock();self.io_lock=threading.RLock();self.log_lock=threading.Lock()
        self.driver=None;self.close_worker=None;self.pending_close=False;self.close_reason=None
        self.interlock_revision=0
        self.auto_reconnect_suppressed=False;self.last_ack_monotonic=None
        self.settings=ShutterSettings();self.events=deque(maxlen=40)
        self.laser_settings=self.validate_laser_settings({})
        self.state={'connected':False,'busy':False,'pwm_active':False,'last_command':None,
                    'last_close_reason':None,
                    'actual_position':None,'position_feedback_available':False,'output_terminal':None,
                    'error':None,'inhibit_reason':None,'close_requested':False,'interlock_revision':0}
        self.state.update(connection_origin=None,connection_note=None,tx_count=0,last_command_at=None,
                          last_error=None,last_error_at=None,error_code=None,error_hint=None)
        path=self.root/'manual_control_settings.json'
        self.settings_file_exists=path.is_file()
        if self.settings_file_exists:
            try:
                saved=json.loads(path.read_text(encoding='utf-8'))
                if saved.get('shutter',{}).get('counter_channel'):self.settings=ShutterSettings.from_payload(saved['shutter'])
                self.laser_settings=self.validate_laser_settings(saved.get('laser',self.laser_settings))
            except (ValueError,TypeError,OSError) as error:self.state['error']='수동 설정 불러오기 실패: '+str(error)

    @staticmethod
    def validate_laser_settings(payload):
        if not isinstance(payload,dict):raise ValueError('레이저 수동 설정을 확인하세요.')
        if payload.get('control_mode','GUI Ctrl')!='GUI Ctrl':
            raise ValueError('레이저 요청 제어 모드는 GUI Ctrl(Full Control)입니다.')
        result={'control_mode':'GUI Ctrl'}
        defaults={'power_percent':0.,'frequency_khz':0.,'pulse_width_ns':1.}
        for key in ('power_percent','frequency_khz','pulse_width_ns'):
            value=payload.get(key,defaults[key])
            if value is None or value=='':
                if key=='power_percent':raise ValueError('레이저 출력 %를 입력하세요.')
                value=defaults[key]
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):raise ValueError('레이저 설정에 유효한 숫자를 입력하세요.')
            if (key=='power_percent' and not 0<=value<=100
                    or key=='frequency_khz' and value<0
                    or key=='pulse_width_ns' and value<=0):
                raise ValueError('출력은 0~100%, 주파수는 0 kHz 이상, 펄스폭은 0 ns보다 커야 합니다.')
            result[key]=float(value)
        return result

    def _save(self,settings=None,laser=None):
        self.root.mkdir(parents=True,exist_ok=True)
        data={'version':1,'shutter':asdict(settings or self.settings),'laser':laser or self.laser_settings,
              'shutter_waveform_s':{'open_high':OPEN_HIGH_S,'close_high':CLOSE_HIGH_S,'low':LOW_S}}
        path=self.root/'manual_control_settings.json';temporary=path.with_name('.manual_settings.tmp')
        try:
            temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
            temporary.replace(path)
            self.settings_file_exists=True
        finally:temporary.unlink(missing_ok=True)

    def _record(self,action,details):
        event={'at':now(),'action':action,'details':details}
        self.root.mkdir(parents=True,exist_ok=True)
        with self.log_lock:
            with (self.root/'manual_control_events.jsonl').open('a',encoding='utf-8') as f:
                f.write(json.dumps(event,ensure_ascii=False,allow_nan=False)+'\n');f.flush()
        with self.state_lock:self.events.append(event)

    def snapshot(self):
        with self.state_lock:
            return {'shutter':{**self.state,'configured':self.driver is not None,'settings':asdict(self.settings),
                    'auto_reconnect_suppressed':self.auto_reconnect_suppressed,
                    'waveform_s':{'open_high':OPEN_HIGH_S,'close_high':CLOSE_HIGH_S,'low':LOW_S}},
                    'laser':{'connected':False,'emission_state':'unknown','power_index_percent':None,
                             'settings':dict(self.laser_settings),'settings_applied_to_hardware':False,
                             'reported_control_mode':None,'control_mode_verified':False},
                    'events':list(self.events)}

    def connect(self,payload,*,inventory=None,restore=False):
        settings=ShutterSettings.from_payload(payload)
        with self.io_lock:
            if self.driver and self.driver.task is not None:raise ValueError('출력을 해제한 뒤 NI 설정을 변경하세요.')
            inventory=discover_outputs() if inventory is None else inventory
            found=[d for d in inventory['devices'] if settings.counter_channel in d['counter_channels']]
            if not found:raise ValueError('선택한 NI 카운터 출력 채널을 찾지 못했습니다. 장치 목록을 다시 조회하세요.')
            if found[0]['simulated']:raise ValueError('실제 셔터에는 시뮬레이션 NI 장치를 사용할 수 없습니다.')
            self._save(settings=settings)
            self._record('shutter_restore_check' if restore else 'shutter_connected',{'settings':asdict(settings),'model':found[0]['model'],'output_started':False})
            with self.state_lock:
                if restore and self.auto_reconnect_suppressed:return
                self.settings=settings;self.driver=NIShutter(settings)
                self.auto_reconnect_suppressed=False
                self.state.update(connected=True,error=None,last_command=None,pwm_active=False,output_terminal=None,
                                  connection_origin='restored' if restore else 'manual',error_code=None,error_hint=None,
                                  connection_note='저장 채널 연결 복원 · 출력 대기' if restore else '수동 연결 · 출력 대기')
        return self.snapshot()

    def reconcile_devices(self,inventory):
        """Background-only checks and logical restoration. Never resume a waveform."""
        if not self.io_lock.acquire(blocking=False):return
        try:
            with self.state_lock:
                settings=self.settings
                suppressed=self.auto_reconnect_suppressed
            if not settings.counter_channel:settings=ShutterSettings('myDAQ1/ctr0')
            device=next((d for d in inventory['devices'] if d['name']==settings.counter_channel.split('/')[0]),None)
            # An inventory-property failure is not proof that the device was
            # unplugged. Keep the owned waveform until a real fault is known.
            if device and device.get('error') and settings.counter_channel not in device['counter_channels']:return
            match=next((d for d in inventory['devices'] if not d['simulated'] and settings.counter_channel in d['counter_channels']),None)
            if match is None:
                if self.driver is not None:
                    try:self.driver.release()
                    except Exception as error:
                        with self.state_lock:self.state['error']='NI 연결 확인/출력 해제 실패: '+str(error)
                        return
                    with self.state_lock:
                        self.driver=None
                        message='NI 장치 또는 카운터가 검출되지 않습니다: '+settings.counter_channel
                        self.state.update(connected=False,pwm_active=False,last_command=None,error=message,
                                          last_error=message,last_error_at=now(),connection_note='장치 재검출 대기')
                return
            if self.driver is not None and self.driver.task is not None:
                try:
                    if self.driver.task.is_task_done():raise RuntimeError('NI 카운터 출력 태스크가 중지됐습니다.')
                except Exception as error:
                    try:self.driver.release()
                    except Exception:pass
                    with self.state_lock:
                        if self.driver.task is None:self.driver=None
                        self.state.update(connected=False,last_command=None,pwm_active=False,error=str(error),
                                          last_error=str(error),last_error_at=now(),connection_note='출력 자동 재개 안 함 · 장치 재확인 중')
                return
            if self.driver is None and not suppressed:
                self.connect(asdict(settings),inventory=inventory,restore=True)
        finally:self.io_lock.release()

    def save_laser(self,payload):
        settings=self.validate_laser_settings(payload)
        with self.io_lock:
            self._save(laser=settings)
            self._record('laser_settings_saved',{'settings':settings,'sent_to_hardware':False})
            with self.state_lock:self.laser_settings=settings
        return self.snapshot()

    def _perform(self,action,reason):
        attempted=False
        with self.state_lock:
            intended=self.driver
            if intended is None:raise ValueError('5번 탭에서 셔터 NI 출력 채널을 먼저 연결하세요.')
            if action=='open' and (self.state['inhibit_reason'] or self.state['close_requested']):
                raise ValueError('차단 요청이 있어 셔터를 열 수 없습니다. 정지 원인을 해소한 뒤 수동제어 복귀를 누르세요.')
        try:
            # Opening audit happens before I/O. Closing never waits for this disk
            # operation: it uses io_lock only for the NI command itself.
            if action=='open':self._record('shutter_command_requested',{'action':action,'reason':reason})
            with self.io_lock:
                with self.state_lock:
                    if self.driver is None:raise ValueError('셔터 연결이 해제됐습니다.')
                    if action=='open' and (self.driver is not intended or self.state['inhibit_reason'] or self.state['close_requested']):
                        raise ValueError('셔터 연결 또는 차단 상태가 변경되어 열기를 취소했습니다.')
                    self.state['busy']=True
                try:
                    attempted=True
                    result=self.driver.apply(action)
                    with self.state_lock:
                        self.state.update(connected=True,last_command=action,pwm_active=True,
                                          output_terminal=result['output_terminal'],error=None,
                                          last_close_reason=reason if action=='close' else None,
                                          connection_note='NI 명령 응답 확인 · PWM 유지 · 실제 위치 미확인',
                                          tx_count=self.state['tx_count']+1,last_command_at=result['output_started_at'],error_code=None,error_hint=None)
                        self.last_ack_monotonic=time.monotonic()
                finally:
                    with self.state_lock:self.state['busy']=False
        except Exception as error:
            with self.state_lock:
                self.state['error']=str(error)
                self.state['connection_note']='셔터 명령/연결 상태 재확인 필요'
                cause=error
                while cause is not None and getattr(cause,'error_code',None) is None:cause=cause.__cause__
                code=getattr(cause,'error_code',None)
                self.state.update(last_error=str(error),last_error_at=now(),error_code=code,
                                  error_hint='이전 프로그램이나 LabVIEW가 카운터를 사용 중일 수 있습니다. 이전 실행의 프로그램 종료 버튼 또는 실행 창 Ctrl+C로 종료한 뒤 다시 연결하세요.' if code==-50103 else None)
                if attempted:self.state.update(last_command=None,pwm_active=bool(self.driver and self.driver.task is not None))
            raise ValueError('셔터 출력 오류: '+str(error)) from error
        # Audit writes run without io_lock, so a stalled disk cannot block a
        # later emergency close while the shutter is open.
        try:
            if action=='close':self._record('shutter_command_requested',{'action':action,'reason':reason})
            self._record('shutter_command_started',{**result,'reason':reason,'position_confirmed':False})
        except OSError as error:
            if action=='open':self.request_close('opening_log_error',latch=True)
            with self.state_lock:self.state['error']=str(error)
            if action=='open':raise ValueError('셔터 열기 이력 저장 실패 · 닫기를 요청했습니다: '+str(error)) from error

    def open(self):
        self._perform('open','manual')
        # A close request arriving during NI setup has priority over this open.
        with self.state_lock:close_pending=self.pending_close or bool(self.state['inhibit_reason'])
        if close_pending:self.request_close('close_during_open')
        return self.snapshot()

    def request_close(self,reason='manual',*,latch=False):
        with self.state_lock:
            if latch:
                self.interlock_revision+=1
                self.state.update(inhibit_reason=reason,interlock_revision=self.interlock_revision)
            if self.driver is None:return
            if self.state['close_requested']:return
            if self.state['last_command']=='close' and self.state['last_close_reason']==reason and self.state['pwm_active'] and not self.state['busy'] and not self.state['error']:return
            self.pending_close=True;self.close_reason=reason;self.state['close_requested']=True
            if self.close_worker is None or not self.close_worker.is_alive():
                self.close_worker=threading.Thread(target=self._close_loop,daemon=True)
                self.close_worker.start()

    def _close_loop(self):
        while True:
            with self.state_lock:
                if not self.pending_close:
                    self.state['close_requested']=False
                    self.close_worker=None
                    return
                self.pending_close=False;reason=self.close_reason
            try:self._perform('close',reason)
            except ValueError:pass

    def clear_interlock(self):
        with self.state_lock:
            if not self.pending_close and not self.state['close_requested'] and not self.state['busy']:
                self.state['inhibit_reason']=None
                self.state['last_close_reason']=None
                return True
            return False

    def restore_manual_control(self, expected_revision):
        """Explicitly allow manual opening after a stopped run; never open here."""
        def check():
            if type(expected_revision) is not int or expected_revision!=self.interlock_revision:
                raise ValueError('차단 상태가 변경됐습니다. 현재 상태를 확인한 뒤 다시 시도하세요.')
            if not self.driver or not self.state['connected'] or self.state['error']:
                raise ValueError('셔터 NI 연결·출력 오류를 먼저 확인하세요.')
            if self.pending_close or self.state['close_requested'] or self.state['busy']:
                raise ValueError('셔터 닫기 요청을 처리 중입니다. 완료 후 다시 시도하세요.')
            if self.state['last_command']!='close' or not self.state['pwm_active']:
                raise ValueError('셔터 닫기 명령을 먼저 보내고 출력 상태를 확인하세요.')
        with self.state_lock:
            check()
            reason=self.state['inhibit_reason']
        # Audit outside state/io locks so another close never waits for disk I/O.
        self._record('shutter_manual_rearm_requested',{'previous_reason':reason,
                     'interlock_revision':expected_revision,'opens_shutter':False})
        with self.state_lock:
            # A concurrent critical/emergency request invalidates this reset.
            check()
            self.state['inhibit_reason']=None
        return self.snapshot()

    def wait_for_close(self,timeout=3):
        with self.state_lock:worker=self.close_worker
        if worker:worker.join(timeout)
        return not worker or not worker.is_alive()

    def disconnect(self):
        with self.state_lock:
            self.auto_reconnect_suppressed=True
            connected=self.driver is not None
        if not connected:return self.snapshot()
        self.request_close('disconnect')
        if not self.wait_for_close():raise ValueError('셔터 닫힘 명령을 처리 중입니다. 잠시 후 다시 시도하세요.')
        with self.io_lock:
            if self.driver:
                # Give the requested close waveform several periods before release.
                time.sleep(.06)
                try:self.driver.release()
                except Exception as error:raise ValueError('NI 출력 해제 실패: '+str(error)) from error
            with self.state_lock:
                self.driver=None;self.state.update(connected=False,pwm_active=False,last_command=None)
            self._record('shutter_output_released',{'actual_position':'unknown'})
        return self.snapshot()

    def reconnect(self):
        """Close/release only our own task, then rebind. Never reset the device."""
        settings=asdict(self.settings if self.settings.counter_channel else ShutterSettings('myDAQ1/ctr0'))
        self.disconnect()
        return self.connect(settings)

