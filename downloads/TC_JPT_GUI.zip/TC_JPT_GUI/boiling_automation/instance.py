"""Keep GUI launches in one user session from competing for the NI counter."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import urllib.request


class GuiInstance:
    def __init__(self,directory=None):
        base=Path(directory) if directory is not None else Path(tempfile.gettempdir())
        name='tc_jpt_gui_'+hashlib.sha256(str(Path.home()).encode()).hexdigest()[:12]
        self.path=base/(name+'.lock');self.info=base/(name+'.json');self.stream=None
    def acquire(self):
        self.stream=self.path.open('a+b')
        # Windows byte-range locks also deny reads of the locked byte. Query
        # file size instead, so a second launch reaches the nonblocking lock.
        if os.fstat(self.stream.fileno()).st_size==0:self.stream.write(b'0');self.stream.flush()
        self.stream.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            return True
        except OSError:
            self.stream.close();self.stream=None;return False
    def publish(self,origin,instance_id):
        if self.stream is None:raise RuntimeError('Instance lock is not held')
        temp=self.info.with_suffix('.tmp')
        temp.write_text(json.dumps({'origin':origin,'instance_id':instance_id}),encoding='utf-8');temp.replace(self.info)
    def existing_instance(self):
        try:
            saved=json.loads(self.info.read_text(encoding='utf-8'));origin=saved['origin']
            if not re.fullmatch(r'http://127\.0\.0\.1:\d{1,5}',origin):return None
            with urllib.request.urlopen(origin+'/api/instance',timeout=1) as response:data=json.load(response)
            if data.get('application')=='TC_JPT_GUI' and data.get('instance_id')==saved['instance_id']:
                version=data.get('version')
                return {'origin':origin,'version':version if isinstance(version,str) and re.fullmatch(r'\d+\.\d+\.\d+',version) else None}
        except Exception:return None
    def existing_origin(self):
        existing=self.existing_instance()
        return existing['origin'] if existing else None
    def release(self):
        if self.stream is None:return
        try:self.info.unlink(missing_ok=True)
        finally:
            if os.name=='nt':
                import msvcrt
                self.stream.seek(0);msvcrt.locking(self.stream.fileno(),msvcrt.LK_UNLCK,1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(),fcntl.LOCK_UN)
            self.stream.close();self.stream=None
