"""Versioned calibration workspace, imports, and explicit frozen-model activation."""
from dataclasses import replace
import json
import uuid

from .initial_calibration import (CalibrationDataset,CalibrationPoint,fit_dataset,import_dataset,
                                  dataset_csv,now)
from .calibration_common import ReferenceEvidence,finite


class InitialCalibrationSession:
    def load_initial_workspace(self):
        path=self.results_root/'initial_calibration_data.json'
        self.initial_dataset=(CalibrationDataset.from_dict(json.loads(path.read_text(encoding='utf-8')))
                              if path.is_file() else CalibrationDataset(uuid.uuid4().hex,0))
        self.initial_fit=None

    def initial_summary(self):
        ds=self.initial_dataset
        return {'dataset_id':ds.dataset_id,'revision':ds.revision,'point_count':len(ds.points),
                'fit_id':self.initial_fit.profile_id if self.initial_fit else None,
                'temperature_profile_id':self.temperature_calibration.profile_id}

    def initial_workspace(self):
        with self.lock:
            return {'dataset':self.initial_dataset.to_dict(),
                    'fit':self.initial_fit.to_dict(False) if self.initial_fit else None,
                    'temperature_profile':self.temperature_calibration.to_dict(False)}

    def _check_dataset_version(self,payload):
        ds=self.initial_dataset
        if payload.get('expected_dataset_id')!=ds.dataset_id or payload.get('expected_revision')!=ds.revision:
            raise ValueError('초기 보정 데이터가 변경됐습니다. 현재 데이터를 불러온 뒤 다시 시도하세요.')

    def update_initial_data(self,payload):
        if not isinstance(payload,dict):raise ValueError('초기 보정 요청 형식을 확인하세요.')
        action=payload.get('action')
        imported=import_dataset(payload.get('text'),payload.get('format')) if action=='import' else None
        with self.lock:
            self._check_dataset_version(payload)
            old=self.initial_dataset;points=list(old.points);dataset_id=old.dataset_id
            if action=='add_capture':
                capture=self.calibration_for("furnace")
                if not capture or payload.get('capture_id')!=capture.capture_id:
                    raise ValueError('4번 탭에서 전기로의 현재 기준온도에서 안정 구간을 먼저 측정하세요.')
                # Validate user data before selecting / writing acquisition evidence.
                reference=finite(payload.get('reference_c'))
                CalibrationPoint('validation',reference,(0,)*12,'','',payload.get('note',''))
                if len(points)>=500:raise ValueError('측정점은 최대 500개입니다.')
                selected=capture.select_reference()
                evidence=ReferenceEvidence.from_dict(selected['evidence'])
                point=CalibrationPoint(uuid.uuid4().hex,reference,tuple(selected['reference_raw_c']),
                                       selected['source'],now(),payload.get('note',''),evidence=evidence)
                points.append(point)
            elif action in ('add_manual','edit'):
                point=CalibrationPoint.from_dict({'reference_c':payload.get('reference_c'),
                      'raw_c':payload.get('raw_c'),'note':payload.get('note',''),'source':'수동 입력 · 안정 검증 없음'})
                if action=='add_manual':points.append(point)
                else:
                    index=next((i for i,p in enumerate(points) if p.point_id==payload.get('point_id')),None)
                    if index is None:raise ValueError('수정할 측정점을 찾을 수 없습니다.')
                    previous=points[index]
                    if point.raw_c==previous.raw_c:
                        point=replace(previous,reference_c=point.reference_c,note=point.note)
                    else:point=replace(point,point_id=previous.point_id)
                    points[index]=point
            elif action=='delete':
                points=[p for p in points if p.point_id!=payload.get('point_id')]
                if len(points)==len(old.points):raise ValueError('삭제할 측정점을 찾을 수 없습니다.')
            elif action=='clear':points=[]
            elif action=='import':
                points=list(imported.points);dataset_id=uuid.uuid4().hex
            else:raise ValueError('측정점 추가·수정·삭제·불러오기 동작을 확인하세요.')
            updated=CalibrationDataset(dataset_id,old.revision+1,tuple(points),now())
            self.results_root.mkdir(parents=True,exist_ok=True)
            path=self.results_root/'initial_calibration_data.json'
            temporary=path.with_name('.initial_calibration_'+uuid.uuid4().hex+'.tmp')
            try:
                temporary.write_text(json.dumps(updated.to_dict(),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
                temporary.replace(path)
            finally:temporary.unlink(missing_ok=True)
            self.initial_dataset=updated;self.initial_fit=None
            return self.initial_workspace()

    def fit_initial_data(self,payload):
        if not isinstance(payload,dict):raise ValueError('보정식 계산 요청을 확인하세요.')
        with self.lock:
            self._check_dataset_version(payload);dataset=self.initial_dataset
        fitted=fit_dataset(dataset)
        with self.lock:
            self._check_dataset_version(payload);self.initial_fit=fitted
            return self.initial_workspace()

    def activate_initial_calibration(self,payload):
        if not isinstance(payload,dict):raise ValueError('초기 보정 적용 요청을 확인하세요.')
        with self.lock:
            if self.running:raise ValueError('실험을 중지한 뒤 초기 보정식을 적용하세요. 다음 실험부터 적용됩니다.')
            old=self.temperature_calibration
            if payload.get('expected_profile_id')!=old.profile_id:
                raise ValueError('온도 보정 설정이 변경됐습니다. 현재 설정을 불러온 뒤 다시 시도하세요.')
            if payload.get('action')=='apply':
                self._check_dataset_version(payload)
                model=self.initial_fit
                if not model or payload.get('fit_id')!=model.profile_id:
                    raise ValueError('현재 측정점으로 보정식을 먼저 계산하세요.')
            elif payload.get('action')=='disable':model=None
            else:raise ValueError('초기 보정식 적용 또는 사용 해제를 선택하세요.')
            offsets=tuple(old.reference_c-(model.correct(v,i) if model else v)
                          for i,v in enumerate(old.reference_raw_c)) if old.reference_raw_c else (0.,)*12
            updated=replace(old,initial_calibration=model,offsets_c=offsets,
                            profile_id=uuid.uuid4().hex,created_at=now())
            self._persist_temperature_profile(updated)
            self.operation_revision+=1
            return self.initial_workspace()

    def export_initial_data(self,kind):
        with self.lock:
            dataset=self.initial_dataset;fitted=self.initial_fit
        if kind=='csv':return dataset_csv(dataset)
        if kind!='json':raise ValueError('JSON 또는 CSV를 선택하세요.')
        value=dataset.to_dict()
        value['fit_report']=fitted.to_dict(False) if fitted else None
        return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
