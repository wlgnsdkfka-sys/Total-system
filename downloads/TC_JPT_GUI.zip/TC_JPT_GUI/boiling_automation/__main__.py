"""Replay CSV temperatures or a synthetic experiment, without device access."""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
import json
import math
from pathlib import Path
import sys

from .core import CHANNELS, Config, Event, Reading, ReplayController


def read_csv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        required = {"t_s", *CHANNELS}
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError("Input CSV requires t_s,TC1,TC2,TC3,TC4,TC5,TC6,TC7,TC8")
        if len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise ValueError("Duplicate CSV headers are ambiguous")
        for row in reader:
            try:
                yield Reading(float(row["t_s"]), tuple(float(row[c]) for c in CHANNELS))
            except (ValueError, TypeError) as error:
                raise ValueError(f"Invalid temperature row at line {reader.line_num}") from error


def demo(critical_c: float):
    """650 simulated seconds; inject a raw TC8 threshold event at the end."""
    baseline = min(25.0, critical_c - 10)
    for second in range(651):
        temperatures = [baseline + i * 0.1 + 0.02 * math.sin(second / 5) for i in range(8)]
        if second == 650:
            temperatures[7] = critical_c + 1
        yield Reading(float(second), tuple(temperatures))


def _event_json(event: Event) -> str:
    payload = asdict(event)
    if event.kind == "observation_recorded":
        # The selected samples are written once, in their own CSV.
        payload["details"]["record"].pop("selected_samples")
    return json.dumps(payload, ensure_ascii=False, allow_nan=False)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="TC/JPT offline replay. No hardware is operated.")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--input", type=Path, help="CSV with elapsed t_s and TC1..TC8 in degrees C")
    source.add_argument("--demo", action="store_true", help="Use synthetic temperatures")
    parser.add_argument("--critical-temp", required=True, type=float, help="Trip at or above this temperature")
    parser.add_argument("--stability-range", type=float, help="User-defined peak-to-peak tolerance for early advancement")
    parser.add_argument("--max-power", type=int, default=100, help="Absolute simulated output cap, 0..100 percent")
    parser.add_argument("--output", required=True, type=Path, help="A new or empty result directory")
    args = parser.parse_args(argv)
    try:
        config = Config(args.critical_temp, allowed_range_c=args.stability_range,
                        max_power_percent=args.max_power)
        if args.output.exists() and (not args.output.is_dir() or any(args.output.iterdir())):
            raise ValueError("Output directory must be new or empty; existing results are preserved")
        args.output.mkdir(parents=True, exist_ok=True)
        controller = ReplayController(config)
        source_rows = demo(config.critical_c) if args.demo else read_csv(args.input)
        metadata = {"mode": "offline_replay", "hardware_connected": False,
                    "source": "synthetic_demo" if args.demo else str(args.input),
                    "config": asdict(config)}
        (args.output / "run.json").write_text(
            json.dumps(metadata, indent=2, allow_nan=False) + "\n", encoding="utf-8"
        )
        reason = None
        with (args.output / "events.jsonl").open("w", encoding="utf-8") as event_file, \
             (args.output / "stages.csv").open("w", encoding="utf-8", newline="") as stage_file, \
             (args.output / "selected_samples.csv").open("w", encoding="utf-8", newline="") as sample_file:
            stage_fields = ["power_percent", "recorded_at_s", "start_s", "end_s", "completion_reason",
                            "selected_worst_range_c", "current_worst_range_c", *[f"{c}_mean_c" for c in CHANNELS]]
            stages = csv.DictWriter(stage_file, fieldnames=stage_fields)
            samples = csv.DictWriter(sample_file, fieldnames=[
                "power_percent", "recorded_at_s", "t_s", "interpolated", *CHANNELS
            ])
            stages.writeheader()
            samples.writeheader()

            def write(events):
                nonlocal reason
                for event in events:
                    if event.kind == "observation_recorded":
                        record = event.details["record"]
                        stages.writerow({
                            "power_percent": record.power_percent,
                            "recorded_at_s": record.recorded_at_s,
                            "start_s": record.segment.start_s,
                            "end_s": record.segment.end_s,
                            "completion_reason": record.completion_reason,
                            "selected_worst_range_c": record.segment.worst_range_c,
                            "current_worst_range_c": record.current_range_c,
                            **{f"{c}_mean_c": stats.mean_c for c, stats in zip(CHANNELS, record.segment.channels)},
                        })
                        for point in record.selected_samples:
                            samples.writerow({
                                "power_percent": record.power_percent,
                                "recorded_at_s": record.recorded_at_s,
                                "t_s": point.t_s,
                                "interpolated": point.interpolated,
                                **dict(zip(CHANNELS, point.temperatures_c)),
                            })
                        stage_file.flush()
                        sample_file.flush()
                    if event.kind == "shutdown_required":
                        reason = event.details["reason"]
                    event_file.write(_event_json(event) + "\n")
                    event_file.flush()

            try:
                for reading in source_rows:
                    write(controller.process(reading))
                    if controller.terminal:
                        break
            except (OSError, ValueError, csv.Error):
                write(controller.abort("input_error"))
                raise
            finally:
                source_rows.close()
                write(controller.finish())
        result = {"mode": "offline_replay", "state": controller.state, "reason": reason,
                  "recorded_steps": len(controller.records), "output": str(args.output)}
        print(json.dumps(result, ensure_ascii=False))
        return 0 if reason in ("critical_temperature", "maximum_output_reached") else 2
    except (OSError, ValueError, csv.Error) as error:
        print(f"Offline replay failed: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
