"""Read-only NI TC input: high-resolution calibration and hardware-timed fast input."""
from __future__ import annotations
from dataclasses import dataclass
import importlib
import math
import re
import time

from .core import Reading
from .temperature_calibration import finite

DEFAULT_CHANNELS=tuple('cDAQ1Mod3/ai'+str(i) for i in [0,1,2,3,4,5,6,7,15,14,13,12])
TC_TYPES=('B','E','J','K','N','R','S','T')
STARTUP_DISCARD_S = 2.0


@dataclass(frozen=True)
class NISettings:
    physical_channels: tuple[str,...]
    thermocouple_types: tuple[str,...]
    minimum_c: float = 0
    maximum_c: float = 300

    def __post_init__(self):
        count=len(self.physical_channels)
        if count not in (8,12) or len(self.thermocouple_types)!=count:
            raise ValueError('NI 채널과 열전대 종류를 전기로 TC1~8 또는 실험 오프셋 TC1~12에 맞춰 지정하세요.')
        for c in self.physical_channels:
            if not isinstance(c,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}/ai[0-9]{1,3}',c):
                raise ValueError('NI 물리 채널을 장치명/ai번호 형식으로 입력하세요. 범위·목록 표기는 사용하지 않습니다.')
        if len(set(c.lower() for c in self.physical_channels))!=count:
            raise ValueError('NI 물리 채널은 중복될 수 없습니다.')
        if any(c not in TC_TYPES for c in self.thermocouple_types):
            raise ValueError(f'TC1~{count}의 열전대 종류를 실제 배선에 맞춰 선택하세요.')
        finite(self.minimum_c);finite(self.maximum_c)
        if not -270<=self.minimum_c<self.maximum_c<=1800:
            raise ValueError('NI 온도 범위는 -270~1800°C 안에서 최소 < 최대로 지정하세요.')

    @classmethod
    def from_payload(cls,payload,channel_count=12):
        if not isinstance(payload,dict):raise ValueError('NI 입력 설정을 확인하세요.')
        try:
            settings=cls(tuple(payload.get('physical_channels',())),tuple(payload.get('thermocouple_types',())),
                         payload.get('minimum_c',0),payload.get('maximum_c',300))
            if len(settings.physical_channels)!=channel_count:raise ValueError(f'이 측정은 TC1~{channel_count}의 {channel_count}채널 설정이 필요합니다.')
            return settings
        except TypeError as error:raise ValueError('NI 입력 설정을 확인하세요.') from error


def load_driver():
    try:
        return importlib.import_module('nidaqmx'),importlib.import_module('nidaqmx.constants')
    except Exception as error:
        raise ValueError('NI 입력에는 NI-DAQmx 드라이버와 Python nidaqmx가 필요합니다. 설치 안내를 확인하세요.') from error


def readings(settings: NISettings,cancel,*,mode='calibration',on_configured=None):
    """Only create thermocouple AI channels; never create or write DO/AO/CO tasks."""
    if mode not in ('calibration','experiment'):raise ValueError('NI 수집 모드를 확인하세요.')
    nidaqmx,constants=load_driver()
    origin=None;count=len(settings.physical_channels)
    adc_mode='HIGH_RESOLUTION' if mode=='calibration' else 'HIGH_SPEED'
    sample_rate=None;sample_index=0
    with nidaqmx.Task() as task:
        for i,(channel,tc_type) in enumerate(zip(settings.physical_channels,settings.thermocouple_types)):
            ai_channel=task.ai_channels.add_ai_thrmcpl_chan(channel,name_to_assign_to_channel=f'TC{i+1}',
                min_val=settings.minimum_c,max_val=settings.maximum_c,
                units=constants.TemperatureUnits.DEG_C,
                thermocouple_type=getattr(constants.ThermocoupleType,tc_type),
                cjc_source=constants.CJCSource.BUILT_IN)
            ai_channel.ai_adc_timing_mode=getattr(constants.ADCTimingMode,adc_mode)
        if cancel.is_set():
            return
        if mode=='experiment':
            maximum=finite(task.timing.samp_clk_max_rate)
            if maximum<.5:raise ValueError('NI 최대 수집 속도가 2초 이내 온도 감시에 부족합니다.')
            task.timing.cfg_samp_clk_timing(maximum,sample_mode=constants.AcquisitionType.CONTINUOUS,
                                           samps_per_chan=max(100,math.ceil(maximum*10)))
            task.control(constants.TaskMode.TASK_COMMIT)
            sample_rate=finite(task.timing.samp_clk_rate)
            if sample_rate<.5:raise ValueError('NI 실제 수집 속도가 2초 이내 온도 감시에 부족합니다.')
        if on_configured is not None:
            on_configured({'mode':mode,'adc_timing_mode':adc_mode,
                           'clock':'hardware_continuous' if mode=='experiment' else 'on_demand',
                           'sample_rate_hz_per_channel':sample_rate,
                           'target_interval_s':1 if mode=='calibration' else None,
                           'startup_discard_s':STARTUP_DISCARD_S if mode=='calibration' else 0,
                           'physical_channels':settings.physical_channels,
                           'thermocouple_types':settings.thermocouple_types,
                           'minimum_c':settings.minimum_c,'maximum_c':settings.maximum_c})
        if cancel.is_set():return
        task.start()
        discard_until = time.monotonic() + (STARTUP_DISCARD_S if mode=='calibration' else 0)
        first_sample = True
        while not cancel.is_set():
            before=time.monotonic()
            if mode=='experiment':
                queued=task.in_stream.avail_samp_per_chan
                if queued>math.ceil(sample_rate*2):
                    raise ValueError('NI 온도 버퍼가 2초 이상 지연됐습니다. 오래된 값으로 실험을 계속할 수 없습니다. '
                                     f'대기 {queued}샘플/채널 · 수집 {sample_rate:g}Hz/채널 · 추정 대기 {queued/sample_rate:.2f}초. '
                                     'PC의 계산·저장 처리 지연과 수집 속도를 확인하세요.')
                sample=task.read(number_of_samples_per_channel=1,timeout=2.0)
            else:
                sample=task.read(timeout=2.0)
            now=time.monotonic()
            if cancel.is_set():break
            # Keep the AI running during settling. Sleeping before the first read
            # would still let a distorted first conversion enter the reference.
            if mode=='calibration' and (first_sample or now < discard_until):
                first_sample = False
                if cancel.wait(max(0,1-(time.monotonic()-before))):break
                continue
            if not isinstance(sample,(tuple,list)) or len(sample)!=count:
                raise ValueError(f'NI 입력에서 TC1~{count}의 온도 {count}개를 받지 못했습니다.')
            flattened=[]
            for i,v in enumerate(sample):
                if isinstance(v,(tuple,list)):
                    if len(v)!=1:raise ValueError('NI 온도 샘플 형식이 올바르지 않습니다.')
                    v=v[0]
                try:
                    value=finite(v)
                except (ValueError,TypeError) as error:
                    raise ValueError(f'TC{i+1} ({settings.physical_channels[i]}) 원시온도가 유효한 숫자가 아닙니다.') from error
                if not settings.minimum_c<=value<=settings.maximum_c:
                    raise ValueError(f'TC{i+1} ({settings.physical_channels[i]}) 원시온도 {value:g}°C가 설정 범위 '
                                     f'{settings.minimum_c:g}~{settings.maximum_c:g}°C를 벗어났습니다. 배선·열전대 종류를 확인하세요.')
                flattened.append(value)
            if origin is None:origin=now
            t=sample_index/sample_rate if mode=='experiment' else now-origin
            yield Reading(t,tuple(flattened[:8]),bulk_temperatures_c=tuple(flattened[8:]))
            sample_index+=1
            if mode=='calibration' and cancel.wait(max(0,1-(time.monotonic()-before))):break
