"""Optional, read-only NI-DAQmx thermocouple input for calibration only."""
from __future__ import annotations
from dataclasses import dataclass
import importlib
import re
import time

from .core import Reading
from .temperature_calibration import finite

DEFAULT_CHANNELS=tuple('cDAQ1Mod3/ai'+str(i) for i in [0,1,2,3,4,5,6,7,15,14,13,12])
TC_TYPES=('B','E','J','K','N','R','S','T')


@dataclass(frozen=True)
class NISettings:
    physical_channels: tuple[str,...]
    thermocouple_types: tuple[str,...]
    minimum_c: float = 0
    maximum_c: float = 300

    def __post_init__(self):
        count=len(self.physical_channels)
        if count not in (8,12) or len(self.thermocouple_types)!=count:
            raise ValueError('NI 채널과 열전대 종류를 전기로 TC1~8 또는 실험 오프셋 TC1~12에 맞춰 지정하세요.')
        for c in self.physical_channels:
            if not isinstance(c,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}/ai[0-9]{1,3}',c):
                raise ValueError('NI 물리 채널을 장치명/ai번호 형식으로 입력하세요. 범위·목록 표기는 사용하지 않습니다.')
        if len(set(c.lower() for c in self.physical_channels))!=count:
            raise ValueError('NI 물리 채널은 중복될 수 없습니다.')
        if any(c not in TC_TYPES for c in self.thermocouple_types):
            raise ValueError(f'TC1~{count}의 열전대 종류를 실제 배선에 맞춰 선택하세요.')
        finite(self.minimum_c);finite(self.maximum_c)
        if not -270<=self.minimum_c<self.maximum_c<=1800:
            raise ValueError('NI 온도 범위는 -270~1800°C 안에서 최소 < 최대로 지정하세요.')

    @classmethod
    def from_payload(cls,payload,channel_count=12):
        if not isinstance(payload,dict):raise ValueError('NI 입력 설정을 확인하세요.')
        try:
            settings=cls(tuple(payload.get('physical_channels',())),tuple(payload.get('thermocouple_types',())),
                         payload.get('minimum_c',0),payload.get('maximum_c',300))
            if len(settings.physical_channels)!=channel_count:raise ValueError(f'이 측정은 TC1~{channel_count}의 {channel_count}채널 설정이 필요합니다.')
            return settings
        except TypeError as error:raise ValueError('NI 입력 설정을 확인하세요.') from error


def load_driver():
    try:
        return importlib.import_module('nidaqmx'),importlib.import_module('nidaqmx.constants')
    except Exception as error:
        raise ValueError('NI 입력에는 NI-DAQmx 드라이버와 Python nidaqmx가 필요합니다. 설치 안내를 확인하세요.') from error


def readings(settings: NISettings,cancel):
    """Only create thermocouple AI channels; never create or write DO/AO/CO tasks."""
    nidaqmx,constants=load_driver()
    origin=None;count=len(settings.physical_channels)
    with nidaqmx.Task() as task:
        for i,(channel,tc_type) in enumerate(zip(settings.physical_channels,settings.thermocouple_types)):
            task.ai_channels.add_ai_thrmcpl_chan(channel,name_to_assign_to_channel=f'TC{i+1}',
                min_val=settings.minimum_c,max_val=settings.maximum_c,
                units=constants.TemperatureUnits.DEG_C,
                thermocouple_type=getattr(constants.ThermocoupleType,tc_type),
                cjc_source=constants.CJCSource.BUILT_IN)
        if cancel.is_set():
            return
        task.start()
        while not cancel.is_set():
            before=time.monotonic()
            sample=task.read(timeout=2.0)
            now=time.monotonic()
            if cancel.is_set():break
            if not isinstance(sample,(tuple,list)) or len(sample)!=count:
                raise ValueError(f'NI 입력에서 TC1~{count}의 온도 {count}개를 받지 못했습니다.')
            flattened=[]
            for v in sample:
                if isinstance(v,(tuple,list)):
                    if len(v)!=1:raise ValueError('NI 온도 샘플 형식이 올바르지 않습니다.')
                    v=v[0]
                value=finite(v)
                if not settings.minimum_c<=value<=settings.maximum_c:
                    raise ValueError("NI 원시온도가 설정 범위를 벗어났습니다. 배선·열전대 종류를 확인하세요.")
                flattened.append(value)
            if origin is None:origin=now
            yield Reading(now-origin,tuple(flattened[:8]),bulk_temperatures_c=tuple(flattened[8:]))
            if cancel.wait(max(0,1-(time.monotonic()-before))):break
