"""NI high-speed input uses the existing calibrated monitoring and durable logs."""
import csv
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from boiling_automation.core import Reading
from boiling_automation.gui import GuiSession
from boiling_automation.ni_temperature import DEFAULT_CHANNELS
from boiling_automation.temperature_calibration import TemperatureCalibration


SETTINGS={'physical_channels':DEFAULT_CHANNELS,'thermocouple_types':['K']*12,'minimum_c':0,'maximum_c':300}


class NIExperimentTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.s=GuiSession(Path(self.tmp.name));self.closed=[];self.modes=[]
    def tearDown(self):
        self.s.stop()
        if self.s.worker and self.s.worker.is_alive():self.s.worker.join(5)
        self.tmp.cleanup()
    def run_input(self,points,critical=200,fail=None):
        def source(settings,cancel,*,mode,on_configured):
            self.modes.append(mode)
            try:
                on_configured({**SETTINGS,'mode':mode,'adc_timing_mode':'HIGH_SPEED',
                    'sample_rate_hz_per_channel':5.,'clock':'hardware_continuous','startup_discard_s':0})
                for point in points:
                    if cancel.is_set():break
                    yield point
                if fail:raise fail
            finally:self.closed.append(True)
        with patch('boiling_automation.gui.load_driver'),patch('boiling_automation.gui.ni_readings',side_effect=source):
            self.s.start({'source':'ni','ni_settings':SETTINGS,'speed':1,'critical_c':critical,'allowed_std_c':.1,'max_power_percent':0})
            self.s.worker.join(15)
            self.assertFalse(self.s.worker.is_alive())
        return self.s.snapshot()
    def test_fast_samples_all_reach_calibration_separate_csvs_and_stage_selection(self):
        self.s.temperature_calibration=TemperatureCalibration(True,100,(99.,)*12,(1.,)*12,'saved-offset')
        points=(Reading(i/5,(99.,)*8,bulk_temperatures_c=(99.,)*4) for i in range(451))
        state=self.run_input(points)
        self.assertEqual(state['state'],'completed');self.assertEqual(state['measurement_sample_count'],451)
        self.assertEqual(state['communications']['tc']['received_frames'],451)
        self.assertIsNotNone(state['communications']['tc']['last_received_at'])
        self.assertEqual(self.modes,['experiment']);self.assertTrue(self.closed)
        records={basis:list(csv.DictReader(io.StringIO(self.s.export_measurements(basis)[0].decode()))) for basis in ('raw','tab4','tab3')}
        self.assertTrue(all(len(rows)==451 for rows in records.values()))
        self.assertEqual(records['raw'][0]['TC1'],'99.0');self.assertEqual(records['tab3'][0]['TC1'],'100.0')
        for i in range(451):
            self.assertEqual(records['raw'][i]['t_s'],records['tab3'][i]['t_s'])
            self.assertEqual(records['raw'][i]['sample_id'],records['tab4'][i]['sample_id'])
        meta=json.loads((self.s.writer.directory/'run.json').read_text())
        self.assertEqual(meta['temperature_input']['sample_rate_hz_per_channel'],5.)
        self.assertEqual(meta['temperature_input']['adc_timing_mode'],'HIGH_SPEED')
        self.assertFalse(meta['laser_control_connected']);self.assertFalse(meta['shutter_control_connected'])
        self.assertEqual(len(state['records']),1)
    def test_every_fast_sample_is_checked_for_critical_temperature(self):
        state=self.run_input([Reading(0,(25.,)*8,bulk_temperatures_c=(25.,)*4),Reading(.2,(120.,)+(25.,)*7,bulk_temperatures_c=(25.,)*4)],critical=120)
        self.assertEqual(state['state'],'tripped');self.assertEqual(state['measurement_sample_count'],2)
        self.assertEqual(state['power_index_percent'],-1)
        self.assertTrue(self.closed)
    def test_invalid_ni_settings_and_accelerated_live_input_do_not_create_a_run(self):
        for extra in ({'speed':60},{'ni_settings':None}):
            with self.assertRaises(ValueError):self.s.start({'source':'ni','ni_settings':SETTINGS,'speed':1,'critical_c':120,**extra})
        self.assertIsNone(self.s.writer)
    def test_driver_failure_after_a_sample_preserves_it_and_stops(self):
        state=self.run_input([Reading(0,(25.,)*8,bulk_temperatures_c=(25.,)*4)],fail=RuntimeError('input disconnected'))
        self.assertEqual(state['measurement_sample_count'],1);self.assertIn('input disconnected',state['error'])
        self.assertFalse(state['running']);self.assertTrue(self.closed)
    def test_stop_releases_input_and_prevents_calibration_task_overlap(self):
        ready=threading.Event()
        def source(settings,cancel,*,mode,on_configured):
            try:
                on_configured({**SETTINGS,'mode':mode,'sample_rate_hz_per_channel':5.})
                yield Reading(0,(25.,)*8,bulk_temperatures_c=(25.,)*4)
                ready.set();cancel.wait(5)
            finally:self.closed.append(True)
        with patch('boiling_automation.gui.load_driver'),patch('boiling_automation.gui.ni_readings',side_effect=source):
            self.s.start({'source':'ni','ni_settings':SETTINGS,'speed':1,'critical_c':120})
            self.assertTrue(ready.wait(3))
            self.assertTrue(self.s.snapshot()['experiment_temperature_input_connected'])
            self.assertTrue(self.s.snapshot()['temperature_input_hardware_connected'])
            with self.assertRaises(ValueError):self.s.start_calibration_capture({'source':'demo'})
            self.s.stop();self.s.worker.join(3)
        self.assertTrue(self.closed);self.assertFalse(self.s.worker.is_alive())
    def test_acquisition_metadata_storage_failure_stops_before_reading(self):
        with patch('boiling_automation.gui.ResultWriter.set_temperature_input',side_effect=OSError('sampling metadata disk full')):
            state=self.run_input([Reading(0,(25.,)*8,bulk_temperatures_c=(25.,)*4)])
        self.assertEqual(state['measurement_sample_count'],0);self.assertIn('disk full',state['error'])
        self.assertEqual(state['power_index_percent'],-1);self.assertTrue(self.closed)
