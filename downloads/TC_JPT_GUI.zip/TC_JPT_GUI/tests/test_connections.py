"""Restart restoration, no waveform replay, real I/O indicators, and probe isolation."""
import importlib
import json
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from boiling_automation.connections import ConnectionMonitor
from boiling_automation.manual_controls import ManualControls,ShutterSettings
from boiling_automation.ni_temperature import DEFAULT_CHANNELS
from test_manual_controls import FakeTask


INVENTORY={'devices':[
 {'name':'myDAQ1','model':'NI myDAQ','simulated':False,'counter_channels':['myDAQ1/ctr0'],'analog_input_channels':['myDAQ1/ai0','myDAQ1/ai1']},
 {'name':'cDAQ1Mod3','model':'NI 9213','simulated':False,'counter_channels':[],'analog_input_channels':[f'cDAQ1Mod3/ai{i}' for i in range(16)]},
]}


class ConnectionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.manual=ManualControls(Path(self.temp.name));self.tasks=[]
        self.inventory=INVENTORY;self.monitor=ConnectionMonitor(self.manual,lambda:self.inventory)
        self.tc={'physical_channels':DEFAULT_CHANNELS,'received_frames':0,'last_received_at':None,'last_received_mono':None,'error':None}
        constants=SimpleNamespace(TimeUnits=SimpleNamespace(SECONDS='seconds'),Level=SimpleNamespace(LOW='low'),AcquisitionType=SimpleNamespace(CONTINUOUS='continuous'))
        actual_import=importlib.import_module
        def task():
            t=FakeTask();self.tasks.append(t);return t
        def load(name):
            if name=='nidaqmx':return SimpleNamespace(Task=task)
            if name=='nidaqmx.constants':return constants
            return actual_import(name)
        p=patch('boiling_automation.manual_controls.importlib.import_module',side_effect=load);p.start();self.addCleanup(p.stop)
    def tearDown(self):
        self.monitor.stop();self.manual.wait_for_close();self.manual.disconnect();self.temp.cleanup()
    def status(self,**kwargs):return self.monitor.status(self.tc,**kwargs)
    def test_detected_mydaq_is_restored_without_creating_any_output_task(self):
        self.monitor.refresh();sh=self.manual.snapshot()['shutter']
        self.assertTrue(sh['connected']);self.assertEqual(sh['settings']['counter_channel'],'myDAQ1/ctr0')
        self.assertEqual(sh['connection_origin'],'restored');self.assertFalse(sh['pwm_active'])
        self.assertIsNone(sh['last_command']);self.assertEqual(sh['tx_count'],0);self.assertEqual(self.tasks,[])
        self.assertEqual(self.status()['shutter']['state'],'ready')
        self.assertEqual(json.loads((self.manual.root/'manual_control_settings.json').read_text())['shutter']['counter_channel'],'myDAQ1/ctr0')
    def test_saved_channel_and_terminal_survive_new_program_instance(self):
        self.manual.settings=ShutterSettings('myDAQ1/ctr0','/myDAQ1/PFI3');self.manual._save()
        restored=ManualControls(self.manual.root);monitor=ConnectionMonitor(restored,lambda:INVENTORY);monitor.refresh()
        try:
            sh=restored.snapshot()['shutter'];self.assertTrue(sh['connected'])
            self.assertEqual(sh['settings']['output_terminal'],'/myDAQ1/PFI3');self.assertEqual(self.tasks,[])
        finally:monitor.stop();restored.disconnect()
    def test_missing_or_simulated_mydaq_is_not_reported_connected(self):
        self.inventory={'devices':[]};self.monitor.refresh()
        self.assertFalse(self.manual.snapshot()['shutter']['connected']);self.assertEqual(self.status()['shutter']['state'],'disconnected')
        self.inventory={'devices':[{**INVENTORY['devices'][0],'simulated':True}]};self.monitor.refresh()
        self.assertFalse(self.manual.snapshot()['shutter']['connected']);self.assertEqual(self.tasks,[])
    def test_saved_other_channel_is_not_silently_replaced_with_mydaq(self):
        self.manual.settings=ShutterSettings('Dev2/ctr1');self.manual._save();self.monitor.refresh()
        self.assertFalse(self.manual.snapshot()['shutter']['connected'])
        self.assertEqual(self.manual.settings.counter_channel,'Dev2/ctr1');self.assertEqual(self.tasks,[])
    def test_explicit_disconnect_suppresses_automatic_reconnection_until_restart(self):
        self.monitor.refresh();self.manual.disconnect();self.monitor.refresh()
        self.assertFalse(self.manual.snapshot()['shutter']['configured'])
        self.assertEqual(self.status()['shutter']['label'],'장치 검출 · 수동 연결 해제')
    def test_disconnect_during_restore_does_not_get_overridden(self):
        entered=threading.Event();release=threading.Event();original=self.manual._record
        def slow(action,details):
            if action=='shutter_restore_check':entered.set();release.wait(3)
            return original(action,details)
        with patch.object(self.manual,'_record',side_effect=slow):
            worker=threading.Thread(target=self.monitor.refresh);worker.start();self.assertTrue(entered.wait(1))
            self.manual.disconnect();release.set();worker.join(3)
        self.assertFalse(self.manual.snapshot()['shutter']['configured']);self.assertEqual(self.tasks,[])
    def test_unplug_and_replug_restore_only_connection_not_the_previous_open_waveform(self):
        self.monitor.refresh();self.manual.open();self.assertEqual(len(self.tasks),1)
        self.assertEqual(self.status()['shutter']['state'],'active')
        self.inventory={'devices':[]};self.monitor.refresh()
        self.assertTrue(self.tasks[0].closed);self.assertFalse(self.manual.snapshot()['shutter']['connected'])
        self.inventory=INVENTORY;self.monitor.refresh();sh=self.manual.snapshot()['shutter']
        self.assertTrue(sh['connected']);self.assertFalse(sh['pwm_active']);self.assertIsNone(sh['last_command'])
        self.assertEqual(len(self.tasks),1);self.assertEqual(self.status()['shutter']['state'],'ready')
    def test_stopped_native_task_is_detected_without_restarting_output(self):
        self.monitor.refresh();self.manual.open();self.tasks[0].closed=True
        self.monitor.refresh();self.assertEqual(self.status()['shutter']['state'],'error')
        self.monitor.refresh();self.assertTrue(self.manual.snapshot()['shutter']['connected'])
        self.assertFalse(self.manual.snapshot()['shutter']['pwm_active']);self.assertEqual(len(self.tasks),1)
    def test_failed_capability_query_does_not_drop_a_running_owned_waveform(self):
        self.monitor.refresh();self.manual.open()
        self.inventory={'devices':[{**INVENTORY['devices'][0],'counter_channels':[],'error':'temporary capability query failure'},INVENTORY['devices'][1]]}
        self.monitor.refresh()
        self.assertFalse(self.tasks[0].closed);self.assertTrue(self.manual.snapshot()['shutter']['pwm_active'])
        self.assertEqual(self.status()['shutter']['state'],'warning')
    def test_tc_blinks_only_for_fresh_actual_input_not_virtual_or_stopped_data(self):
        self.monitor.refresh();self.assertEqual(self.status()['tc']['state'],'ready')
        self.assertEqual(self.status(active_ni=True)['tc']['state'],'checking')
        self.tc.update(received_frames=1,last_received_at='2026-10-29T12:00:00+09:00',last_received_mono=time.monotonic())
        self.assertEqual(self.status(active_ni=True)['tc']['state'],'active')
        self.assertEqual(self.status(active_ni=False,input_mode='CSV')['tc']['state'],'ready')
        self.tc['last_received_mono']-=3
        self.assertEqual(self.status(active_ni=True)['tc']['state'],'error')
    def test_unsupported_laser_does_not_show_fake_communication_from_saved_power(self):
        self.monitor.refresh();self.manual.save_laser({'power_percent':100})
        laser=self.status()['laser'];self.assertEqual(laser['state'],'unimplemented');self.assertEqual(laser['transmitted_commands'],0)
        self.assertIsNone(laser['last_transmitted_at'])
    def test_probe_failure_is_visible_and_does_not_start_any_output(self):
        self.monitor.probe=lambda:(_ for _ in ()).throw(RuntimeError('DAQ driver missing'));self.monitor.refresh()
        status=self.status();self.assertEqual(status['shutter']['state'],'error');self.assertIn('DAQ driver missing',status['probe_error']);self.assertEqual(self.tasks,[])
    def test_slow_probe_does_not_block_status_or_other_threads(self):
        entered=threading.Event();release=threading.Event()
        def slow():entered.set();release.wait(3);return INVENTORY
        self.monitor.probe=slow;worker=threading.Thread(target=self.monitor.refresh);worker.start();self.assertTrue(entered.wait(1))
        result=[];reader=threading.Thread(target=lambda:result.append(self.status()));reader.start();reader.join(.5)
        try:self.assertFalse(reader.is_alive());self.assertTrue(result[0]['checking'])
        finally:release.set();worker.join(3);reader.join(1)
    def test_stopping_monitor_prevents_late_restoration(self):
        entered=threading.Event();release=threading.Event()
        def slow():entered.set();release.wait(3);return INVENTORY
        self.monitor.probe=slow;self.monitor.start();self.assertTrue(entered.wait(1))
        self.monitor.stop_event.set();self.monitor.refresh_event.set();release.set();self.monitor.stop()
        self.assertFalse(self.manual.snapshot()['shutter']['connected']);self.assertEqual(self.tasks,[])
    def test_resource_reservation_error_keeps_code_and_restart_guidance(self):
        self.monitor.refresh();error=RuntimeError('counter reserved');error.error_code=-50103
        with patch.object(FakeTask,'start',side_effect=error):
            with self.assertRaises(ValueError):self.manual.open()
        status=self.status()['shutter'];self.assertEqual(status['state'],'error');self.assertEqual(status['error_code'],-50103)
        self.assertIn('이전 프로그램',status['error_hint'])
    def test_actual_calibration_frames_are_counted_separately_from_simulation(self):
        from boiling_automation.gui import GuiSession
        from boiling_automation.core import Reading
        session=GuiSession(self.manual.root/'tc-session')
        settings={'physical_channels':DEFAULT_CHANNELS,'thermocouple_types':['K']*12}
        def rows(*args,**kwargs):
            for i in range(181):yield Reading(float(i),(100.,)*8,bulk_temperatures_c=(100.,)*4)
        try:
            with patch('boiling_automation.gui.load_driver'),patch('boiling_automation.gui.ni_readings',side_effect=rows):
                session.start_calibration_capture({'source':'ni','ni_settings':settings,'speed':1})
                session.capture_worker.join(3)
            self.assertFalse(session.capture_worker.is_alive())
            self.assertEqual(session.snapshot()['communications']['tc']['received_frames'],181)
            self.assertEqual(self.tasks,[])
        finally:session.stop()
    def test_communications_http_refresh_requires_token_and_starts_no_output(self):
        import http.client
        from boiling_automation.gui import GuiServer
        with patch('boiling_automation.gui.discover_outputs',return_value=INVENTORY):
            server=GuiServer(('127.0.0.1',0),self.manual.root/'http-server');worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
            def request(method,path,token=None):
                connection=http.client.HTTPConnection('127.0.0.1',server.server_address[1],timeout=3)
                try:
                    headers={'Content-Type':'application/json'}
                    if token:headers['X-App-Token']=token
                    connection.request(method,path,'{}' if method=='POST' else None,headers)
                    response=connection.getresponse();return response.status,response.read()
                finally:connection.close()
            try:
                self.assertEqual(request('GET','/communications.js')[0],200)
                self.assertEqual(request('GET','/api/communications')[0],200)
                self.assertEqual(request('POST','/api/communications/refresh')[0],403)
                self.assertEqual(request('POST','/api/communications/refresh',server.token)[0],200)
                self.assertEqual(self.tasks,[])
            finally:
                server.session.connections.stop();server.session.stop();server.session.manual_controls.disconnect()
                server.shutdown();server.server_close();worker.join(3)
