import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from boiling_automation.instance import GuiInstance


class InstanceTests(unittest.TestCase):
    def test_second_launch_cannot_acquire_the_active_session(self):
        with tempfile.TemporaryDirectory() as folder:
            a=GuiInstance(folder);b=GuiInstance(folder)
            try:
                self.assertTrue(a.acquire());self.assertFalse(b.acquire())
                a.release();self.assertTrue(b.acquire())
            finally:a.release();b.release()
    def test_existing_instance_is_verified_before_opening_its_page(self):
        import io
        with tempfile.TemporaryDirectory() as folder:
            a=GuiInstance(folder);a.acquire();a.publish('http://127.0.0.1:12345','nonce')
            try:
                with patch('boiling_automation.instance.urllib.request.urlopen',return_value=io.BytesIO(json.dumps({'application':'TC_JPT_GUI','instance_id':'nonce'}).encode())):
                    self.assertEqual(GuiInstance(folder).existing_origin(),'http://127.0.0.1:12345')
                with patch('boiling_automation.instance.urllib.request.urlopen',return_value=io.BytesIO(b'{"application":"other"}')):
                    self.assertIsNone(GuiInstance(folder).existing_origin())
            finally:a.release()
    def test_external_metadata_url_is_never_opened(self):
        with tempfile.TemporaryDirectory() as folder:
            instance=GuiInstance(folder);instance.info.write_text('{"origin":"https://example.com","instance_id":"x"}')
            with patch('boiling_automation.instance.urllib.request.urlopen') as request:
                self.assertIsNone(instance.existing_origin());request.assert_not_called()
    def test_failed_second_launch_cannot_remove_the_owners_metadata(self):
        with tempfile.TemporaryDirectory() as folder:
            a=GuiInstance(folder);b=GuiInstance(folder);a.acquire();a.publish('http://127.0.0.1:12345','n')
            try:
                self.assertFalse(b.acquire());b.release();self.assertTrue(a.info.exists())
            finally:a.release()
    def test_main_reuses_live_program_and_clean_exit_releases_the_lock(self):
        import threading,time,urllib.request
        from boiling_automation.gui import main
        with tempfile.TemporaryDirectory() as folder:
            lease=GuiInstance(folder);results=Path(folder)/'results';done=[]
            with patch('boiling_automation.gui.GuiInstance',side_effect=lambda:GuiInstance(folder)):
                worker=threading.Thread(target=lambda:done.append(main(['--no-browser','--results',str(results)])),daemon=True);worker.start()
                deadline=time.monotonic()+3
                while not lease.info.exists() and time.monotonic()<deadline:threading.Event().wait(.01)
                origin=lease.existing_origin();self.assertIsNotNone(origin)
                try:
                    self.assertEqual(main(['--no-browser','--results',str(Path(folder)/'other')]),0)
                    self.assertFalse((Path(folder)/'other').exists())
                    with urllib.request.urlopen(origin+'/api/bootstrap',timeout=2) as response:token=json.load(response)['token']
                    request=urllib.request.Request(origin+'/api/shutdown',data=b'{}',headers={'Content-Type':'application/json','X-App-Token':token})
                    with urllib.request.urlopen(request,timeout=3) as response:self.assertEqual(response.status,200)
                finally:worker.join(5)
                self.assertFalse(worker.is_alive());self.assertEqual(done,[0]);self.assertFalse(lease.info.exists())
                self.assertTrue(lease.acquire());lease.release()
