import csv
import http.client
import io
import json
from pathlib import Path
import statistics
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile

from boiling_automation.core import Config, Reading, ReplayController, _interval
from boiling_automation.gui import GuiServer, GuiSession, csv_readings
from boiling_automation.temperature_calibration import TemperatureCalibration


def table_csv(seconds=90,values=None):
    text='t_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n'
    return text+'\n'.join(str(t)+','+','.join(str(v) for v in (values(t) if values else [99+i*.1 for i in range(12)])) for t in range(seconds+1))


def profile(raw=None):
    raw=tuple(raw or [99+i*.1 for i in range(12)])
    return TemperatureCalibration(True,100,raw,tuple(100-v for v in raw),'test-profile')


class CalibrationMathTests(unittest.TestCase):
    def test_all_twelve_boiling_references_map_to_one_hundred(self):
        p=profile();raw=Reading(0,p.reference_raw_c[:8],bulk_temperatures_c=p.reference_raw_c[8:])
        result=p.apply(raw)
        self.assertEqual((*result.temperatures_c,*result.bulk_temperatures_c),(100,)*12)
        self.assertEqual((*result.raw_temperatures_c,*result.raw_bulk_temperatures_c),p.reference_raw_c)

    def test_later_temperatures_change_and_standard_deviation_is_preserved(self):
        p=profile();corrected=[];original=[]
        for t in range(31):
            values=tuple(v+t*.25 for v in p.reference_raw_c)
            r=Reading(t,values[:8],bulk_temperatures_c=values[8:]);out=p.apply(r)
            self.assertEqual(out.temperatures_c[0],100+t*.25)
            corrected.append(out.temperatures_c[0]);original.append(r.temperatures_c[0])
        self.assertAlmostEqual(statistics.stdev(original),statistics.stdev(corrected))

    def test_no_calibration_is_identity_and_missing_bulk_stays_missing(self):
        raw=Reading(0,(25,)*8,bulk_temperatures_c=(None,24,None,25))
        self.assertEqual(TemperatureCalibration().apply(raw).temperatures_c,(25,)*8)
        self.assertEqual(profile().apply(raw).bulk_temperatures_c[0],None)
        self.assertEqual(profile().apply(Reading(0,(25,)*8)).bulk_temperatures_c,())

    def test_raw_values_are_interpolated_with_corrected_samples(self):
        p=profile();points=[p.apply(Reading(t,(99+t,)*8,bulk_temperatures_c=(99+t,)*4)) for t in (0,2)]
        sample=_interval(points,.5,1.5)[0]
        self.assertTrue(sample.interpolated)
        self.assertEqual(sample.raw_temperatures_c,(99.5,)*8)
        self.assertAlmostEqual(sample.temperatures_c[0],100.5)
        self.assertEqual(sample.raw_bulk_temperatures_c,(99.5,)*4)

    def test_invalid_profiles_cannot_be_used(self):
        for change in ({'offsets_c':(0,)*11},{'reference_raw_c':(99,)*12,'offsets_c':(9,)*12},
                       {'reference_c':float('nan')},{'enabled':True},
                       {'reference_raw_c':(99,)*11},{'offsets_c':(True,)*12}):
            with self.subTest(change=change),self.assertRaises(ValueError):TemperatureCalibration(**change)


class LaserOffIndexTests(unittest.TestCase):
    def test_idle_on_zero_increase_and_stop_have_distinct_indices(self):
        c=ReplayController(Config(1000,allowed_std_c=.1))
        self.assertEqual(c.power_index_percent,-1)
        first=c.process(Reading(0,(25,)*8))
        self.assertEqual(c.power_index_percent,0)
        self.assertEqual(first[0].details['laser_emission_assumed'],'on')
        for t in range(1,91):c.process(Reading(t,(25,)*8))
        self.assertEqual(c.power_index_percent,1)
        event=c.abort('user_stop')[-1]
        self.assertEqual(c.power_index_percent,-1)
        self.assertEqual(event.details['power_index_percent'],-1)
        self.assertEqual(event.details['previous_power_percent'],1)
        self.assertEqual(event.details['laser_emission_assumed'],'off')
        self.assertEqual(c.records[0].power_percent,0)

    def test_critical_and_completed_states_use_minus_one(self):
        for critical in (25,100):
            c=ReplayController(Config(critical,allowed_std_c=.1,max_power_percent=0))
            for t in range(91):c.process(Reading(t,(25,)*8))
            self.assertTrue(c.terminal);self.assertEqual(c.power_index_percent,-1)


class CalibrationSessionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.folder=Path(self.temp.name)
        self.session=GuiSession(self.folder)
    def tearDown(self):
        self.session.stop()
        if self.session.worker:self.session.worker.join(5)
        self.temp.cleanup()
    def save(self,**extra):
        return self.session.save_temperature_calibration({'action':'apply','reference_c':100,
              'reference_raw_c':[99+i*.1 for i in range(12)],
              'expected_profile_id':self.session.temperature_calibration.profile_id,**extra})
    def run_csv(self,**extra):
        self.session.start({'source':'csv','csv_text':table_csv(),'critical_c':1000,
                            'allowed_std_c':.1,'speed':300,'max_power_percent':0,**extra})
        self.session.worker.join(5);self.assertFalse(self.session.worker.is_alive())
        return self.session.snapshot()

    def test_profile_persists_and_initial_state_is_off(self):
        saved=self.save()
        restored=GuiSession(self.folder)
        self.assertEqual(restored.temperature_calibration.to_dict(),saved)
        self.assertEqual(restored.snapshot()['power_index_percent'],-1)

    def test_statistics_bulk_exports_and_curve_use_corrected_temperatures(self):
        saved=self.save();s=self.run_csv()
        self.assertEqual(s['latest']['temperatures_c'],(100,)*8)
        self.assertEqual(s['latest']['bulk_temperatures_c'],(100,)*4)
        self.assertEqual(s['records'][0]['segment']['channels'][0]['mean_c'],100)
        curve=self.session.curve_from_records()
        self.assertAlmostEqual(curve['rows'][0]['surface_temp_c'],100)
        self.assertAlmostEqual(curve['rows'][0]['heat_flux'],0)
        self.assertEqual(s['power_percent'],-1)
        with zipfile.ZipFile(io.BytesIO(self.session.export()[0])) as z:
            metadata=json.loads(z.read('run.json'))
            self.assertEqual(metadata['temperature_calibration']['profile_id'],saved['profile_id'])
            self.assertEqual(metadata['power_index_percent']['off'],-1)
            rows=list(csv.DictReader(io.StringIO(z.read('selected_samples.csv').decode())))
            self.assertEqual(float(rows[0]['TC1']),100)
            self.assertEqual(float(rows[0]['TC1_raw_c']),99)
            self.assertEqual(float(rows[0]['TC12_raw_c']),100.1)
            self.assertEqual(float(rows[0]['TC12']),100)
            # Export/replay picks the raw columns, avoiding double correction.
            raw=list(csv_readings(z.read('selected_samples.csv').decode()))
            self.assertEqual(raw[0].temperatures_c[0],99)
            self.assertEqual(self.session.temperature_calibration.apply(raw[0]).temperatures_c[0],100)

    def test_calibrated_threshold_trips_before_first_stage_or_increase(self):
        self.save();s=self.run_csv(critical_c=100)
        self.assertEqual(s['reason'],'critical_temperature');self.assertEqual(s['records'],[])
        self.assertEqual(s['power_index_percent'],-1)
        self.assertEqual(s['events'][-1]['details']['channels'],['TC'+str(i) for i in range(1,9)])
        self.assertEqual(s['events'][-1]['details']['raw_temperatures_c'][0],99)

    def test_profile_changes_never_rewrite_completed_run(self):
        saved=self.save();s=self.run_csv();record=s['records'][0]
        self.save(action='disable')
        self.assertEqual(self.session.snapshot()['records'][0],record)
        self.assertEqual(self.session.run_temperature_calibration.profile_id,saved['profile_id'])
        next_run=self.run_csv()
        self.assertEqual(next_run['latest']['temperatures_c'][0],99)

    def test_changes_during_run_are_rejected_and_stale_profile_is_rejected(self):
        with patch.object(threading.Thread,'start'):
            self.session.start({'critical_c':1000})
        self.session.worker=None
        for action in ('apply','disable','reset'):
            with self.assertRaises(ValueError):self.save(action=action)
        self.session.stop()
        self.save()
        with self.assertRaises(ValueError):self.save(expected_profile_id='uncalibrated')

    def test_invalid_reference_does_not_replace_saved_profile(self):
        saved=self.save()
        for value in ([99]*11,[99]*11+[None],[99]*11+[True],[99]*11+[float('nan')]):
            with self.assertRaises(ValueError):self.save(reference_raw_c=value)
            self.assertEqual(self.session.temperature_calibration.to_dict(),saved)

    def test_last_thirty_second_csv_mean_uses_all_twelve_raw_channels(self):
        csv_text=table_csv(40,lambda t:[98+t*.1+i*.01 for i in range(12)])
        preview=self.session.preview_temperature_calibration({'source':'csv','csv_text':csv_text})
        self.assertEqual((preview['start_s'],preview['end_s'],preview['sample_count']),(10,40,31))
        self.assertAlmostEqual(preview['reference_raw_c'][0],100.5)
        self.assertAlmostEqual(preview['reference_raw_c'][11],100.61)
        self.assertEqual(len(preview['std_c']),12)

    def test_partial_reference_reports_duration_and_missing_bulk_is_rejected(self):
        p=self.session.preview_temperature_calibration({'source':'csv','csv_text':table_csv(5)})
        self.assertEqual(p['coverage_s'],5)
        text='t_s,'+','.join('TC'+str(i) for i in range(1,9))+'\n0,'+','.join(['99']*8)+'\n1,'+','.join(['99']*8)
        with self.assertRaises(ValueError):self.session.preview_temperature_calibration({'source':'csv','csv_text':text})

    def test_bad_timestamps_and_nonfinite_reference_are_rejected(self):
        for rows in ('0,'+','.join(['99']*12)+'\n0,'+','.join(['99']*12),
                     '0,'+','.join(['99']*12)+'\n10,'+','.join(['99']*12),
                     '0,'+','.join(['nan']*12)+'\n1,'+','.join(['99']*12)):
            text='t_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n'+rows
            with self.assertRaises(ValueError):self.session.preview_temperature_calibration({'source':'csv','csv_text':text})

    def test_latest_reference_uses_uncorrected_values(self):
        self.save();self.run_csv()
        p=self.session.preview_temperature_calibration({'source':'latest'})
        self.assertEqual(p['reference_raw_c'][0],99)
        self.assertEqual(p['reference_raw_c'][11],100.1)

    def test_failed_persistence_does_not_change_profile(self):
        saved=self.save()
        with patch.object(Path,'replace',side_effect=OSError('disk full')):
            with self.assertRaises(OSError):self.save(action='disable')
        self.assertEqual(self.session.temperature_calibration.to_dict(),saved)


class CalibrationHttpTests(unittest.TestCase):
    def test_routes_protect_writes_and_support_reference_preview(self):
        with tempfile.TemporaryDirectory() as folder:
            server=GuiServer(('127.0.0.1',0),Path(folder));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            def request(method,path,payload=None,token=None):
                c=http.client.HTTPConnection('127.0.0.1',server.server_address[1],timeout=5)
                headers={'Content-Type':'application/json'}
                if token:headers['X-App-Token']=token
                try:
                    c.request(method,path,json.dumps(payload) if payload is not None else None,headers)
                    r=c.getresponse();return r.status,r.read()
                finally:c.close()
            try:
                self.assertEqual(request('GET','/temperature-calibration.js')[0],200)
                code,body=request('GET','/api/temperature-calibration');self.assertEqual(code,200)
                payload={'action':'apply','expected_profile_id':json.loads(body)['profile_id'],'reference_raw_c':[99]*12}
                self.assertEqual(request('POST','/api/temperature-calibration',payload)[0],403)
                self.assertEqual(request('POST','/api/temperature-calibration',payload,server.token)[0],200)
                code,body=request('POST','/api/temperature-calibration/preview',{'source':'csv','csv_text':table_csv(5)},server.token)
                self.assertEqual(code,200);self.assertEqual(json.loads(body)['coverage_s'],5)
            finally:server.shutdown();server.server_close();thread.join(5)
