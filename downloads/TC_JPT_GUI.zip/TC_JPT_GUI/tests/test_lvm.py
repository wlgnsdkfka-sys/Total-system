import csv
import io
import tempfile
from pathlib import Path
import unittest

from boiling_automation.core import Reading,Event
from boiling_automation.gui import GuiSession,csv_readings
from boiling_automation.lvm import measurement_rows,to_csv
from boiling_automation.measurement_data import MeasurementLog,MEASUREMENT_FILES
from boiling_automation.temperature_calibration import TemperatureCalibration


class LVMTests(unittest.TestCase):
    def test_real_lvm_headers_segments_metadata_precision_and_raw_replay(self):
        with tempfile.TemporaryDirectory() as folder:
            log=MeasurementLog(Path(folder),TemperatureCalibration(),batch_size=3,flush_interval_s=600)
            try:
                for i in range(7):
                    log.write(Reading(i*.2,(100.123456789,)*8,bulk_temperatures_c=(99.,None,98.,97.)),
                              0,-1 if i==6 else 0,'tripped' if i==6 else 'running',
                              [Event('shutdown_required',i*.2,{'reason':'critical_temperature'})] if i==6 else [])
                bodies=[(Path(folder)/name).read_bytes() for name in MEASUREMENT_FILES.values()]
                for basis,body in zip(MEASUREMENT_FILES,bodies):
                    self.assertTrue(body.startswith(b'LabVIEW Measurement\nWriter_Version\t2\n'))
                    self.assertEqual(body.count(b'Channels\t17\n'),3)
                    data=list(measurement_rows(body));self.assertEqual(len(data),7)
                    self.assertEqual([r['sample_id'] for r in data],list(map(str,range(7))))
                    self.assertEqual(data[-1]['TC1'],'100.123456789')
                    self.assertEqual(data[-1]['TC10'],'')
                    self.assertEqual(data[-1]['temperature_basis'],basis)
                    self.assertEqual(data[-1]['stop_reason'],'critical_temperature')
                    self.assertEqual(data[-1]['power_index_after_sample_percent'],'-1')
                points=list(csv_readings(bodies[0].decode()))
                self.assertEqual(points[-1].temperatures_c,(100.123456789,)*8)
                self.assertIsNone(points[-1].bulk_temperatures_c[1])
                self.assertEqual(len(list(csv.DictReader(io.StringIO(to_csv(bodies[0]).decode())))),7)
                with self.assertRaisesRegex(ValueError,'원시'):list(csv_readings(bodies[1].decode()))
                with self.assertRaises(ValueError):list(measurement_rows(bodies[0][:-50]))
            finally:
                for stream in log.streams.values():stream.close()

    def test_live_files_and_download_are_lvm_with_csv_compatibility_only_on_request(self):
        with tempfile.TemporaryDirectory() as folder:
            s=GuiSession(Path(folder))
            s.start({'source':'csv','csv_text':'t_s,'+','.join('TC'+str(i) for i in range(1,9))+'\n0,'+','.join(['250']*8),
                     'critical_c':200,'speed':300})
            s.worker.join(5)
            try:
                self.assertFalse(list(s.writer.directory.glob('measurements_*.csv')))
                self.assertEqual(len(list(s.writer.directory.glob('measurements_*.lvm'))),3)
                body,name=s.export_measurements('raw',format='lvm')
                self.assertTrue(name.endswith('.lvm'));self.assertEqual(len(list(measurement_rows(body))),1)
                body,name=s.export_measurements('raw',format='csv')
                self.assertTrue(name.endswith('.csv'));self.assertIn('TC1',body.decode())
            finally:s.stop()
