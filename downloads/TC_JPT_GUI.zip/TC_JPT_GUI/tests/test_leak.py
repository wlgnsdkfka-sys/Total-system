import csv
from dataclasses import asdict
import io
import json
from pathlib import Path
import tempfile
import unittest

from boiling_automation.calculation import default_settings
from boiling_automation.core import Config, Reading, ReplayController, _interval
from boiling_automation.gui import GuiSession, csv_readings
from boiling_automation.leak import FluxMonitor, LeakConfig


def calibration():
    settings = default_settings()
    for i, band in enumerate(settings['bands']):
        band.update(conductivity_w_mk=400, flux_spacing_mm=1, weight=1 if i == 0 else 0)
    return settings


def point(t, delta=1, bulk=()):
    return Reading(float(t), (25, 25+delta, 25, 25, 25, 25, 25, 25), bulk_temperatures_c=bulk)


def monitor(action='stop', **kwargs):
    return FluxMonitor(LeakConfig(enabled=True, calibration_confirmed=True, action=action,
                                  window_s=4, settling_s=0, hold_s=2, threshold_mode='manual', **kwargs), calibration())


class LeakDetectionTests(unittest.TestCase):
    def test_enabling_requires_thresholds_and_calibration_confirmation(self):
        for changes in ({'enabled':True}, {'enabled':True, 'calibration_confirmed':True, 'threshold_mode':'manual'},
                        {'drop_percent':101}, {'hold_s':float('nan')}, {'window_s':0},
                        {'enabled':'yes'}, {'fluctuation_std_w_cm2':-1}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                LeakConfig.from_payload(changes)
        self.assertFalse(LeakConfig().enabled)

    def test_output_increase_followed_by_drop_stops_before_next_increase(self):
        m = monitor(drop_percent=20)
        c = ReplayController(Config(1000, allowed_std_c=100, max_power_percent=3), m)
        events = []
        for t in range(110):
            events += c.process(point(t, 1 if t <= 90 else .5))
        self.assertEqual(c.state, 'tripped')
        self.assertEqual(c.power_percent, 1)
        self.assertEqual(len(c.records), 1)
        alerts = [e for e in events if e.kind == 'suspected_leak']
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].t_s, 97)
        self.assertEqual(alerts[0].details['drop_percent'], 50)
        self.assertEqual(alerts[0].details['reference']['power_percent'], 0)
        self.assertEqual(events[-1].details['independent_actions'], ['shutter_close', 'laser_emission_off'])

    def test_warning_keeps_running_and_does_not_repeat_same_rule_per_step(self):
        m = monitor('warn', fluctuation_std_w_cm2=1)
        c = ReplayController(Config(1000), m)
        events = []
        for t in range(30):
            events += c.process(point(t, 1+(-1)**t*.2))
        self.assertFalse(c.terminal)
        self.assertEqual(sum(e.kind == 'suspected_leak' for e in events), 1)
        self.assertGreater(m.std, 1)
        self.assertEqual(m.snapshot()['status'], 'suspected')

    def test_flux_trip_has_priority_over_record_and_output_increase(self):
        m = monitor(fluctuation_std_w_cm2=1)
        c = ReplayController(Config(1000, allowed_std_c=100), m)
        for t in range(90):
            c.process(point(t, 1 if t < 88 else 2))
        # The two-second violation completes on the first record boundary.
        events = c.process(point(90, 2))
        self.assertTrue(c.terminal)
        self.assertEqual(c.power_percent, 0)
        self.assertEqual(c.records, [])
        self.assertEqual(events[-1].details['reason'], 'suspected_leak')

    def test_raw_temperature_and_bad_data_still_have_first_priority(self):
        for reading, reason in ((Reading(6, (2000,)*8), 'critical_temperature'),
                                (Reading(6, (float('nan'),)*8), 'invalid_temperature_data')):
            m = monitor(fluctuation_std_w_cm2=1)
            c = ReplayController(Config(1000), m)
            for t in range(6): c.process(point(t))
            events = c.process(reading)
            self.assertEqual(events[-1].details['reason'], reason)
            self.assertFalse(any(e.kind == 'suspected_leak' for e in events))

    def test_short_spike_does_not_satisfy_sustained_condition(self):
        m = monitor(fluctuation_std_w_cm2=1)
        m.config = LeakConfig(enabled=True, calibration_confirmed=True, window_s=2,
                              settling_s=0, hold_s=5, fluctuation_std_w_cm2=1)
        alerts = []
        for t in range(20): alerts += m.observe(point(t, 2 if t == 4 else 1), 0)
        self.assertEqual(alerts, [])

    def test_step_transition_and_settling_data_are_excluded_from_window(self):
        m = monitor(fluctuation_std_w_cm2=1)
        m.config = LeakConfig(enabled=True, calibration_confirmed=True, window_s=4,
                              settling_s=3, hold_s=0, fluctuation_std_w_cm2=1)
        for t in range(15): self.assertFalse(m.observe(point(t), 0))
        for t in range(15, 23): self.assertFalse(m.observe(point(t, 5), 1))
        self.assertTrue(m.ready)
        self.assertEqual(m.std, 0)
        self.assertEqual(m.mean, 200)

    def test_nonpositive_reference_never_produces_percent_drop(self):
        for baseline in (0, -2):
            m = monitor(drop_percent=20)
            m.reference = {'heat_flux':baseline, 'power_percent':0}
            for t in range(10): self.assertFalse(m.observe(point(t, -.5), 1))
            self.assertIsNone(m.drop)

    def test_minimum_reference_flux_excludes_small_noise_baselines(self):
        m = monitor(drop_percent=20, min_reference_flux_w_cm2=1)
        m.reference = {'heat_flux':.001, 'power_percent':0}
        for t in range(10): self.assertFalse(m.observe(point(t, 0), 1))
        self.assertIsNone(m.drop)

    def test_overflowing_drop_cannot_contaminate_json_snapshot(self):
        m = monitor(drop_percent=20)
        m.reference = {'heat_flux':1e-320, 'power_percent':0}
        for t in range(4): m.observe(point(t),1)
        with self.assertRaises(ValueError): m.observe(point(4),1)
        json.dumps(m.snapshot(),allow_nan=False)

    def test_disabled_monitor_does_not_interrupt_or_claim_leak(self):
        m = FluxMonitor(LeakConfig(), calibration())
        for t in range(10): self.assertFalse(m.observe(point(t, (-1)**t), 0))
        self.assertEqual(m.snapshot()['status'], 'disabled')
        self.assertEqual(m.latest_flux, -40)


class BulkAndIntegrationTests(unittest.TestCase):
    def test_optional_bulk_csv_and_missing_values_are_distinct(self):
        header = 't_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n'
        rows = list(csv_readings(header+'0,'+','.join(['25']*8+['95','96','','98'])+'\n'))
        self.assertEqual(rows[0].bulk_temperatures_c, (95,96,None,98))
        old = list(csv_readings('t_s,'+','.join('TC'+str(i) for i in range(1,9))+'\n0,'+','.join(['25']*8)+'\n'))
        self.assertEqual(old[0].bulk_temperatures_c, (None,)*4)

    def test_bulk_is_excluded_from_trip_and_stability_channels(self):
        c = ReplayController(Config(100, allowed_std_c=.01, max_power_percent=0))
        for t in range(91): c.process(point(t, bulk=(200+t,300-t,400+t,500-t)))
        self.assertEqual(c.state,'completed')
        self.assertEqual(len(c.records[0].segment.channels),8)
        self.assertEqual(c.records[0].segment.worst_std_c,0)

    def test_interpolation_preserves_bulk_and_does_not_fill_missing_channels(self):
        points = [point(0, bulk=(90,None,92,93)), point(2,bulk=(92,93,94,95))]
        boundary = _interval(points,.5,1.5)[0]
        self.assertEqual(boundary.bulk_temperatures_c,(90.5,None,92.5,93.5))

    def test_saved_leak_settings_restore_and_run_snapshots_include_calibration(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            s = GuiSession(root)
            s.save_settings(calibration())
            config = asdict(monitor('warn',drop_percent=20).config)
            s.save_leak_settings(config)
            s = GuiSession(root)
            self.assertTrue(s.leak_config.enabled)
            s.start({'critical_c':1000, 'speed':1})
            try:
                s.save_settings(default_settings())
                self.assertTrue(s.snapshot()["leak_confirmation_required"])
                self.assertEqual(s.controller.flux_monitor.settings,calibration())
                with self.assertRaises(ValueError): s.save_leak_settings(config)
                metadata = json.loads((s.writer.directory/'run.json').read_text())
                self.assertEqual(metadata['leak_detection'],config)
                self.assertEqual(metadata['calculation_settings'],calibration())
            finally:
                s.stop(); s.worker.join(5)

    def test_gui_csv_drop_warning_and_bulk_export(self):
        with tempfile.TemporaryDirectory() as folder:
            s = GuiSession(Path(folder)); s.save_settings(calibration())
            text = 't_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n'
            for t in range(181):
                text += str(t)+','+','.join(map(str,point(t,1 if t<=90 else .5).temperatures_c))+',95,96,97,98\n'
            config = asdict(monitor('warn',drop_percent=20).config)
            s.start({'critical_c':1000,'allowed_std_c':100,'max_power_percent':1,'speed':300,
                     'source':'csv','csv_text':text,'leak_detection':config})
            s.worker.join(5)
            state=s.snapshot()
            self.assertEqual(state['reason'],'maximum_output_reached')
            self.assertEqual(state['latest']['bulk_temperatures_c'], (95,96,97,98))
            self.assertEqual(len(state['leak_detection']['alerts']),1)
            with (s.writer.directory/'selected_samples.csv').open() as f:
                rows=list(csv.DictReader(f))
            self.assertTrue(all(row['TC12']=='98.0' for row in rows))
            self.assertEqual(len(state['records'][0]['segment']['channels']),8)
            self.assertEqual(state['saturation_c'],100)
            events=[json.loads(line) for line in (s.writer.directory/'events.jsonl').read_text().splitlines()]
            self.assertEqual(sum(e['kind']=='suspected_leak' for e in events),1)



class AutomaticFluxTests(unittest.TestCase):
    def auto(self, **kwargs):
        return FluxMonitor(LeakConfig(enabled=True, calibration_confirmed=True, threshold_mode='auto',
                                      window_s=4, settling_s=0, hold_s=2, **kwargs),calibration())

    def test_auto_mode_can_be_enabled_without_absolute_thresholds(self):
        cfg=LeakConfig.from_payload({'enabled':True,'calibration_confirmed':True,'threshold_mode':'auto'})
        self.assertIsNone(cfg.fluctuation_std_w_cm2)
        self.assertEqual(cfg.min_reference_flux_w_cm2,0)
        self.assertEqual(cfg.noise_multiplier,5)

    def test_legacy_absolute_settings_keep_manual_behavior(self):
        cfg=LeakConfig.from_payload({'enabled':True,'calibration_confirmed':True,'fluctuation_std_w_cm2':3})
        self.assertEqual(cfg.threshold_mode,'manual')
        self.assertEqual(cfg.fluctuation_std_w_cm2,3)

    def test_fluctuation_detection_scales_with_measured_noise(self):
        times=[]
        thresholds=[]
        for scale in (.01,1,100):
            m=self.auto(); alerts=[]
            for t in range(35):
                amplitude=.01 if t<20 else .2
                alerts += m.observe(point(t,scale*(1+(-1)**t*amplitude)),0)
            self.assertEqual(len(alerts),1)
            self.assertEqual(alerts[0]['rule'],'flux_fluctuation')
            self.assertEqual(alerts[0]['threshold_mode'],'auto')
            times.append(alerts[0]['t_s']);thresholds.append(alerts[0]['threshold_std_w_cm2']/scale)
        self.assertEqual(times,[times[0]]*3)
        for value in thresholds: self.assertAlmostEqual(value,thresholds[0])

    def test_auto_reference_rejects_noise_near_zero(self):
        m=self.auto(drop_percent=20)
        m.reference={'heat_flux':.01,'heat_flux_std':.1,'power_percent':0}
        for t in range(10): self.assertFalse(m.observe(point(t,0),1))
        self.assertEqual(m.minimum_reference,.5)
        self.assertIsNone(m.drop)

    def test_constant_baseline_is_finite_and_detects_subsequent_variation(self):
        m=self.auto();alerts=[]
        for t in range(25): alerts+=m.observe(point(t,1 if t<15 else 1+(-1)**t*.2),0)
        self.assertEqual(len(alerts),1)
        self.assertGreater(m.threshold_std,0)
        json.dumps(m.snapshot(),allow_nan=False)

    def test_auto_drop_stops_and_exports_actual_derived_thresholds(self):
        m=self.auto(action='stop',drop_percent=20)
        c=ReplayController(Config(1000,allowed_std_c=100,max_power_percent=3),m)
        events=[]
        for t in range(110): events+=c.process(point(t,1 if t<=90 else .5))
        self.assertEqual(c.power_percent,1)
        self.assertEqual(events[-1].details['reason'],'suspected_leak')
        alert=[e for e in events if e.kind=='suspected_leak'][0]
        self.assertEqual(alert.details['drop_percent'],50)
        self.assertIsNotNone(alert.details['noise_reference'])
        self.assertGreater(alert.details['minimum_reference_flux_w_cm2'],0)

    def test_warned_stage_does_not_relearn_anomalous_noise(self):
        m=self.auto(); c=ReplayController(Config(1000,allowed_std_c=100),m)
        # First window is quiet, persistent later variation is flagged before the record.
        for t in range(91): c.process(point(t,1 if t<15 else 1+(-1)**t*.2))
        self.assertEqual(m.noise_reference['source'],'first_observation')
        self.assertEqual(m.noise_reference['std_w_cm2'],0)


if __name__ == '__main__': unittest.main()
