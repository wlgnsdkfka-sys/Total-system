import csv
import io
import json
from pathlib import Path
import statistics
import tempfile
import unittest

from boiling_automation.boiling import curve_csv, import_curve_csv, prepare_curve
from boiling_automation.calculation import calculate_stage, default_settings, validate_settings
from boiling_automation.core import Config, Reading, ReplayController
from boiling_automation.gui import GuiSession


def record_for(values):
    controller = ReplayController(Config(1000, allowed_std_c=100, max_power_percent=0))
    for second in range(91):
        controller.process(Reading(float(second), tuple(values(second))))
    return controller.records[0]


class StatisticsExportTests(unittest.TestCase):
    def test_gui_csv_std_matches_the_exact_saved_samples(self):
        with tempfile.TemporaryDirectory() as name:
            session = GuiSession(Path(name))
            session.start({"critical_c": 100, "allowed_std_c": .2, "max_power_percent": 0, "speed": 300})
            session.worker.join(5)
            self.assertFalse(session.worker.is_alive())
            with (session.writer.directory / 'selected_samples.csv').open() as stream:
                selected = list(csv.DictReader(stream))
            with (session.writer.directory / 'stages.csv').open() as stream:
                stage = next(csv.DictReader(stream))
            for channel in range(1, 9):
                sigma = statistics.stdev(float(row[f'TC{channel}']) for row in selected)
                self.assertAlmostEqual(float(stage[f'TC{channel}_std_c']), sigma)
            self.assertAlmostEqual(float(stage['selected_max_std_c']), max(float(stage[f'TC{i}_std_c']) for i in range(1, 9)))


class CalculationTests(unittest.TestCase):
    def test_physical_units_and_surface_extrapolation_are_explicit(self):
        settings = default_settings()
        for i, band in enumerate(settings['bands']):
            band.update(conductivity_w_mk=400, surface_offset_mm=.5,
                        temperature_spacing_mm=1, flux_spacing_mm=1, weight=1 if i == 0 else 0)
        record = record_for(lambda _: [110, 120, 25, 25, 25, 25, 25, 25])
        result = calculate_stage(record, settings)
        self.assertAlmostEqual(result['surface_temp_c'], 105)
        self.assertAlmostEqual(result['heat_flux'], 400)
        self.assertEqual(result['surface_std_c'], 0)
        self.assertEqual(result['heat_flux_std'], 0)
        curve = prepare_curve({'saturation_c': 100, 'rows': [result]})
        self.assertAlmostEqual(curve['points'][0]['superheat_c'], 5)
        self.assertAlmostEqual(curve['points'][0]['heat_flux_w_cm2'], 400)

    def test_derived_temperature_std_includes_channel_covariance(self):
        settings = default_settings()
        for i, band in enumerate(settings['bands']):
            band.update(surface_offset_mm=0, weight=.5 if i < 2 else 0)
        record = record_for(lambda t: [25 + .1 * t, 25 + .1 * t, 25 - .1 * t, 25 - .1 * t, 25, 25, 25, 25])
        result = calculate_stage(record, settings)
        self.assertGreater(record.segment.channels[0].std_c, 0)
        self.assertAlmostEqual(result['surface_temp_c'], 25)
        self.assertAlmostEqual(result['surface_std_c'], 0)

    def test_invalid_geometry_and_weights_are_rejected(self):
        for key, value in [('flux_spacing_mm', 0), ('weight', .9), ('channel_a', 9)]:
            with self.subTest(key=key):
                settings = default_settings()
                settings['bands'][0][key] = value
                with self.assertRaises(ValueError):
                    validate_settings(settings)

    def test_missing_settings_return_a_validation_error(self):
        with self.assertRaises(ValueError):
            validate_settings({})

    def test_saturation_and_constants_persist_without_changing_trip_threshold(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            session = GuiSession(root)
            settings = default_settings()
            settings['saturation_c'] = 95
            settings['bands'][0]['conductivity_w_mk'] = 405
            session.save_settings(settings)
            restored = GuiSession(root)
            self.assertEqual(restored.calculation_settings['saturation_c'], 95)
            self.assertEqual(restored.calculation_settings['bands'][0]['conductivity_w_mk'], 405)
            self.assertIsNone(restored.controller)
            self.assertTrue((root / 'calculation_settings.json').is_file())


class BoilingCurveTests(unittest.TestCase):
    def test_heat_flux_units_and_saturation_are_not_inferred_from_percent(self):
        for unit, flux in [('W/cm2', 1), ('kW/m2', 10), ('W/m2', 10000)]:
            with self.subTest(unit=unit):
                result = prepare_curve({'saturation_c': 100, 'heat_flux_unit': unit,
                                        'rows': [{'surface_temp_c': 108, 'surface_std_c': .2, 'heat_flux': flux}]})
                self.assertEqual(result['points'][0]['superheat_c'], 8)
                self.assertEqual(result['points'][0]['heat_flux_w_cm2'], 1)
                self.assertEqual(result['points'][0]['surface_std_c'], .2)

    def test_missing_flux_is_reported_and_not_fabricated(self):
        result = prepare_curve({'saturation_c': 100, 'rows': [
            {'power_percent': 5, 'surface_temp_c': 110},
            {'surface_temp_c': 120, 'heat_flux': 2},
        ]})
        self.assertEqual(len(result['points']), 1)
        self.assertEqual(result['omitted_rows'][0]['row'], 1)

    def test_vi_csv_aliases_use_explicit_w_per_cm2_units(self):
        result = import_curve_csv('Average Temp,Total Flux\n110,12.5\n', 'W/cm2')
        self.assertEqual(result['rows'][0]['surface_temp_c'], 110)
        self.assertEqual(result['rows'][0]['heat_flux'], 12.5)

    def test_explicit_si_csv_is_converted_once(self):
        result = import_curve_csv('surface_temp_c,heat_flux_w_m2\n110,10000\n')
        self.assertEqual(result['heat_flux_unit'], 'W/cm2')
        self.assertEqual(result['rows'][0]['heat_flux'], 1)

    def test_curve_csv_records_units_saturation_and_uncertainty(self):
        curve = prepare_curve({'saturation_c': 95, 'rows': [
            {'surface_temp_c': 105, 'surface_std_c': .1, 'heat_flux': 3, 'heat_flux_std': .05},
        ]})
        rows = list(csv.DictReader(io.StringIO(curve_csv(curve).decode('utf-8-sig'))))
        self.assertEqual(float(rows[0]['superheat_c']), 10)
        self.assertEqual(float(rows[0]['heat_flux_w_cm2']), 3)
        self.assertEqual(float(rows[0]['heat_flux_std_w_cm2']), .05)
        self.assertEqual(float(rows[0]['saturation_c']), 95)

    def test_nonfinite_curve_data_is_rejected(self):
        with self.assertRaises(ValueError):
            prepare_curve({'saturation_c': 100, 'rows': [{'surface_temp_c': 110, 'heat_flux': float('nan')}]})
