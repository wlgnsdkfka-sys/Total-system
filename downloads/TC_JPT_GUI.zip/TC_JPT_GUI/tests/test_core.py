import math
import unittest

from boiling_automation.core import Config, Reading, ReplayController, select_best_segment


def reading(t, value=25.0):
    return Reading(float(t), (float(value),) * 8)


def feed(controller, start, end, value=25.0):
    events = []
    for second in range(start, end + 1):
        events.extend(controller.process(reading(second, value)))
    return events


class SegmentTests(unittest.TestCase):
    def test_a_complete_sixty_seconds_is_required(self):
        points = [reading(t) for t in range(60)]
        self.assertIsNone(select_best_segment(points, Config(100)))

    def test_best_segment_can_be_in_the_middle(self):
        points = [reading(t, 25 + (20 - t if t < 20 else t - 40 if t > 40 else 0))
                  for t in range(61)]
        segment = select_best_segment(points, Config(100))
        self.assertEqual((segment.start_s, segment.end_s), (20, 40))
        self.assertEqual(segment.worst_range_c, 0)

    def test_equal_segments_favor_the_latest(self):
        segment = select_best_segment([reading(t) for t in range(61)], Config(100))
        self.assertEqual((segment.start_s, segment.end_s), (40, 60))

    def test_all_eight_channels_share_one_segment(self):
        points = []
        for t in range(61):
            other = 25 if t <= 20 else 25 + (t - 20) * 0.1
            eighth = 25 + t if t < 40 else 65
            points.append(Reading(float(t), (other,) * 7 + (eighth,)))
        segment = select_best_segment(points, Config(100))
        self.assertEqual((segment.start_s, segment.end_s), (40, 60))
        self.assertEqual(len(segment.channels), 8)
        self.assertAlmostEqual(segment.channels[7].range_c, 0)
        self.assertAlmostEqual(segment.worst_range_c, 2)

    def test_statistics_are_time_weighted(self):
        segment = select_best_segment([reading(t, 20 + 0.5 * t) for t in range(61)], Config(100))
        self.assertAlmostEqual(segment.channels[0].mean_c, 45)
        self.assertAlmostEqual(segment.channels[0].std_c, 10 / math.sqrt(12))

    def test_irregular_timestamps_keep_exact_twenty_second_duration(self):
        points = [reading(i * 0.7) for i in range(87)]
        segment = select_best_segment(points, Config(100))
        self.assertAlmostEqual(segment.end_s - segment.start_s, 20)
        self.assertAlmostEqual(segment.end_s, points[-1].t_s)


class ReplayTests(unittest.TestCase):
    def test_stable_run_advances_early_after_sixty_seconds(self):
        controller = ReplayController(Config(100, allowed_range_c=0.2))
        feed(controller, 0, 59)
        self.assertEqual(controller.records, [])
        events = controller.process(reading(60))
        self.assertEqual(controller.power_percent, 1)
        self.assertEqual(controller.records[0].completion_reason, "stable")
        self.assertEqual([e.kind for e in events], ["observation_recorded", "simulated_power_increased"])

    def test_no_tolerance_does_not_invent_an_early_stability_criterion(self):
        controller = ReplayController(Config(100))
        feed(controller, 0, 299)
        self.assertEqual(controller.records, [])
        controller.process(reading(300))
        self.assertEqual(controller.power_percent, 1)
        self.assertEqual(controller.records[0].completion_reason, "maximum_step_time")

    def test_best_interval_is_only_from_the_final_minute(self):
        controller = ReplayController(Config(1000))
        for t in range(301):
            controller.process(reading(t, 25 if t < 240 else 25 + (t - 240) * 0.1))
        record = controller.records[0]
        self.assertGreaterEqual(record.segment.start_s, 240)
        self.assertLessEqual(record.segment.end_s, 300)
        self.assertEqual(record.segment.end_s - record.segment.start_s, 20)
        self.assertEqual(record.selected_samples[0].t_s, record.segment.start_s)
        self.assertEqual(record.selected_samples[-1].t_s, record.segment.end_s)

    def test_historical_quiet_interval_does_not_cause_early_increase_during_rise(self):
        controller = ReplayController(Config(1000, allowed_range_c=0.2))
        for t in range(61):
            controller.process(reading(t, 25 if t <= 20 else 25 + (t - 20) * 0.1))
        self.assertEqual(controller.records, [])
        self.assertEqual(controller.power_percent, 0)

    def test_unstable_run_records_at_five_minutes(self):
        controller = ReplayController(Config(1000, allowed_range_c=0.2))
        for t in range(301):
            controller.process(reading(t, 25 + 0.1 * t))
        self.assertEqual(controller.records[0].completion_reason, "maximum_step_time")
        self.assertEqual(controller.power_percent, 1)

    def test_next_step_cannot_reuse_an_interval_from_previous_power(self):
        controller = ReplayController(Config(100, allowed_range_c=0.2))
        feed(controller, 0, 60)
        feed(controller, 61, 119, 30)
        self.assertEqual(len(controller.records), 1)
        controller.process(reading(120, 30))
        self.assertEqual(len(controller.records), 2)
        self.assertEqual(controller.records[1].power_percent, 1)
        self.assertGreaterEqual(controller.records[1].segment.start_s, 60)
        self.assertEqual(controller.records[1].segment.channels[0].mean_c, 30)

    def test_raw_tc8_threshold_preempts_recording_and_increase(self):
        controller = ReplayController(Config(100, allowed_range_c=0.2))
        feed(controller, 0, 59)
        events = controller.process(Reading(60, (25,) * 7 + (100,)))
        self.assertEqual(controller.state, "tripped")
        self.assertEqual(controller.records, [])
        self.assertEqual(controller.power_percent, 0)
        self.assertEqual(events[0].details["channels"], ["TC8"])
        self.assertEqual(events[0].details["independent_actions"], ["shutter_close", "laser_emission_off"])

    def test_a_single_hot_sample_is_not_hidden_by_averaging(self):
        controller = ReplayController(Config(100))
        feed(controller, 0, 29)
        events = controller.process(Reading(30, (101,) + (25,) * 7))
        self.assertEqual(events[0].details["reason"], "critical_temperature")

    def test_initial_overtemperature_does_not_start_a_power_step(self):
        controller = ReplayController(Config(100))
        events = controller.process(reading(0, 101))
        self.assertEqual([e.kind for e in events], ["shutdown_required"])

    def test_invalid_temperature_requires_both_shutdown_actions(self):
        controller = ReplayController(Config(100))
        events = controller.process(Reading(0, (math.nan,) + (25,) * 7))
        self.assertEqual(events[0].details["reason"], "invalid_temperature_data")
        self.assertEqual(len(events[0].details["independent_actions"]), 2)

    def test_missing_channel_is_an_error(self):
        events = ReplayController(Config(100)).process(Reading(0, (25,) * 7))
        self.assertEqual(events[0].details["reason"], "invalid_temperature_data")

    def test_non_increasing_timestamps_are_an_error(self):
        controller = ReplayController(Config(100))
        controller.process(reading(0))
        self.assertEqual(controller.process(reading(0))[0].details["reason"], "invalid_temperature_data")

    def test_data_gap_and_watchdog_detect_stale_measurements(self):
        for method in ("sample", "clock"):
            with self.subTest(method=method):
                controller = ReplayController(Config(100))
                controller.process(reading(0))
                events = controller.process(reading(3)) if method == "sample" else controller.check_clock(3)
                self.assertTrue(controller.terminal)
                self.assertIn(events[0].details["reason"], ("temperature_data_gap", "temperature_data_stale"))

    def test_trip_is_latched(self):
        controller = ReplayController(Config(100))
        controller.process(reading(0, 101))
        self.assertEqual(controller.process(reading(1)), [])
        self.assertEqual(controller.check_clock(5), [])
        self.assertEqual(controller.state, "tripped")

    def test_maximum_output_cannot_be_exceeded(self):
        controller = ReplayController(Config(100, allowed_range_c=0.2, max_power_percent=0))
        events = feed(controller, 0, 60)
        self.assertEqual(controller.state, "completed")
        self.assertEqual(controller.power_percent, 0)
        self.assertNotIn("simulated_power_increased", [e.kind for e in events])
        self.assertEqual(events[-1].details["reason"], "maximum_output_reached")

    def test_eof_is_reported_as_an_incomplete_run(self):
        controller = ReplayController(Config(100))
        feed(controller, 0, 20)
        self.assertEqual(controller.finish()[0].details["reason"], "input_ended_before_completion")
        self.assertEqual(controller.state, "tripped")

    def test_invalid_configuration_is_rejected(self):
        for options in ({"critical_c": math.nan}, {"critical_c": 100, "allowed_range_c": -1},
                        {"critical_c": 100, "max_power_percent": 101},
                        {"critical_c": 100, "step_duration_s": 301}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                Config(**options)


if __name__ == "__main__":
    unittest.main()
