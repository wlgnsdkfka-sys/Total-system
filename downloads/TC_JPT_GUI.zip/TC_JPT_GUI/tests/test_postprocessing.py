import csv
import http.client
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
import zipfile

from boiling_automation.core import Reading
from boiling_automation.gui import GuiServer,GuiSession
from boiling_automation.lvm import (EXPORT_COLUMNS,continuous_lvm,flatten_input,measurement_rows,to_csv)
from boiling_automation.measurement_data import MeasurementLog,MEASUREMENT_FILES
from boiling_automation.temperature_calibration import TemperatureCalibration


class PostprocessingTests(unittest.TestCase):
    def fixture(self,folder):
        log=MeasurementLog(Path(folder),TemperatureCalibration(),batch_size=3,flush_interval_s=600)
        try:
            for i in range(8):
                log.write(Reading(i*.01,(97.123456789,)*8,bulk_temperatures_c=(98.1,None,98.3,98.4)),0,0,'running',[])
            log.flush()
            return (Path(folder)/MEASUREMENT_FILES['raw']).read_bytes()
        finally:
            for stream in log.streams.values():stream.close()

    def test_flat_download_has_one_header_all_rows_and_original_values(self):
        with tempfile.TemporaryDirectory() as folder:original=self.fixture(folder)
        self.assertEqual(original.count(b'X_Value\t'),3)
        body=continuous_lvm(original)
        self.assertEqual(body.count(b'X_Value\t'),1)
        self.assertEqual(body.count(b'Samples\t'),1)
        self.assertIn(b'Multi_Headings\tNo',body)
        self.assertEqual(list(measurement_rows(body)),list(measurement_rows(original)))
        exported=to_csv(original).decode()
        self.assertEqual(exported.count('t_s,TC1,TC2'),1)
        rows=list(csv.DictReader(io.StringIO(exported)))
        self.assertEqual(list(rows[0]),list(EXPORT_COLUMNS))
        self.assertEqual(len(rows),8)
        self.assertEqual(rows[-1]['sample_id'],'7')
        self.assertEqual(rows[-1]['TC1'],'97.123456789')
        self.assertEqual(rows[-1]['TC10'],'')

    def test_excel_resaved_segmented_csv_keeps_numeric_text_without_inventing_lost_metadata(self):
        with tempfile.TemporaryDirectory() as folder:original=self.fixture(folder)
        fields=list(csv.reader(io.StringIO(original.decode()),delimiter='\t'))
        for row in fields:
            if row and row[0] and row[0][0].isdigit():row[-1]='{"state_after_sample":"running"'
        source=io.StringIO(newline='');csv.writer(source).writerows(fields)
        flattened,report=flatten_input(source.getvalue())
        self.assertEqual(report['sample_count'],8)
        self.assertEqual(report['source_segments'],3)
        self.assertEqual(report['missing_metadata_rows'],8)
        self.assertTrue(report['strictly_increasing'])
        data=list(csv.DictReader(io.StringIO(flattened)))
        self.assertEqual([r['sample_id'] for r in data],list(map(str,range(8))))
        self.assertTrue(all(r['TC1']=='97.123456789' for r in data))
        self.assertTrue(all(r['temperature_basis']=='unknown' and r['state_after_sample']=='' for r in data))

    def test_out_of_order_input_is_preserved_and_reported_not_silently_sorted(self):
        text='t_s,'+','.join('TC'+str(i) for i in range(1,9))+'\n'
        text+='\n'.join(str(t)+','+','.join(['99.123456789']*8) for t in (2,0,1))
        out,report=flatten_input(text)
        self.assertEqual([r['t_s'] for r in csv.DictReader(io.StringIO(out))],['2','0','1'])
        self.assertFalse(report['strictly_increasing']);self.assertFalse(report['rows_sorted_or_removed'])

    def test_zip_adds_continuous_csvs_without_writing_live_csv_mirrors(self):
        with tempfile.TemporaryDirectory() as folder:
            s=GuiSession(Path(folder))
            try:
                s.start({'source':'demo','critical_c':1000,'allowed_std_c':.2,'max_power_percent':0,'speed':300})
                s.worker.join(5);body,_=s.export()
                self.assertFalse(list(s.writer.directory.glob('measurements_*.csv')))
                with zipfile.ZipFile(io.BytesIO(body)) as z:
                    for basis,name in MEASUREMENT_FILES.items():
                        flat=z.read(name.replace('.lvm','.csv')).decode()
                        self.assertEqual(list(csv.DictReader(io.StringIO(flat))),list(measurement_rows(z.read(name))))
                        self.assertEqual(flat.count('t_s,TC1,TC2'),1)
            finally:s.stop()

    def test_converter_http_requires_app_token_and_does_not_start_an_experiment(self):
        with tempfile.TemporaryDirectory() as folder:
            server=GuiServer(('127.0.0.1',0),Path(folder));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            def request(token):
                connection=http.client.HTTPConnection(*server.server_address)
                try:
                    text='t_s,'+','.join('TC'+str(i) for i in range(1,9))+'\n0,'+','.join(['99']*8)
                    connection.request('POST','/api/measurements/flatten',json.dumps({'text':text}),{'X-App-Token':token})
                    response=connection.getresponse();return response.status,json.loads(response.read())
                finally:connection.close()
            try:
                self.assertEqual(request('')[0],403)
                status,data=request(server.token);self.assertEqual(status,200)
                self.assertEqual(data['report']['sample_count'],1)
                self.assertTrue(data['csv_text'].startswith('t_s,TC1'))
                self.assertIsNone(server.session.controller)
            finally:server.shutdown();server.server_close();thread.join(3)
