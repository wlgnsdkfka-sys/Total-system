import http.client
import io
import json
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

from boiling_automation.gui import GuiServer, GuiSession


def replay(**overrides):
    text = 't_s,TC1,TC2,TC3,TC4,TC5,TC6,TC7,TC8\n' + '\n'.join(
        str(t) + ',25,25,25,25,25,25,25,25' for t in range(91))
    return {'source': 'csv', 'csv_text': text, 'critical_c': 100,
            'allowed_std_c': .1, 'max_power_percent': 0, 'speed': 300, **overrides}


class StandbyTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.session = GuiSession(Path(self.temporary.name) / 'results')

    def tearDown(self):
        self.session.calibration_capture = None
        self.session.stop()
        if self.session.worker:
            self.session.worker.join(5)
        self.temporary.cleanup()

    def finish(self, settings=None):
        self.session.start(settings or replay())
        self.session.worker.join(5)
        self.assertFalse(self.session.worker.is_alive())
        return self.session.snapshot()

    def reset(self, state):
        return self.session.return_to_standby({'run_name': state['run_name']})

    def test_completed_run_keeps_records_graphs_and_exported_measurements(self):
        finished = self.finish()
        folder = Path(finished['result_folder'])
        files = {p.name: p.read_bytes() for p in folder.iterdir() if p.is_file()}
        record = self.session.record(0)
        idle = self.reset(finished)
        self.assertEqual(idle['state'], 'idle')
        self.assertEqual(idle['last_run_state'], 'completed')
        self.assertTrue(idle['standby'])
        self.assertEqual(idle['elapsed_s'], 0)
        self.assertEqual(idle['step_elapsed_s'], 0)
        self.assertTrue(all(v['state'] == 'off' for v in idle['indicators'].values()))
        for field in ('records', 'history', 'std_history', 'measurement_sample_count',
                      'run_name', 'config', 'run_calculation_settings'):
            self.assertEqual(idle[field], finished[field], field)
        self.assertEqual(self.session.record(0), record)
        self.assertEqual(files, {p.name: p.read_bytes() for p in folder.iterdir() if p.is_file()})
        body, _ = self.session.export(idle['run_name'])
        with zipfile.ZipFile(io.BytesIO(body)) as archive:
            for name in ('measurements_raw.csv', 'measurements_tab4.csv', 'measurements_tab3.csv', 'stages.csv'):
                self.assertEqual(archive.read(name), files[name])

    def test_tripped_reset_preserves_interlock_and_sends_no_hardware_commands(self):
        settings = replay()
        settings['critical_c'] = 24
        finished = self.finish(settings)
        self.assertEqual(finished['state'], 'tripped')
        self.assertEqual(finished['manual_controls']['shutter']['inhibit_reason'], 'critical_temperature')
        with patch.object(self.session.manual_controls, 'request_close') as close, \
                patch.object(self.session.manual_controls, 'open') as open_shutter, \
                patch.object(self.session.manual_controls, 'clear_interlock') as rearm:
            idle = self.reset(finished)
        close.assert_not_called()
        open_shutter.assert_not_called()
        rearm.assert_not_called()
        self.assertIsNone(idle['reason'])
        self.assertEqual(idle['manual_controls']['shutter']['inhibit_reason'], 'critical_temperature')
        self.assertEqual(self.session.reason, 'critical_temperature')

    def test_reset_rejects_active_experiment_and_active_calibration(self):
        self.session.start(replay(speed=1))
        with self.assertRaisesRegex(ValueError, '먼저 중지'):
            self.reset(self.session.snapshot())
        self.session.stop()
        self.session.worker.join(5)
        finished = self.session.snapshot()
        self.session.calibration_capture = SimpleNamespace(active=True)
        with self.assertRaisesRegex(ValueError, '먼저 중지'):
            self.reset(finished)

    def test_run_guard_and_idempotent_reset_prevent_stale_ui_actions(self):
        with self.assertRaises(ValueError):
            self.session.return_to_standby({})
        finished = self.finish()
        with self.assertRaisesRegex(ValueError, '실험이 변경'):
            self.session.return_to_standby({'run_name': 'old-run'})
        idle = self.reset(finished)
        self.assertGreater(idle['generation'], finished['generation'])
        self.assertGreater(idle['operation_revision'], finished['operation_revision'])
        self.assertEqual(self.reset(idle)['generation'], idle['generation'])

    def test_new_run_leaves_standby_without_overwriting_previous_run(self):
        finished = self.finish()
        folder = Path(finished['result_folder'])
        original = (folder / 'measurements_raw.csv').read_bytes()
        self.reset(finished)
        current = self.session.start(replay(speed=1))
        self.assertFalse(current['standby'])
        self.assertTrue(current['running'])
        self.assertNotEqual(current['run_name'], finished['run_name'])
        self.assertEqual((folder / 'measurements_raw.csv').read_bytes(), original)
        self.assertEqual(current['records'], [])


class StandbyHttpTests(unittest.TestCase):
    def test_route_requires_local_app_token_and_current_run(self):
        with tempfile.TemporaryDirectory() as folder:
            server = GuiServer(('127.0.0.1', 0), Path(folder) / 'results')
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            def request(token, data):
                connection = http.client.HTTPConnection(*server.server_address, timeout=5)
                try:
                    connection.request('POST', '/api/standby', json.dumps(data),
                                       {'X-App-Token': token})
                    response = connection.getresponse()
                    return response.status, json.loads(response.read())
                finally:
                    connection.close()
            try:
                server.session.start(replay())
                server.session.worker.join(5)
                finished = server.session.snapshot()
                self.assertEqual(request('', {'run_name': finished['run_name']})[0], 403)
                self.assertEqual(request(server.token, {'run_name': 'old-run'})[0], 400)
                status, state = request(server.token, {'run_name': finished['run_name']})
                self.assertEqual(status, 200)
                self.assertEqual(state['state'], 'idle')
                self.assertTrue(state['standby'])
            finally:
                server.shutdown()
                server.server_close()
                thread.join(5)


if __name__ == '__main__':
    unittest.main()
