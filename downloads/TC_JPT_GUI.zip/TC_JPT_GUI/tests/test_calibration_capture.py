import csv
from dataclasses import asdict
import hashlib
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile

from boiling_automation.calibration_capture import CalibrationCapture,CaptureConfig
from boiling_automation.core import Reading
from boiling_automation.gui import GuiServer,GuiSession
from boiling_automation.temperature_calibration import TemperatureCalibration,ReferenceEvidence


def reading(t,values=None):
    v=values if values is not None else [99+i*.1 for i in range(12)]
    return Reading(float(t),tuple(v[:8]),bulk_temperatures_c=tuple(v[8:]))

def text(seconds,values=None):
    return 't_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n'+'\n'.join(str(t)+','+','.join(str(v) for v in (values(t) if values else [99+i*.1 for i in range(12)])) for t in range(seconds+1))


class StableWindowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.c=CalibrationCapture(Path(self.temp.name)/'capture',CaptureConfig(),'csv',300)
    def tearDown(self):self.c.close();self.temp.cleanup()
    def test_never_eligible_before_full_three_minutes(self):
        for t in range(180):
            self.c.observe(reading(t));self.assertFalse(self.c.stable)
        with self.assertRaises(ValueError):self.c.select_reference()
        self.c.observe(reading(180));self.assertTrue(self.c.stable)
        selected=self.c.select_reference()
        self.assertEqual(selected['reference_raw_c'],[99+i*.1 for i in range(12)])
        self.assertEqual(selected['evidence']['sample_count'],181)
    def test_all_channels_including_bulk_must_satisfy_both_thresholds(self):
        for t in range(181):
            v=[100.]*12;v[11]=100+(1 if t%2 else 0)
            self.c.observe(reading(t,v))
        self.assertFalse(self.c.stable)
        self.assertGreater(self.c.stats['ranges_c'][11],self.c.config.allowed_range_c)
        with self.assertRaises(ValueError):self.c.select_reference()
    def test_slow_drift_that_passes_sigma_can_fail_range(self):
        self.c.config=CaptureConfig(180,1,.5)
        for t in range(181):self.c.observe(reading(t,[100+t*.004]*12))
        self.assertLess(max(self.c.stats['std_c']),1)
        self.assertFalse(self.c.stable)
    def test_spike_requires_an_entire_new_stable_window(self):
        for t in range(360):
            v=[100.]*12
            if t==179:v[8]=102
            self.c.observe(reading(t,v))
            if t>=179:self.assertFalse(self.c.stable)
        self.c.observe(reading(360,[100.]*12));self.assertTrue(self.c.stable)
    def test_continues_past_five_minutes_and_archives_all_raw_samples(self):
        for t in range(601):self.c.observe(reading(t))
        self.assertTrue(self.c.active);self.assertTrue(self.c.stable)
        selected=self.c.select_reference();self.c.finish('input_ended')
        body,name=self.c.export()
        with zipfile.ZipFile(io.BytesIO(body)) as z:
            rows=list(csv.DictReader(io.StringIO(z.read('raw_samples.csv').decode())))
            self.assertEqual(len(rows),601)
            self.assertEqual({r['power_index_percent'] for r in rows},{'-1'})
            ev=selected['evidence'];samples=z.read('reference_'+ev['reference_id']+'.csv')
            self.assertEqual(hashlib.sha256(samples).hexdigest(),ev['samples_sha256'])
            self.assertEqual((ev['start_s'],ev['end_s']),(420,600))
    def test_selected_references_are_immutable_when_later_temperatures_drift(self):
        for t in range(181):self.c.observe(reading(t))
        selected=self.c.select_reference();old=self.c.references[selected['reference_id']]
        self.c.observe(reading(181,[105]*12))
        self.assertFalse(self.c.stable)
        self.assertEqual(old.means_c[0],99)
        self.assertEqual(self.c.references[selected['reference_id']],old)
    def test_normal_stop_preserves_valid_window_emergency_or_error_invalidates(self):
        for t in range(181):self.c.observe(reading(t))
        self.c.finish('user_stop');self.assertTrue(self.c.stable)
        self.assertEqual(self.c.select_reference()['evidence']['window_s'],180)
    def test_error_with_empty_message_cannot_preserve_stable_status(self):
        for t in range(181):self.c.observe(reading(t))
        self.c.finish('capture_error',ValueError())
        self.assertFalse(self.c.stable);self.assertTrue(self.c.error)
        with self.assertRaises(ValueError):self.c.select_reference()
    def test_fractional_boundary_statistics_cover_exact_window(self):
        for t in range(183):self.c.observe(reading(t*.995))
        e=self.c.select_reference()['evidence']
        self.assertAlmostEqual(e['end_s']-e['start_s'],180)
        samples=(self.c.directory/('reference_'+e['reference_id']+'.csv')).read_text()
        self.assertEqual(list(csv.DictReader(io.StringIO(samples)))[0]['interpolated'],'1')
    def test_export_freezes_complete_rows_while_measurement_keeps_appending(self):
        for t in range(10):self.c.observe(reading(t))
        frozen=self.c.prepare_export()
        for t in range(10,20):self.c.observe(reading(t))
        with zipfile.ZipFile(io.BytesIO(self.c.export_snapshot(frozen))) as z:
            rows=list(csv.DictReader(io.StringIO(z.read('raw_samples.csv').decode())))
            self.assertEqual(len(rows),10)
            self.assertEqual(json.loads(z.read('capture.json'))['sample_count'],10)
        self.assertEqual(self.c.count,20)
    def test_invalid_samples_and_configuration_are_rejected(self):
        for cfg in ({'window_s':179},{'window_s':3601},{'allowed_std_c':-1},{'allowed_range_c':float('nan')},{'max_gap_s':3}):
            with self.assertRaises(ValueError):CaptureConfig(**cfg)
        self.c.observe(reading(0))
        for r in (reading(0),reading(3),reading(1,[None]*12),Reading(1,(100,)*8)):
            with self.assertRaises(ValueError):self.c.observe(r)


class CaptureSessionTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.s=GuiSession(Path(self.temp.name))
    def tearDown(self):
        self.s.stop()
        for w in (self.s.worker,self.s.capture_worker):
            if w and w.is_alive():w.join(5)
        self.temp.cleanup()
    def run_capture(self,seconds=180,values=None,**extra):
        self.s.start_calibration_capture({'source':'csv','csv_text':text(seconds,values),'speed':300,**extra})
        self.s.capture_worker.join(10);self.assertFalse(self.s.capture_worker.is_alive())
        return self.s.snapshot()
    def test_capture_never_starts_experiment_or_emission_and_saves_evidence(self):
        snapshot=self.run_capture();cap=snapshot['calibration_capture']
        self.assertIsNone(self.s.controller);self.assertFalse(snapshot['running'])
        self.assertEqual(snapshot['power_index_percent'],-1)
        self.assertTrue(cap['stable']);self.assertEqual(cap['reason'],'input_ended')
        ref=self.s.select_calibration_reference({'capture_id':cap['capture_id']})
        saved=self.s.save_temperature_calibration({'action':'apply','reference_raw_c':ref['reference_raw_c'],
           'expected_profile_id':'uncalibrated','source':ref['source'],'capture_id':cap['capture_id'],
           'selected_reference_id':ref['reference_id'],'require_stable_reference':True})
        self.assertEqual(saved['reference_evidence']['window_s'],180)
        restored=GuiSession(Path(self.temp.name))
        self.assertEqual(restored.temperature_calibration.reference_evidence.reference_id,ref['reference_id'])
        corrected=restored.temperature_calibration.apply(reading(200))
        self.assertEqual(corrected.temperatures_c,(100,)*8)
    def test_measured_save_refuses_unverified_manual_values(self):
        with self.assertRaises(ValueError):
            self.s.save_temperature_calibration({'action':'apply','reference_raw_c':[99]*12,
                'expected_profile_id':'uncalibrated','require_stable_reference':True})
        self.assertFalse(self.s.temperature_calibration.enabled)
    def test_short_csv_never_produces_a_three_minute_reference(self):
        cap=self.run_capture(179)['calibration_capture'];self.assertFalse(cap['stable'])
        with self.assertRaises(ValueError):self.s.select_calibration_reference({'capture_id':cap['capture_id']})
    def test_mutual_exclusion_and_global_stop(self):
        with patch.object(threading.Thread,'start'):
            a=self.s.start_calibration_capture({'source':'demo'})
        self.s.capture_worker=None
        with self.assertRaises(ValueError):self.s.start({'critical_c':100})
        with self.assertRaises(ValueError):self.s.start_calibration_capture({'source':'demo'})
        self.s.stop('emergency_stop');self.assertFalse(self.s.calibration_capture.active)
        self.assertEqual(self.s.calibration_capture.reason,'emergency_stop')
        with patch.object(threading.Thread,'start'):self.s.start({'critical_c':100})
        self.s.worker=None
        with self.assertRaises(ValueError):self.s.start_calibration_capture({'source':'demo'})
    def test_stale_capture_id_cannot_stop_or_select_another_capture(self):
        self.run_capture()
        for fn in (self.s.stop_calibration_capture,self.s.select_calibration_reference):
            with self.assertRaises(ValueError):fn({'capture_id':'old-capture'})
    def test_invalid_channel_data_stops_and_disqualifies_reference(self):
        cap=self.run_capture(181,lambda t:[100]*11+[float('nan') if t==181 else 100])['calibration_capture']
        self.assertEqual(cap['reason'],'capture_error');self.assertTrue(cap['error']);self.assertFalse(cap['stable'])
        with self.assertRaises(ValueError):self.s.select_calibration_reference({'capture_id':cap['capture_id']})
    def test_adjusted_means_cannot_reuse_selected_evidence(self):
        cap=self.run_capture()['calibration_capture'];ref=self.s.select_calibration_reference({'capture_id':cap['capture_id']})
        raw=ref['reference_raw_c'];raw[0]+=1
        with self.assertRaises(ValueError):self.s.save_temperature_calibration({'action':'apply','reference_raw_c':raw,
            'expected_profile_id':'uncalibrated','selected_reference_id':ref['reference_id'],'capture_id':cap['capture_id']})
    def test_recording_failure_stops_capture_and_prevents_reference(self):
        with patch.object(threading.Thread,'start'):self.s.start_calibration_capture({'source':'demo'})
        self.s.capture_worker=None;c=self.s.calibration_capture
        with patch.object(c,'observe',side_effect=OSError('disk full')):
            self.s._run_calibration_capture(c,self.s.capture_cancel,'',None)
        self.assertFalse(c.active);self.assertFalse(c.stable);self.assertIn('disk full',c.error)

class CaptureHttpTests(unittest.TestCase):
    def test_capture_routes_require_token_and_export_measured_reference(self):
        import http.client
        with tempfile.TemporaryDirectory() as folder:
            server=GuiServer(('127.0.0.1',0),Path(folder));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            def request(method,path,payload=None,token=None):
                c=http.client.HTTPConnection('127.0.0.1',server.server_address[1],timeout=5)
                headers={'Content-Type':'application/json'}
                if token:headers['X-App-Token']=token
                try:
                    c.request(method,path,json.dumps(payload) if payload is not None else None,headers)
                    r=c.getresponse();return r.status,r.read()
                finally:c.close()
            try:
                self.assertEqual(request('GET','/calibration-capture.js')[0],200)
                self.assertEqual(request('GET','/api/calibration-capture/ni-defaults')[0],200)
                payload={'source':'csv','csv_text':text(180),'speed':300}
                self.assertEqual(request('POST','/api/calibration-capture/start',payload)[0],403)
                code,body=request('POST','/api/calibration-capture/start',payload,server.token)
                self.assertEqual(code,200);capture_id=json.loads(body)['calibration_capture']['capture_id']
                self.assertEqual(request('POST','/api/calibration-capture/select',{'capture_id':capture_id},server.token)[0],400)
                server.session.capture_worker.join(10)
                self.assertFalse(server.session.capture_worker.is_alive())
                code,body=request('POST','/api/calibration-capture/select',{'capture_id':capture_id},server.token)
                self.assertEqual(code,200);self.assertEqual(json.loads(body)['evidence']['window_s'],180)
                code,body=request('GET','/api/calibration-capture/export')
                self.assertEqual(code,200)
                with zipfile.ZipFile(io.BytesIO(body)) as z:
                    self.assertIn('raw_samples.csv',z.namelist())
                    self.assertEqual(len(list(csv.DictReader(io.StringIO(z.read('raw_samples.csv').decode())))),181)
            finally:
                server.session.stop()
                if server.session.capture_worker:server.session.capture_worker.join(5)
                server.shutdown();server.server_close();thread.join(5)
