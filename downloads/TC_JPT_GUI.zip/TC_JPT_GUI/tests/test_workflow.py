"""Five-tab workflow: separate capture purposes, frozen settings, calibrated curves."""
from dataclasses import asdict
import io,json,math,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
from boiling_automation.gui import GuiSession
from boiling_automation.calibration_capture import CalibrationCapture,CaptureConfig
from boiling_automation.core import Reading
from boiling_automation.calculation import default_settings,calculate_reading
from boiling_automation.initial_calibration import CalibrationDataset,CalibrationPoint
from boiling_automation.leak import LeakConfig


def table(seconds=90):
    return 't_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n'+'\n'.join(str(t)+','+','.join(str(v) for v in range(100,112)) for t in range(seconds+1))

class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.s=GuiSession(Path(self.tmp.name))
    def tearDown(self):
        self.s.stop()
        for w in (self.s.worker,self.s.capture_worker):
            if w and w.is_alive():w.join(5)
        self.tmp.cleanup()
    def capture(self,purpose,base=99):
        cap=CalibrationCapture(self.s.results_root/('capture_'+purpose),CaptureConfig(),'csv',300,{},purpose)
        for t in range(181):cap.observe(Reading(t,(base,)*8,bulk_temperatures_c=(base,)*4))
        cap.finish('input_ended');self.s.calibration_captures[purpose]=cap;self.s.calibration_capture=cap
        return cap
    def start_replay(self,speed=300):
        return self.s.start({'source':'csv','csv_text':table(),'critical_c':1000,'allowed_std_c':.1,'max_power_percent':0,'speed':speed})
    def test_purposes_keep_separate_last_results_and_export(self):
        furnace=self.capture('furnace',130);offset=self.capture('offset',99)
        state=self.s.snapshot();self.assertEqual(state['calibration_captures']['furnace']['latest']['values_c'],(130,)*12)
        self.assertEqual(state['calibration_captures']['offset']['latest']['values_c'],(99,)*12)
        body,name=self.s.export_calibration_capture('furnace')
        self.assertEqual(name,furnace.capture_id+'.zip')
        with zipfile.ZipFile(io.BytesIO(body)) as z:self.assertEqual(json.loads(z.read('capture.json'))['purpose'],'furnace')
        self.s.stop_calibration_capture({'capture_id':furnace.capture_id})
        self.assertIs(self.s.calibration_capture,offset)
    def test_furnace_cannot_be_selected_as_experiment_offset(self):
        cap=self.capture('furnace')
        with self.assertRaisesRegex(ValueError,'3번'):self.s.select_calibration_reference({'capture_id':cap.capture_id})
        ref=cap.select_reference()
        with self.assertRaises(ValueError):self.s.save_temperature_calibration({'action':'apply','reference_raw_c':[99]*12,
          'reference_c':100,'expected_profile_id':'uncalibrated','capture_id':cap.capture_id,'selected_reference_id':ref['reference_id']})
    def test_offset_cannot_be_added_as_furnace_point(self):
        cap=self.capture('offset');ds=self.s.initial_dataset
        with self.assertRaisesRegex(ValueError,'4번'):self.s.update_initial_data({'action':'add_capture','capture_id':cap.capture_id,
          'reference_c':100,'expected_dataset_id':ds.dataset_id,'expected_revision':ds.revision})
    def test_old_offset_reference_remains_usable_after_furnace_capture(self):
        offset=self.capture('offset');ref=self.s.select_calibration_reference({'capture_id':offset.capture_id})
        self.capture('furnace',130)
        self.s.save_temperature_calibration({'action':'apply','reference_raw_c':[99]*12,'reference_c':100,
          'expected_profile_id':'uncalibrated','capture_id':offset.capture_id,'selected_reference_id':ref['reference_id']})
        self.assertEqual(self.s.temperature_calibration.offsets_c,(1,)*12)
    def test_two_capture_purposes_and_experiment_are_mutually_exclusive(self):
        with patch('threading.Thread.start'):
            self.s.start_calibration_capture({'purpose':'furnace','source':'demo','demo_reference_c':130})
        with self.assertRaises(ValueError):self.s.start_calibration_capture({'purpose':'offset','source':'demo'})
        with self.assertRaises(ValueError):self.start_replay()
        self.assertEqual(self.s.snapshot()['power_index_percent'],-1)
        self.assertEqual(self.s.calibration_capture.demo_reference_c,130)
    def test_invalid_purpose_does_not_start_acquisition(self):
        with self.assertRaises(ValueError):self.s.start_calibration_capture({'purpose':'wrong','source':'demo'})
        self.assertIsNone(self.s.calibration_capture)
    def test_saving_constants_mid_run_keeps_monitor_and_metadata_frozen(self):
        original=self.s.calculation_settings
        self.start_replay(1);changed=default_settings();changed['saturation_c']=95;changed['bands'][0]['conductivity_w_mk']=800
        self.s.save_settings(changed)
        self.assertEqual(self.s.controller.flux_monitor.settings,original)
        self.assertEqual(self.s.run_calculation_settings,original)
        state=self.s.snapshot();self.assertTrue(state['calculation_settings_pending']);self.assertEqual(state['saturation_c'],100)
        metadata=json.loads((self.s.writer.directory/'run.json').read_text())
        self.assertEqual(metadata['calculation_settings'],original)
        restored=GuiSession(self.s.results_root);self.assertEqual(restored.calculation_settings,changed)
    def test_default_curve_uses_run_constants_latest_source_explicitly_recalculates(self):
        self.start_replay();self.s.worker.join(5)
        original=self.s.curve_from_records()['curve']
        changed=default_settings();changed['saturation_c']=95
        for b in changed['bands']:b['conductivity_w_mk']*=2
        self.s.save_settings(changed)
        frozen=self.s.curve_from_records()['curve'];latest=self.s.curve_from_records({'settings_source':'saved'})['curve']
        self.assertEqual(frozen['points'],original['points'])
        self.assertAlmostEqual(latest['points'][0]['heat_flux_w_cm2'],2*frozen['points'][0]['heat_flux_w_cm2'])
        self.assertAlmostEqual(latest['points'][0]['superheat_c'],frozen['points'][0]['superheat_c']+5)
        self.assertEqual(latest['settings_source'],'saved');self.assertEqual(frozen['record_count'],1)
    def test_next_run_uses_new_constants_without_changing_previous_output(self):
        self.start_replay();self.s.worker.join(5);old=self.s.writer.directory
        changed=default_settings();changed['saturation_c']=95;self.s.save_settings(changed)
        self.start_replay();self.s.worker.join(5)
        self.assertEqual(self.s.run_calculation_settings['saturation_c'],95)
        self.assertEqual(json.loads((old/'run.json').read_text())['calculation_settings']['saturation_c'],100)
    def test_stale_run_curve_request_and_export_are_rejected(self):
        self.start_replay();self.s.worker.join(5)
        with self.assertRaises(ValueError):self.s.curve_from_records({'expected_run_name':'old'})
        old=self.s.curve_from_records()['curve'];self.s.curve_from_records()
        with self.assertRaises(ValueError):self.s.export_curve(old['curve_id'])
        self.assertTrue(self.s.export_curve(self.s.curve['curve_id']))
    def test_changed_flux_formula_requires_new_confirmation_before_next_run(self):
        config=asdict(LeakConfig(enabled=True,calibration_confirmed=True))
        self.s.save_leak_settings(config)
        self.start_replay(1)
        changed=default_settings();changed['flux_sign']=-1;self.s.save_settings(changed)
        self.assertTrue(self.s.snapshot()['leak_confirmation_required'])
        self.assertEqual(self.s.controller.flux_monitor.settings['flux_sign'],1)
        self.s.stop();self.s.worker.join(5)
        with self.assertRaisesRegex(ValueError,'계산식'):self.start_replay()
        restored=GuiSession(self.s.results_root);self.assertTrue(restored.snapshot()['leak_confirmation_required'])
        self.s.save_leak_settings(config);self.assertFalse(self.s.snapshot()['leak_confirmation_required'])
        self.start_replay();self.s.worker.join(5);self.assertEqual(self.s.run_calculation_settings['flux_sign'],-1)
    def test_saturation_only_change_does_not_invalidate_flux_confirmation(self):
        self.s.save_leak_settings(asdict(LeakConfig(enabled=True,calibration_confirmed=True)))
        changed=default_settings();changed['saturation_c']=95;self.s.save_settings(changed)
        self.assertFalse(self.s.snapshot()['leak_confirmation_required'])
    def test_full_furnace_then_offset_then_record_and_curve_use_final_temperatures(self):
        ds=self.s.initial_dataset
        points=tuple(CalibrationPoint('p'+str(i),v,((v+2)/1.1,)*12,'test','') for i,v in enumerate((99,100,110,120,130)))
        self.s.update_initial_data({'action':'import','format':'json','text':json.dumps(CalibrationDataset('furnace',0,points).to_dict()),
           'expected_dataset_id':ds.dataset_id,'expected_revision':ds.revision})
        ds=self.s.initial_dataset;expected={'expected_dataset_id':ds.dataset_id,'expected_revision':ds.revision}
        self.s.fit_initial_data(expected)
        self.s.activate_initial_calibration({**expected,'action':'apply','fit_id':self.s.initial_fit.profile_id,'expected_profile_id':'uncalibrated'})
        initial=self.s.temperature_calibration.initial_calibration
        self.s.save_temperature_calibration({'action':'apply','reference_raw_c':[104/1.1]*12,'reference_c':100,
            'expected_profile_id':self.s.temperature_calibration.profile_id})
        self.assertAlmostEqual(self.s.temperature_calibration.offsets_c[0],-2)
        self.start_replay();self.s.worker.join(5)
        final=tuple(1.1*v-4 for v in range(100,112))
        for actual,expected in zip((*self.s.last_reading.temperatures_c,*self.s.last_reading.bulk_temperatures_c),final):self.assertAlmostEqual(actual,expected)
        c=self.s.curve_from_records()['curve'];surface,flux=calculate_reading(Reading(0,final[:8],bulk_temperatures_c=final[8:]),self.s.run_calculation_settings)
        self.assertAlmostEqual(c['points'][0]['surface_temp_c'],surface);self.assertAlmostEqual(c['points'][0]['heat_flux_w_cm2'],flux)
        self.assertEqual(self.s.temperature_calibration.initial_calibration,initial)
        self.assertEqual(c['temperature_calibration']['initial_calibration']['profile_id'],initial.profile_id)

if __name__=='__main__':unittest.main()
