"""Separate, aligned full streams and reproducible calibration provenance."""
from dataclasses import replace
import csv,io,json,math,tempfile,threading,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
from boiling_automation.core import Reading,Event
from boiling_automation.initial_calibration import CalibrationDataset,CalibrationPoint,fit_dataset
from boiling_automation.temperature_calibration import TemperatureCalibration
from boiling_automation.measurement_data import MeasurementLog,MEASUREMENT_FILES,MEASUREMENT_COLUMNS
from boiling_automation.gui import GuiSession,GuiServer,csv_readings
import http.client

BULK=(98.7,99.2,97.9,99.9)
def calibration(initial=True,offset=True):
    points=tuple(CalibrationPoint('p'+str(j),ref,tuple((ref+2-i*.1)/(1.1+i*.01) for i in range(8)),'test','')
                 for j,ref in enumerate((99.,110.,130.)))
    model=fit_dataset(CalibrationDataset('testdata',0,points)) if initial else None
    raw=tuple((102+2-i*.1)/(1.1+i*.01) if initial else 102. for i in range(8))+BULK
    delta=tuple(100-(model.correct(v,i) if model and i<8 else v) for i,v in enumerate(raw))
    return TemperatureCalibration(offset,100,raw,delta,'frozen',initial_calibration=model)

def input_values(t=0):return tuple((112+i*.2+t*.001+2-i*.1)/(1.1+i*.01) for i in range(8))+tuple(v+.5 for v in BULK)
def source_csv(seconds=90,start=0,step=1,bulk=True,hot=None):
    rows=['t_s,'+','.join('TC'+str(i) for i in range(1,13 if bulk else 9))]
    for j in range(int(seconds/step)+1):
        t=start+j*step;values=list(input_values(j*step))
        if hot is not None and j==hot:values[3]=calibration().raw_for_corrected(201,3)
        rows.append(str(t)+','+','.join(str(v) for v in values[:12 if bulk else 8]))
    return '\n'.join(rows)+'\n'
def rows(body):return list(csv.DictReader(io.StringIO(body.decode('utf-8'))))

class MeasurementTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.s=GuiSession(Path(self.tmp.name));self.s.temperature_calibration=calibration()
    def tearDown(self):
        self.s.stop()
        if self.s.worker and self.s.worker.is_alive():self.s.worker.join(5)
        self.tmp.cleanup()
    def start(self,**extra):return self.s.start({'source':'csv','csv_text':source_csv(),'critical_c':200,'allowed_std_c':.1,'max_power_percent':0,'speed':300,**extra})
    def complete(self,**extra):
        self.start(**extra);self.s.worker.join(5);self.assertFalse(self.s.worker.is_alive());return self.s.snapshot()
    def data(self):return {basis:rows(self.s.export_measurements(basis)[0]) for basis in MEASUREMENT_FILES}
    def assert_aligned(self,data,count):
        for basis,series in data.items():
            self.assertEqual(len(series),count);self.assertEqual([int(r['sample_id']) for r in series],list(range(count)))
            self.assertTrue(all(r['temperature_basis']==basis for r in series))
        for i in range(count):
            common=[{k:v for k,v in data[basis][i].items() if k not in ('temperature_basis',*('TC'+str(j) for j in range(1,13)))} for basis in data]
            self.assertEqual(common[0],common[1]);self.assertEqual(common[1],common[2])
    def test_all_samples_are_separate_and_aligned_with_nonidentity_gain_and_offset(self):
        state=self.complete();data=self.data();self.assert_aligned(data,91)
        self.assertEqual(state['measurement_sample_count'],91)
        self.assertEqual(float(data['raw'][0]['TC1']),input_values()[0])
        self.assertAlmostEqual(float(data['tab4'][0]['TC1']),112)
        self.assertAlmostEqual(float(data['tab3'][0]['TC1']),110)
        for i in range(9,13):
            self.assertEqual(data['raw'][0]['TC'+str(i)],data['tab4'][0]['TC'+str(i)])
            self.assertAlmostEqual(float(data['tab3'][0]['TC'+str(i)]),100.5)
        self.assertEqual(data['tab3'][-1]['power_index_after_sample_percent'],'-1')
        self.assertEqual(data['tab3'][-1]['stop_reason'],'maximum_output_reached')
    def test_zip_has_three_full_files_existing_selected_interval_and_snapshot_counts(self):
        self.complete();body,_=self.s.export()
        with zipfile.ZipFile(io.BytesIO(body)) as z:
            self.assertEqual(len(rows(z.read('selected_samples.csv'))),21)
            snapshot=json.loads(z.read('data_snapshot.json'));self.assertEqual(snapshot['sample_count'],91)
            for name in MEASUREMENT_FILES.values():
                self.assertEqual(len(rows(z.read(name))),91)
                self.assertEqual(snapshot['files'][name]['committed_bytes'],len(z.read(name)))
            self.assertIn('TC1_tab4_c',rows(z.read('selected_samples.csv'))[0])
            self.assertIn('DATA_FORMAT.md',z.namelist())
            meta=json.loads(z.read('run.json'));self.assertEqual(len(meta['measurement_files']),3)
            self.assertEqual(meta['temperature_calibration']['profile_id'],'frozen')
            self.assertEqual(len(meta['temperature_calibration']['initial_calibration']['points']),3)
    def test_every_stage_transition_has_unambiguous_before_and_after_power(self):
        self.complete(csv_text=source_csv(180),max_power_percent=1)
        data=self.data();self.assert_aligned(data,181)
        self.assertEqual(data['raw'][90]['power_percent'],'0');self.assertEqual(data['raw'][90]['power_index_after_sample_percent'],'1')
        self.assertEqual(data['raw'][91]['power_percent'],'1');self.assertEqual(data['raw'][180]['power_index_after_sample_percent'],'-1')
    def test_nonzero_source_time_uses_same_elapsed_origin_in_all_files(self):
        self.complete(csv_text=source_csv(start=1000));data=self.data();self.assert_aligned(data,91)
        self.assertEqual(float(data['raw'][0]['t_s']),1000);self.assertEqual(float(data['raw'][0]['elapsed_s']),0)
        self.assertEqual(float(data['raw'][-1]['elapsed_s']),90)
    def test_selected_boundary_interpolation_has_raw_furnace_and_final_columns(self):
        self.complete(csv_text=source_csv(step=1.5))
        selected=rows((self.s.writer.directory/'selected_samples.csv').read_bytes())
        self.assertTrue(any(r['interpolated']=='True' for r in selected))
        p=self.s.run_temperature_calibration
        for row in selected:
            for i in range(12):
                raw=float(row[f'TC{i+1}_raw_c']);base=float(row[f'TC{i+1}_tab4_c']);final=float(row[f'TC{i+1}'])
                self.assertAlmostEqual(base,p.initial_value(raw,i));self.assertAlmostEqual(final,p.correct_value(raw,i))
    def test_disabled_calibration_views_are_identical_when_appropriate(self):
        for initial,offset in ((False,False),(True,False),(False,True)):
            self.s.temperature_calibration=calibration(initial,offset)
            self.complete();data=self.data()
            for i in range(1,13):
                if not initial or i>=9:self.assertEqual(data['raw'][0]['TC'+str(i)],data['tab4'][0]['TC'+str(i)])
                if not offset:self.assertEqual(data['tab4'][0]['TC'+str(i)],data['tab3'][0]['TC'+str(i)])
    def test_bulk_missing_channels_are_empty_in_every_view(self):
        self.complete(csv_text=source_csv(bulk=False));data=self.data()
        for series in data.values():self.assertTrue(all(row['TC'+str(i)]=='' for row in series for i in range(9,13)))
    def test_critical_triggering_sample_survives_even_without_completed_stage(self):
        self.complete(csv_text=source_csv(10,hot=4));data=self.data();self.assert_aligned(data,5)
        self.assertEqual(self.s.reason,'critical_temperature');self.assertEqual(self.s.controller.records,[])
        self.assertAlmostEqual(float(data['tab3'][-1]['TC4']),201)
        self.assertEqual(data['tab3'][-1]['sample_status'],'ok');self.assertEqual(data['tab3'][-1]['stop_reason'],'critical_temperature')
    def test_early_user_stop_keeps_samples_before_the_first_ninety_second_record(self):
        written=threading.Event();original=MeasurementLog.write
        def write(log,*args):original(log,*args);written.set()
        with patch.object(MeasurementLog,'write',write):
            self.start(speed=1);self.assertTrue(written.wait(2));self.s.stop();self.s.worker.join(5)
        count=self.s.writer.measurements.count;self.assertGreater(count,0);self.assertLess(count,90)
        self.assert_aligned(self.data(),count);self.assertEqual(self.s.controller.records,[])
    def test_rejected_numeric_input_is_preserved_with_status_and_consistent_rows(self):
        text=source_csv(2).replace(str(input_values()[0]),'nan',1)
        self.complete(csv_text=text);data=self.data();self.assert_aligned(data,1)
        self.assertEqual(data['raw'][0]['TC1'],'nan');self.assertEqual(data['raw'][0]['sample_status'],'invalid_temperature_data')
        with zipfile.ZipFile(io.BytesIO(self.s.export()[0])) as z:json.loads(z.read('data_snapshot.json'))
    def test_raw_can_be_replayed_but_furnace_and_final_do_not_double_apply_corrections(self):
        self.complete()
        raw=self.s.export_measurements('raw')[0].decode();p=next(csv_readings(raw));self.assertAlmostEqual(p.temperatures_c[0],input_values()[0])
        for basis in ('tab4','tab3'):
            with self.assertRaisesRegex(ValueError,'원시'):next(csv_readings(self.s.export_measurements(basis)[0].decode()))
    def test_profile_changes_after_run_do_not_change_any_saved_values(self):
        self.complete();before={basis:self.s.export_measurements(basis)[0] for basis in MEASUREMENT_FILES}
        self.s.save_temperature_calibration({'action':'disable','expected_profile_id':self.s.temperature_calibration.profile_id})
        for basis in MEASUREMENT_FILES:self.assertEqual(self.s.export_measurements(basis)[0],before[basis])
        meta=json.loads((self.s.writer.directory/'run.json').read_text());self.assertTrue(meta['temperature_calibration']['enabled'])
    def test_failed_row_rolls_back_all_three_files_to_last_committed_sample(self):
        self.complete(csv_text=source_csv(1))
        # Use a fresh live writer for an isolated disk-failure transaction.
        directory=self.s.results_root/'transaction';directory.mkdir()
        log=MeasurementLog(directory,self.s.temperature_calibration,flush_interval_s=0);p=self.s.temperature_calibration.apply(Reading(0,input_values()[:8],bulk_temperatures_c=input_values()[8:]))
        class FailWrite:
            def __init__(self,stream):self.stream=stream
            def write(self,value):raise OSError('disk full')
            def __getattr__(self,name):return getattr(self.stream,name)
        try:
            log.write(p,0,0,'running',[]);old=dict(log.committed_sizes)
            log.streams['tab4']=FailWrite(log.streams['tab4'])
            with self.assertRaises(OSError):log.write(replace(p,t_s=1),0,0,'running',[])
            self.assertEqual(log.count,1);self.assertEqual(log.committed_sizes,old)
            for name in MEASUREMENT_FILES.values():self.assertEqual(len(rows((directory/name).read_bytes())),1)
        finally:
            for stream in log.streams.values():stream.close()
    def test_data_write_failure_stops_before_the_next_power_event(self):
        original=MeasurementLog.write
        def fail(log,*args):
            if log.count==90:raise OSError('measurement disk failed')
            return original(log,*args)
        with patch.object(MeasurementLog,'write',fail):self.complete(csv_text=source_csv(180),max_power_percent=1)
        self.assertEqual(self.s.reason,'input_or_storage_error')
        self.assertEqual(self.s.controller.power_index_percent,-1)
        self.assertFalse(any(e['kind']=='simulated_power_increased' for e in self.s.events))
        self.assert_aligned(self.data(),90)
    def test_zip_compression_does_not_block_input_and_freezes_aligned_prefixes(self):
        written=threading.Event();compressing=threading.Event();release=threading.Event();advanced=threading.Event()
        original_write=MeasurementLog.write;original_export=__import__('boiling_automation.gui',fromlist=['CalibrationCapture']).CalibrationCapture.export_snapshot
        frozen_count=[None];result=[];errors=[]
        def write(log,*args):
            original_write(log,*args);written.set()
            if frozen_count[0] is not None and log.count>=frozen_count[0]+3:advanced.set()
        def compress(entries):
            frozen_count[0]=json.loads(dict(entries)['data_snapshot.json'])['sample_count'];compressing.set()
            release.wait(3);return original_export(entries)
        def export():
            try:result.append(self.s.export())
            except Exception as error:errors.append(error)
        with patch.object(MeasurementLog,'write',write),patch('boiling_automation.gui.CalibrationCapture.export_snapshot',side_effect=compress):
            self.start(csv_text=source_csv(300),speed=60,max_power_percent=100);self.assertTrue(written.wait(2))
            worker=threading.Thread(target=export);worker.start()
            try:self.assertTrue(compressing.wait(2));self.assertTrue(advanced.wait(2))
            finally:release.set();worker.join(5);self.s.stop();self.s.worker.join(5)
        self.assertFalse(errors);self.assertTrue(result)
        with zipfile.ZipFile(io.BytesIO(result[0][0])) as z:
            data={basis:rows(z.read(name)) for basis,name in MEASUREMENT_FILES.items()};self.assert_aligned(data,frozen_count[0])
            self.assertGreater(self.s.writer.measurements.count,frozen_count[0])

class BufferedStorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.now=0.
        patcher=patch('boiling_automation.measurement_data.time.monotonic',side_effect=lambda:self.now)
        patcher.start();self.addCleanup(patcher.stop)
        self.log=MeasurementLog(self.root,TemperatureCalibration(),flush_interval_s=.25,batch_size=8)
    def tearDown(self):
        for stream in self.log.streams.values():stream.close()
        self.tmp.cleanup()
    def point(self,t):return Reading(t,(100.123456789,)*8,bulk_temperatures_c=(99.987654321,)*4)
    def write(self,t,events=()):self.log.write(self.point(t),0,0,'running',events)
    def test_time_and_size_batches_keep_every_sample_aligned_without_rounding(self):
        self.write(0);self.now=.249;self.write(.1)
        self.assertEqual(self.log.snapshot()['sample_count'],0)
        self.assertEqual(self.log.snapshot()['pending_sample_count'],2)
        self.now=.251;self.write(.2)
        self.assertEqual(self.log.snapshot()['sample_count'],3)
        for i in range(3,11):self.write(i/10)
        self.assertEqual(self.log.committed_count,11)
        data=[rows((self.root/name).read_bytes()) for name in MEASUREMENT_FILES.values()]
        for view in data:
            self.assertEqual([int(r['sample_id']) for r in view],list(range(11)))
            self.assertEqual(float(view[-1]['TC1']),100.123456789)
            self.assertEqual(float(view[-1]['TC12']),99.987654321)
    def test_power_transition_and_shutdown_force_pending_data_to_disk(self):
        self.write(0)
        self.write(.1,[Event('simulated_power_increased',.1,{'power_percent':1})])
        self.assertEqual(self.log.committed_count,2)
        self.write(.2)
        self.write(.3,[Event('shutdown_required',.3,{'reason':'critical_temperature'})])
        self.assertEqual(self.log.committed_count,4)
        self.assertEqual(self.log.snapshot()['pending_sample_count'],0)
        for name in MEASUREMENT_FILES.values():
            data=rows((self.root/name).read_bytes())
            self.assertEqual(len(data),4)
            self.assertEqual(data[-1]['stop_reason'],'critical_temperature')
    def test_partial_batch_failure_rolls_all_views_back_to_same_committed_prefix(self):
        self.write(0);self.log.flush()
        sizes=dict(self.log.committed_sizes)
        self.write(.1);self.write(.2)
        stream=self.log.streams['tab4']
        with patch.object(stream,'write',side_effect=OSError('disk full')):
            with self.assertRaises(OSError):self.log.flush()
        self.assertEqual(self.log.count,1)
        self.assertEqual(self.log.committed_sizes,sizes)
        self.assertEqual(self.log.snapshot()['pending_sample_count'],0)
        for name in MEASUREMENT_FILES.values():self.assertEqual(len(rows((self.root/name).read_bytes())),1)


class MeasurementHttpTests(unittest.TestCase):
    def test_individual_csv_and_stale_or_unknown_request(self):
        with tempfile.TemporaryDirectory() as folder:
            server=GuiServer(('127.0.0.1',0),Path(folder));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            s=server.session;s.temperature_calibration=calibration()
            try:
                s.start({'source':'csv','csv_text':source_csv(),'critical_c':200,'allowed_std_c':.1,'max_power_percent':0,'speed':300});s.worker.join(5)
                run=s.writer.directory.name
                def get(query):
                    c=http.client.HTTPConnection(*server.server_address);c.request('GET','/api/export-measurements?'+query);r=c.getresponse();body=r.read();headers=dict(r.getheaders());c.close();return r.status,headers,body
                for basis in MEASUREMENT_FILES:
                    code,headers,body=get('basis='+basis+'&run_name='+run)
                    self.assertEqual(code,200);self.assertIn('text/csv',headers['Content-Type']);self.assertIn(run,headers['Content-Disposition'])
                    self.assertEqual(len(rows(body)),91)
                for query in ('basis=other','basis=tab4&run_name=old','basis=../../run.json'):
                    self.assertEqual(get(query)[0],400)
            finally:
                s.stop();server.shutdown();server.server_close();thread.join(5)

if __name__=='__main__':unittest.main()
