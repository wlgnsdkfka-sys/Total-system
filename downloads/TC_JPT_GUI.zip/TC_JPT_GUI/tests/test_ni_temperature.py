from types import SimpleNamespace
import unittest
from unittest.mock import patch

from boiling_automation.ni_temperature import NISettings,DEFAULT_CHANNELS,readings,load_driver


class Cancel:
    def __init__(self):self.stopped=False
    def is_set(self):return self.stopped
    def wait(self,delay):self.stopped=True;return True


class FakeTask:
    def __init__(self,values=None,failure=None):
        self.channels=[];self.started=False;self.closed=False;self.failure=failure
        self.values=values if values is not None else [99+i*.1 for i in range(12)]
        self.ai_channels=SimpleNamespace(add_ai_thrmcpl_chan=self.add)
    def add(self,*args,**kwargs):self.channels.append((args,kwargs))
    def __enter__(self):return self
    def __exit__(self,*args):self.closed=True
    def start(self):self.started=True
    def read(self,**kwargs):
        if self.failure:raise self.failure
        return self.values


def constants():
    return SimpleNamespace(TemperatureUnits=SimpleNamespace(DEG_C='degC'),
        ThermocoupleType=SimpleNamespace(**{k:k for k in ('B','E','J','K','N','R','S','T')}),
        CJCSource=SimpleNamespace(BUILT_IN='builtIn'))


class NIReadOnlyTests(unittest.TestCase):
    def settings(self,**extra):return NISettings(DEFAULT_CHANNELS,('K',)*12,**extra)
    def test_candidate_channel_order_and_cold_junction_units_are_explicit(self):
        task=FakeTask();cancel=Cancel()
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            rows=list(readings(self.settings(),cancel))
        self.assertEqual(len(rows),1);self.assertTrue(task.started);self.assertTrue(task.closed)
        self.assertEqual(len(task.channels),12)
        self.assertEqual([row[0][0] for row in task.channels],list(DEFAULT_CHANNELS))
        self.assertEqual([row[0][0] for row in task.channels][-4:],['cDAQ1Mod3/ai15','cDAQ1Mod3/ai14','cDAQ1Mod3/ai13','cDAQ1Mod3/ai12'])
        self.assertTrue(all(v[1]['units']=='degC' and v[1]['cjc_source']=='builtIn' for v in task.channels))
        self.assertEqual(rows[0].temperatures_c[0],99);self.assertEqual(rows[0].bulk_temperatures_c[-1],100.1)
        self.assertEqual(rows[0].t_s,0)
    def test_task_is_closed_on_bad_shape_out_of_range_or_driver_failure(self):
        for values,failure in (([100]*11,None),([float('nan')]*12,None),([9999]*12,None),(None,RuntimeError('read failed'))):
            task=FakeTask(values,failure)
            with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
                with self.assertRaises((ValueError,RuntimeError)):list(readings(self.settings(),Cancel()))
            self.assertTrue(task.closed)
    def test_closing_generator_releases_ni_resource(self):
        task=FakeTask()
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            source=readings(self.settings(),Cancel());next(source);source.close()
        self.assertTrue(task.closed)
    def test_cancel_before_start_does_not_start_ai(self):
        task=FakeTask();cancel=Cancel();cancel.stopped=True
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            self.assertEqual(list(readings(self.settings(),cancel)),[])
        self.assertFalse(task.started);self.assertTrue(task.closed)
    def test_mixed_thermocouple_types_are_supported(self):
        task=FakeTask();settings=NISettings(DEFAULT_CHANNELS,('K',)*8+('T',)*4)
        with patch('boiling_automation.ni_temperature.load_driver',return_value=(SimpleNamespace(Task=lambda:task),constants())):
            list(readings(settings,Cancel()))
        self.assertEqual([c[1]['thermocouple_type'] for c in task.channels],['K']*8+['T']*4)
    def test_ambiguous_channels_missing_types_and_ranges_are_rejected(self):
        for kwargs in ({'physical_channels':DEFAULT_CHANNELS[:-1]},
                       {'physical_channels':('cDAQ1Mod3/ai0:11',)*12},
                       {'physical_channels':('Dev1/port0/line0',)*12},
                       {'physical_channels':('Dev1/ai0',)*12},
                       {'thermocouple_types':('',)*12},
                       {'minimum_c':300,'maximum_c':100}):
            data={'physical_channels':DEFAULT_CHANNELS,'thermocouple_types':('K',)*12,**kwargs}
            with self.assertRaises(ValueError):NISettings.from_payload(data)
    def test_missing_driver_has_installation_guidance(self):
        with patch('boiling_automation.ni_temperature.importlib.import_module',side_effect=ModuleNotFoundError()):
            with self.assertRaisesRegex(ValueError,'NI-DAQmx'):load_driver()
