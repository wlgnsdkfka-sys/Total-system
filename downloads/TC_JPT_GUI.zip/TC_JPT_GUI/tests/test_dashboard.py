import http.client
import json
from pathlib import Path
import statistics
import tempfile
import threading
import unittest

from boiling_automation.core import Config, Reading, ReplayController
from boiling_automation.gui import GuiServer, GuiSession


def reading(t,value=25): return Reading(float(t),(float(value),)*8)

def csv_for(seconds, values=None):
    text='t_s,'+','.join('TC'+str(i) for i in range(1,9))+'\n'
    return text+'\n'.join(str(t)+','+','.join(map(str,values(t) if values else [25]*8)) for t in range(seconds+1))


class MinimumDurationTests(unittest.TestCase):
    def test_every_step_waits_ninety_seconds_and_advances_at_boundary(self):
        c=ReplayController(Config(1000,allowed_std_c=.1,max_power_percent=2))
        for t in range(270):
            c.process(reading(t))
            self.assertEqual(len(c.records),t//90)
        c.process(reading(270))
        self.assertEqual([r.recorded_at_s for r in c.records],[90,180,270])
        self.assertEqual(c.state,'completed')

    def test_minimum_duration_uses_time_since_step_started(self):
        c=ReplayController(Config(1000,allowed_std_c=.1))
        for t in range(1000,1090): c.process(reading(t))
        self.assertEqual(c.records,[])
        c.process(reading(1090))
        self.assertEqual(c.records[0].recorded_at_s,1090)

    def test_stability_uses_thirty_seconds_instead_of_quiet_last_twenty(self):
        c=ReplayController(Config(1000,allowed_std_c=.1))
        for t in range(100):
            c.process(reading(t,35 if 60<=t<70 else 25))
        self.assertEqual(c.records,[])
        c.process(reading(100))
        self.assertEqual(c.records[0].recorded_at_s,100)
        self.assertEqual(c.records[0].current_std_c,0)

    def test_critical_temperature_preempts_minimum_time(self):
        c=ReplayController(Config(100,allowed_std_c=.1))
        for t in range(10): c.process(reading(t))
        events=c.process(reading(10,100))
        self.assertEqual(events[-1].details['reason'],'critical_temperature')
        self.assertEqual(c.records,[])

    def test_minimum_and_maximum_cannot_be_inverted_or_bypassed(self):
        for kwargs in ({'minimum_step_s':89},{'minimum_step_s':301},
                       {'step_duration_s':89},{'stability_window_s':61}):
            with self.subTest(kwargs=kwargs),self.assertRaises(ValueError):Config(100,**kwargs)


class ContinuousStatisticsTests(unittest.TestCase):
    def run_csv(self,seconds,values=None,**overrides):
        self.temporary=tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        session=GuiSession(Path(self.temporary.name))
        session.start({'source':'csv','csv_text':csv_for(seconds,values),'critical_c':1000,'speed':300,**overrides})
        session.worker.join(12)
        self.assertFalse(session.worker.is_alive())
        return session

    def test_rolling_thirty_seconds_matches_exact_samples_and_marks_startup(self):
        s=self.run_csv(35,lambda t:[25+t*.1]*8)
        snapshot=s.snapshot();expected=statistics.stdev(25+t*.1 for t in range(5,36))
        self.assertEqual(snapshot['records'],[])
        self.assertAlmostEqual(snapshot['current_std_c'],expected)
        self.assertIsNone(snapshot['std_history'][0]['values_c'])
        self.assertEqual(snapshot['std_history'][1]['coverage_s'],1)
        self.assertEqual(snapshot['std_history'][29]['coverage_s'],29)
        self.assertEqual(snapshot['std_history'][30]['coverage_s'],30)
        self.assertEqual(snapshot['std_history'][35]['coverage_s'],30)

    def test_step_change_keeps_rolling_window_and_new_run_resets_it(self):
        s=self.run_csv(125,lambda t:[25 if t<=90 else 35]*8,allowed_std_c=.1)
        history=s.snapshot()['std_history']
        self.assertEqual(len(s.controller.records),1)
        self.assertTrue(all(history[t]['values_c'] is not None for t in range(89,123)))
        self.assertAlmostEqual(history[91]['values_c'][0],statistics.stdev([25]*30+[35]))
        self.assertEqual(history[121]['values_c'][0],0)
        s.start({'critical_c':1000,'speed':1})
        try:
            self.assertLess(len(s.snapshot()['std_history']),3)
            self.assertIsNone(s.snapshot()['current_std_c'])
        finally:s.stop();s.worker.join(5)

    def test_full_run_history_survives_past_six_minutes(self):
        s=self.run_csv(700,lambda t:[25+t*.01]*8)
        snapshot=s.snapshot()
        self.assertEqual(len(snapshot['std_history']),701)
        self.assertEqual(snapshot['std_history'][0]['t_s'],0)
        self.assertEqual(snapshot['std_history'][-1]['t_s'],700)
        self.assertEqual(len(snapshot['history']),361)
        self.assertEqual(snapshot['std_history'][0]['temperatures_c'],(25,)*8)
        self.assertEqual(snapshot['std_history'][-1]['temperatures_c'],(32,)*8)
        self.assertEqual(snapshot['first_t_s'],0)
        metadata=json.loads((s.writer.directory/'run.json').read_text())
        self.assertEqual(metadata['config']['minimum_step_s'],90)
        self.assertEqual(metadata['config']['stability_window_s'],30)
        self.assertEqual(metadata['live_std_window_s'],30)

    def test_window_is_based_on_seconds_not_a_fixed_number_of_samples(self):
        with tempfile.TemporaryDirectory() as directory:
            s=GuiSession(Path(directory))
            points=[reading(i*.05,25+i*.01) for i in range(601)]
            s.std_window.extend(points);s.history.extend(points)
            s.last_reading=points[-1];s._update_range()
            self.assertEqual(len(s.history),361)
            self.assertAlmostEqual(s.std_coverage_s,30)
            self.assertAlmostEqual(s.current_std,statistics.stdev(p.temperatures_c[0] for p in points))

    def test_lamps_use_all_eight_channels_and_distinguish_over_from_equal(self):
        s=self.run_csv(35,allowed_std_c=0)
        indicators=s.snapshot()['indicators']
        self.assertEqual(indicators['critical']['state'],'normal')
        self.assertEqual(indicators['std']['state'],'normal')
        self.assertEqual(indicators['std']['value_c'],0)
        s=self.run_csv(35,lambda t:[25]*7+[25+t*.1],allowed_std_c=.1)
        self.assertEqual(s.snapshot()['indicators']['std']['state'],'alarm')
        self.assertEqual(s.snapshot()['indicators']['std']['channels'],['TC8'])

    def test_critical_lamp_is_red_at_threshold_and_keeps_trip(self):
        s=self.run_csv(10,lambda t:[25]*7+[100 if t==10 else 25],critical_c=100,allowed_std_c=.2)
        self.assertEqual(s.snapshot()['reason'],'critical_temperature')
        self.assertEqual(s.snapshot()['indicators']['critical']['state'],'alarm')
        self.assertEqual(s.snapshot()['indicators']['critical']['channels'],['TC8'])
        self.assertEqual(s.snapshot()['records'],[])

    def test_incomplete_window_is_distinguished_from_a_full_normal_window(self):
        s=self.run_csv(10,allowed_std_c=.1)
        lamp=s.snapshot()['indicators']['std']
        self.assertEqual(lamp['state'],'unknown')
        self.assertEqual(lamp['coverage_s'],10)
        self.assertEqual(lamp['value_c'],0)

    def test_unset_threshold_and_invalid_data_do_not_show_green(self):
        s=self.run_csv(35)
        self.assertEqual(s.snapshot()['indicators']['std']['state'],'off')
        s=self.run_csv(35,lambda t:[float('nan') if t==35 else 25]*8,allowed_std_c=.2)
        self.assertEqual(s.snapshot()['indicators']['std']['state'],'unknown')
        self.assertEqual(s.snapshot()['indicators']['critical']['state'],'unknown')


class HistoryEndpointTests(unittest.TestCase):
    def test_incremental_history_retains_start_and_resets_for_new_run(self):
        with tempfile.TemporaryDirectory() as directory:
            server=GuiServer(('127.0.0.1',0),Path(directory));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            def get(path):
                connection=http.client.HTTPConnection('127.0.0.1',server.server_address[1],timeout=5)
                try:
                    connection.request('GET',path);response=connection.getresponse()
                    return response.status,json.loads(response.read())
                finally:connection.close()
            try:
                session=server.session
                session.start({'critical_c':1000,'source':'csv','csv_text':csv_for(40),'speed':300})
                session.worker.join(5)
                status,state=get('/api/state?compact=1')
                self.assertEqual(status,200);self.assertNotIn('std_history',state)
                self.assertEqual(state['std_history_count'],41)
                run=state['run_name']
                _,first=get('/api/std-history?run_name='+run+'&from=0')
                self.assertEqual(len(first['points']),41)
                _,tail=get('/api/std-history?run_name='+run+'&from=35')
                self.assertEqual([p['t_s'] for p in tail['points']],list(range(35,41)))
                self.assertFalse(tail['reset'])
                _,bounded=get('/api/std-history?run_name='+run+'&from=30&until=35')
                self.assertEqual([p['t_s'] for p in bounded['points']],list(range(30,35)))
                self.assertEqual(bounded['total'],35)
                _,empty=get('/api/std-history?run_name='+run+'&from=41')
                self.assertEqual(empty['points'],[])
                session.start({'critical_c':1000,'source':'csv','csv_text':csv_for(1),'speed':300})
                session.worker.join(5)
                _,reset=get('/api/std-history?run_name='+run+'&from=35')
                self.assertTrue(reset['reset']);self.assertEqual(reset['start'],0)
                self.assertEqual(len(reset['points']),2)
                self.assertEqual(get('/api/std-history?from=-1')[0],400)
            finally:
                server.session.stop();server.shutdown();server.server_close();thread.join(5)


if __name__=='__main__':unittest.main()
