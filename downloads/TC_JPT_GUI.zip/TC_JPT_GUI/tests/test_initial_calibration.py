"""Multitemperature calibration: fit, evidence round trips, frozen runs and safety."""
from dataclasses import replace
import io,json,math,csv,statistics,tempfile,unittest,uuid
from pathlib import Path
from unittest.mock import patch
from boiling_automation.initial_calibration import (CalibrationDataset,CalibrationPoint,InitialProfile,
                                                    fit_dataset,import_dataset,dataset_csv)
from boiling_automation.gui import GuiSession
from boiling_automation.calibration_capture import CalibrationCapture,CaptureConfig
from boiling_automation.temperature_calibration import TemperatureCalibration
from boiling_automation.core import Reading


def dataset():
    # Known a=1.1 + i*.01 and b=-2+i*.1; deliberately cover the user's five setpoints.
    return CalibrationDataset('data',0,tuple(CalibrationPoint('p'+str(j),ref,
        tuple((ref-(-2+i*.1))/(1.1+i*.01) for i in range(12)),'manual','2026-10-22')
        for j,ref in enumerate((99,100,110,120,130))))


class InitialMathTests(unittest.TestCase):
    def test_fit_all_twelve_channels_and_residuals(self):
        model=fit_dataset(dataset())
        for i,c in enumerate(model.channels):
            self.assertAlmostEqual(c.gain,1.1+i*.01);self.assertAlmostEqual(c.intercept_c,-2+i*.1)
            self.assertLess(c.rmse_c,1e-10);self.assertLess(c.max_error_c,1e-10);self.assertAlmostEqual(c.r_squared,1)
            for p in model.points:self.assertAlmostEqual(model.correct(p.raw_c[i],i),p.reference_c)

    def test_ols_uses_all_points_with_equal_weight(self):
        points=tuple(CalibrationPoint('a'+str(i),y,(x,)*12,'manual','') for i,(x,y) in enumerate([(0,1),(1,3),(2,6)]))
        c=fit_dataset(CalibrationDataset('d',0,points)).channels[0]
        self.assertAlmostEqual(c.gain,2.5);self.assertAlmostEqual(c.intercept_c,5/6)
        self.assertAlmostEqual(c.rmse_c,math.sqrt(1/18));self.assertAlmostEqual(c.max_error_c,1/3)

    def test_insufficient_identical_raw_or_reversed_points_rejected(self):
        ds=dataset()
        bad=[replace(ds,points=()),replace(ds,points=ds.points[:1]),
             replace(ds,points=tuple(replace(p,reference_c=100) for p in ds.points)),
             replace(ds,points=tuple(replace(p,raw_c=(1,)*12) for p in ds.points)),
             replace(ds,points=tuple(replace(p,raw_c=tuple(-v for v in p.raw_c)) for p in ds.points))]
        for value in bad:
            with self.subTest(value=value),self.assertRaises(ValueError):fit_dataset(value)

    def test_nonfinite_bool_wrong_channels_and_duplicate_ids_rejected(self):
        p=dataset().points[0]
        for change in ({'reference_c':float('nan')},{'reference_c':True},{'raw_c':(1,)*11},
                       {'raw_c':(float('inf'),)*12},{'std_c':(-1,)*12}):
            with self.subTest(change=change),self.assertRaises(ValueError):replace(p,**change)
        with self.assertRaises(ValueError):CalibrationDataset('d',0,(p,p))

    def test_json_csv_roundtrip(self):
        ds=dataset()
        for kind,text in [('json',json.dumps(ds.to_dict())),('csv',dataset_csv(ds).decode('utf-8-sig'))]:
            loaded=import_dataset(text,kind)
            self.assertEqual(loaded.points,ds.points);self.assertEqual(loaded.fingerprint,ds.fingerprint)

    def test_alias_csv_and_invalid_partial_channel_do_not_pass(self):
        text='reference_c,'+','.join('TC'+str(i) for i in range(1,13))+'\n100,'+','.join(['99']*12)+'\n'
        self.assertEqual(import_dataset(text,'csv').points[0].raw_c,(99,)*12)
        for value in [text.replace(',TC12',''),text.replace('100,99','nan,99'),text.replace('TC12','TC11')]:
            with self.assertRaises(ValueError):import_dataset(value,'csv')

    def test_profile_restore_refits_and_rejects_modified_coefficients(self):
        model=fit_dataset(dataset());data=model.to_dict()
        self.assertEqual(InitialProfile.from_dict(data),model)
        data['channels'][0]['gain']+=.1
        with self.assertRaises(ValueError):InitialProfile.from_dict(data)

    def test_initial_corrects_bulk_std_and_extrapolates_without_clamp(self):
        model=fit_dataset(dataset());p=TemperatureCalibration(initial_calibration=model)
        originals=[];corrected=[]
        for t in range(31):
            values=tuple(150+t*.1 for _ in range(12));r=p.apply(Reading(t,values[:8],bulk_temperatures_c=values[8:]))
            originals.append(values[0]);corrected.append(r.temperatures_c[0]);self.assertEqual(r.raw_temperatures_c,values[:8])
            self.assertAlmostEqual(r.bulk_temperatures_c[3],model.correct(values[11],11))
        self.assertAlmostEqual(statistics.stdev(corrected),1.1*statistics.stdev(originals))
        self.assertGreater(corrected[0],130)
        for i in range(12):self.assertAlmostEqual(p.correct_value(p.raw_for_corrected(210,i),i),210)
        self.assertIsNone(p.apply(Reading(0,(90,)*8,bulk_temperatures_c=(None,)*4)).bulk_temperatures_c[0])


class InitialSessionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.folder=Path(self.tmp.name);self.s=GuiSession(self.folder)
    def tearDown(self):
        self.s.stop()
        for worker in (self.s.worker,self.s.capture_worker):
            if worker and worker.is_alive():worker.join(5)
        self.tmp.cleanup()
    def expected(self):
        return {'expected_dataset_id':self.s.initial_dataset.dataset_id,'expected_revision':self.s.initial_dataset.revision}
    def update(self,action,**kwargs):return self.s.update_initial_data({**self.expected(),'action':action,**kwargs})
    def fit(self):
        self.update('import',format='json',text=json.dumps(dataset().to_dict()))
        return self.s.fit_initial_data(self.expected())
    def activate(self,action='apply',**kwargs):
        return self.s.activate_initial_calibration({**self.expected(),'action':action,
            'fit_id':self.s.initial_fit.profile_id if self.s.initial_fit else None,
            'expected_profile_id':self.s.temperature_calibration.profile_id,**kwargs})
    def boil(self):
        self.s.save_temperature_calibration({'action':'apply','reference_c':100,'reference_raw_c':[99]*12,
          'expected_profile_id':self.s.temperature_calibration.profile_id})
    def test_workspace_auto_persists_but_import_never_activates(self):
        self.fit();self.assertIsNone(self.s.temperature_calibration.initial_calibration)
        self.assertEqual(GuiSession(self.folder).initial_dataset,self.s.initial_dataset)
    def test_model_activation_persists_full_points_and_coefficients(self):
        self.fit();self.activate();restored=GuiSession(self.folder)
        self.assertEqual(restored.temperature_calibration,self.s.temperature_calibration)
        self.assertEqual(len(restored.temperature_calibration.initial_calibration.points),5)
    def test_version_guards_and_invalid_import_preserve_disk_and_active_model(self):
        self.fit();self.activate();ds=self.s.initial_dataset;model=self.s.temperature_calibration
        before=(self.folder/'initial_calibration_data.json').read_bytes()
        for payload in [{'action':'clear','expected_revision':-1},
                        {**self.expected(),'action':'import','format':'csv','text':'garbage'},
                        {**self.expected(),'action':'add_manual','reference_c':100,'raw_c':[99]*11}]:
            with self.assertRaises(ValueError):self.s.update_initial_data(payload)
        self.assertEqual(self.s.initial_dataset,ds);self.assertEqual(self.s.temperature_calibration,model)
        self.assertEqual((self.folder/'initial_calibration_data.json').read_bytes(),before)
    def test_edit_delete_and_clear_invalidate_fit_without_changing_applied_snapshot(self):
        self.fit();self.activate();model=self.s.temperature_calibration;old=self.s.initial_dataset.points[0]
        self.update('edit',point_id=old.point_id,reference_c=old.reference_c+.2,raw_c=list(old.raw_c),note='changed')
        self.assertIsNone(self.s.initial_fit);self.assertEqual(self.s.temperature_calibration,model)
        self.update('delete',point_id=old.point_id);self.assertEqual(len(self.s.initial_dataset.points),4)
        self.update('clear');self.assertEqual(len(self.s.initial_dataset.points),0)
        self.assertEqual(len(self.s.temperature_calibration.initial_calibration.points),5)
        with self.assertRaises(ValueError):self.activate()
    def test_existing_boiling_offset_rebased_on_initial_apply_disable(self):
        self.boil();self.fit();self.activate()
        for i in range(12):self.assertAlmostEqual(self.s.temperature_calibration.correct_value(99,i),100)
        for i in range(12):self.assertAlmostEqual(self.s.temperature_calibration.correct_value(109,i),100+10*(1.1+i*.01))
        self.activate('disable');self.assertEqual(self.s.temperature_calibration.offsets_c,(1.,)*12)
        self.assertIsNone(self.s.temperature_calibration.initial_calibration)
    def test_boiling_save_disable_reset_keep_initial_model(self):
        self.fit();self.activate();initial=self.s.temperature_calibration.initial_calibration;self.boil()
        self.assertAlmostEqual(self.s.temperature_calibration.correct_value(99,0),100)
        for action in ('disable','reset'):
            self.s.save_temperature_calibration({'action':action,'expected_profile_id':self.s.temperature_calibration.profile_id})
            self.assertEqual(self.s.temperature_calibration.initial_calibration,initial)
            self.assertFalse(self.s.temperature_calibration.enabled)
    def test_cannot_activate_while_experiment_running_and_critical_injection_uses_full_inverse(self):
        self.fit();self.activate()
        self.s.start({'source':'demo','critical_c':1000,'allowed_std_c':.1,'max_power_percent':100,'speed':60})
        with self.assertRaises(ValueError):self.activate('disable')
        self.s.inject(7);self.s.worker.join(5)
        snap=self.s.snapshot();self.assertEqual(snap['reason'],'critical_temperature')
        self.assertEqual(snap['events'][-1]['details']['channels'],['TC8'])
        self.assertAlmostEqual(snap['latest']['temperatures_c'][7],1001)
    def test_run_freezes_model_and_original_raw_in_output(self):
        self.fit();self.activate();initial=self.s.temperature_calibration.initial_calibration
        text='t_s,'+','.join('TC'+str(i) for i in range(1,13))+'\n'+'\n'.join(str(t)+','+','.join(['99']*12) for t in range(91))
        self.s.start({'source':'csv','csv_text':text,'critical_c':1000,'allowed_std_c':.1,'max_power_percent':0,'speed':300})
        self.s.worker.join(5);self.assertFalse(self.s.worker.is_alive())
        self.update('clear');self.activate('disable')
        metadata=json.loads((self.s.writer.directory/'run.json').read_text())
        self.assertEqual(metadata['temperature_calibration']['initial_calibration']['profile_id'],initial.profile_id)
        self.assertEqual(len(metadata['temperature_calibration']['initial_calibration']['points']),5)
        samples=list(csv.DictReader(io.StringIO((self.s.writer.directory/'selected_samples.csv').read_text())))
        self.assertEqual(float(samples[0]['TC1_raw_c']),99)
        self.assertAlmostEqual(float(samples[0]['TC1']),initial.correct(99,0))
        self.assertEqual(self.s.run_temperature_calibration.initial_calibration,initial)
    def test_compact_poll_excludes_large_point_sets(self):
        self.fit();self.activate();state=self.s.snapshot(False)
        compact=state['temperature_calibration']['initial_calibration']
        self.assertNotIn('points',compact);self.assertEqual(compact['point_count'],5)
        self.assertIn('points',self.s.snapshot()['temperature_calibration']['initial_calibration'])
    def test_failed_disk_write_keeps_workspace_and_profile_unchanged(self):
        self.fit();ds=self.s.initial_dataset;profile=self.s.temperature_calibration
        with patch('pathlib.Path.replace',side_effect=OSError('disk')):
            with self.assertRaises(OSError):self.update('clear')
            with self.assertRaises(OSError):self.activate()
        self.assertEqual(self.s.initial_dataset,ds);self.assertEqual(self.s.temperature_calibration,profile)
    def test_stable_capture_evidence_roundtrip_and_edit_preservation(self):
        cap=CalibrationCapture(self.folder/'capture',CaptureConfig(),'csv',300,{},purpose='furnace')
        self.s.calibration_capture=cap
        for t in range(181):cap.observe(Reading(t,(98.,)*8,bulk_temperatures_c=(98.,)*4))
        cap.finish('input_ended')
        self.update('add_capture',capture_id=cap.capture_id,reference_c=99,note='기준 온도계')
        p=self.s.initial_dataset.points[0];self.assertEqual(p.raw_c,(98.,)*12);self.assertEqual(p.std_c,(0.,)*12)
        self.assertEqual(p.evidence.window_s,180)
        for kind in ('json','csv'):
            out=self.s.export_initial_data(kind).decode('utf-8-sig')
            self.assertEqual(import_dataset(out,kind).points,(p,))
        self.update('edit',point_id=p.point_id,reference_c=99.1,raw_c=list(p.raw_c),note='new')
        self.assertEqual(self.s.initial_dataset.points[0].evidence,p.evidence)
        self.update('edit',point_id=p.point_id,reference_c=99.1,raw_c=[98.1]*12)
        self.assertIsNone(self.s.initial_dataset.points[0].evidence)
    def test_unstable_or_emergency_capture_cannot_add(self):
        cap=CalibrationCapture(self.folder/'capture',CaptureConfig(),'csv',300,{},purpose='furnace')
        self.s.calibration_capture=cap
        for t in range(180):cap.observe(Reading(t,(98.,)*8,bulk_temperatures_c=(98.,)*4))
        with self.assertRaises(ValueError):self.update('add_capture',capture_id=cap.capture_id,reference_c=99)
        cap.observe(Reading(180,(98.,)*8,bulk_temperatures_c=(98.,)*4));cap.finish('emergency_stop')
        with self.assertRaises(ValueError):self.update('add_capture',capture_id=cap.capture_id,reference_c=99)


if __name__=='__main__':unittest.main()
