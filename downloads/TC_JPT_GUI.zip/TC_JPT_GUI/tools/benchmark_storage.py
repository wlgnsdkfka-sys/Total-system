"""Compare per-sample and batched CSV I/O, checking byte-identical data."""
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import sys
import tempfile
import time

sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from boiling_automation.core import Reading
from boiling_automation.measurement_data import MeasurementLog,MEASUREMENT_FILES
from boiling_automation.temperature_calibration import TemperatureCalibration


class CountedStream:
    def __init__(self,stream):self.stream=stream;self.flushes=0
    def __getattr__(self,name):return getattr(self.stream,name)
    def flush(self):self.flushes+=1;return self.stream.flush()


def run(samples,interval):
    with tempfile.TemporaryDirectory() as folder:
        log=MeasurementLog(Path(folder),TemperatureCalibration(),flush_interval_s=interval)
        log.streams={key:CountedStream(stream) for key,stream in log.streams.items()}
        try:
            started=time.perf_counter()
            for i in range(samples):
                point=Reading(i/75,tuple(100+j*.01+i*.000001 for j in range(8)),
                              bulk_temperatures_c=(99.1,99.2,99.3,99.4))
                log.write(point,1,1,'running',[])
            log.flush()
            elapsed=time.perf_counter()-started
            hashes={name:hashlib.sha256((Path(folder)/name).read_bytes()).hexdigest()
                    for name in MEASUREMENT_FILES.values()}
            return {'seconds':elapsed,'samples_per_second':samples/elapsed,
                    'flush_calls':sum(s.flushes for s in log.streams.values()),
                    'files_sha256':hashes}
        finally:
            for stream in log.streams.values():stream.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--samples',type=int,default=10000)
    parser.add_argument('--repeats',type=int,default=3)
    args=parser.parse_args()
    if args.samples<1 or args.repeats<1:parser.error('samples and repeats must be positive')
    direct=[run(args.samples,0) for _ in range(args.repeats)]
    batched=[run(args.samples,.25) for _ in range(args.repeats)]
    assert all(r['files_sha256']==direct[0]['files_sha256'] for r in direct+batched)
    before=statistics.median(r['seconds'] for r in direct)
    after=statistics.median(r['seconds'] for r in batched)
    print(json.dumps({'samples_per_run':args.samples,'byte_identical':True,
          'per_sample':direct,'batched':batched,'median_speed_ratio':before/after,
          'scope':'CSV storage microbenchmark, not NI acquisition or end-to-end latency'},indent=2))


if __name__=='__main__':main()
