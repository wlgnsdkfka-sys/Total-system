"""Build a redistributable source GUI ZIP without results or uploaded files."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent.parent
FILES = [
    "run_gui.py", "실행하기.bat", "start_gui.sh", "사용설명서.txt", "README.md", "tests/test_standby.py",
    "boiling_automation/__init__.py", "boiling_automation/core.py",
    "boiling_automation/__main__.py", "boiling_automation/gui.py",
    "boiling_automation/leak.py", "boiling_automation/web/leak.js", "tests/test_leak.py",
    "boiling_automation/boiling.py", "boiling_automation/calculation.py",
    "boiling_automation/web/time-range.js", "boiling_automation/web/index.html", "boiling_automation/web/analysis.js", "docs/hardware_findings.md",
    "docs/ni_calibration.md", "docs/ni_sampling.md", "requirements-ni.txt", "boiling_automation/calibration_capture.py", "boiling_automation/ni_temperature.py", "boiling_automation/web/calibration-capture.js", "tests/test_calibration_capture.py", "tests/test_ni_temperature.py", "tests/test_ni_experiment.py", "boiling_automation/temperature_calibration.py", "boiling_automation/web/temperature-calibration.js", "tests/test_temperature_calibration.py", "boiling_automation/web/alarms.js", "tests/test_alerts.py", "tests/test_dashboard.py", "tests/test_core.py", "tests/test_replay.py", "tests/test_gui.py", "tests/test_analysis.py",
    "boiling_automation/calibration_common.py", "boiling_automation/initial_calibration.py",
    "boiling_automation/initial_calibration_session.py", "boiling_automation/web/initial-calibration.js",
    "boiling_automation/measurement_data.py", "tests/test_measurement_data.py", "docs/measurement_data.md", "tests/test_bulk_calibration.py", "tests/test_workflow.py", "docs/workflow.md", "tests/test_initial_calibration.py", "docs/initial_calibration.md",
    "tools/package_gui.py", "boiling_automation/instance.py", "tests/test_instance.py", "docs/scenarios.md", "boiling_automation/connections.py", "boiling_automation/web/communications.js", "tests/test_connections.py", "docs/communications.md", "boiling_automation/manual_controls.py", "boiling_automation/web/manual-controls.js", "tests/test_manual_controls.py", "docs/manual_controls.md", "boiling_automation/web/experiment-ni.js",
]


def main(argv=None):
    parser = argparse.ArgumentParser(description="Build TC_JPT_GUI.zip")
    parser.add_argument("--destination", type=Path, default=ROOT / "dist")
    parser.add_argument("--preview", type=Path)
    args = parser.parse_args(argv)
    args.destination.mkdir(parents=True, exist_ok=True)
    archive_path = args.destination / "TC_JPT_GUI.zip"
    with tempfile.NamedTemporaryFile(dir=args.destination, suffix=".zip", delete=False) as stream:
        temporary = Path(stream.name)
    hashes = {}
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as archive:
            for name in FILES:
                contents = (ROOT / name).read_bytes()
                if name.endswith(".bat"):
                    contents = contents.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
                archive.writestr("TC_JPT_GUI/" + name, contents)
                hashes[name] = hashlib.sha256(contents).hexdigest()
            if args.preview:
                contents = args.preview.read_bytes()
                archive.writestr("TC_JPT_GUI/GUI_미리보기.png", contents)
                hashes["GUI_미리보기.png"] = hashlib.sha256(contents).hexdigest()
            archive.writestr("TC_JPT_GUI/BUILD_MANIFEST.json", json.dumps({
                "application": "TC / JPT GUI",
                "version": "19.0.0",
                "stability_metric": "sample_standard_deviation_n_minus_one",
                "heat_flux_unit": "W/cm2",
                "mode": "ni_temperature_simulation_and_csv_replay",
                "ni_adc_profiles": {"calibration": "HIGH_RESOLUTION", "experiment": "HIGH_SPEED"},
                "laser_control_connected": False, "shutter_control_connected": False,
                "manual_ni_counter_shutter_available": True,
                "python_required": "3.10+",
                "hardware_connected": False,
                "files_sha256": hashes,
            }, ensure_ascii=False, indent=2) + "\n")
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError("Archive integrity check failed")
        temporary.replace(archive_path)
        if args.preview:
            shutil.copyfile(args.preview, args.destination / "GUI_preview.png")
    finally:
        temporary.unlink(missing_ok=True)
    print(archive_path)
    print(f"{archive_path.stat().st_size:,} bytes · SHA-256 {hashlib.sha256(archive_path.read_bytes()).hexdigest()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
