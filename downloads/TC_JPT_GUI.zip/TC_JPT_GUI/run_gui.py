"""Desktop entry point. Opens the local GUI in the default browser."""

import sys

if sys.version_info < (3, 10):
    print("Python 3.10 이상이 필요합니다. Python을 업데이트한 후 다시 실행하세요.")
    raise SystemExit(1)

from boiling_automation.gui import main

if __name__ == "__main__":
    raise SystemExit(main())
