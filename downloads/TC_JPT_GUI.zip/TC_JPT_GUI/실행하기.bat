@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
    py -3 run_gui.py
    goto finished
)
where python >nul 2>&1
if not errorlevel 1 (
    python run_gui.py
    goto finished
)
echo Python 3.10 이상이 필요합니다.
echo https://www.python.org/downloads/ 에서 설치 후 다시 실행해 주세요.
:finished
if errorlevel 1 pause
